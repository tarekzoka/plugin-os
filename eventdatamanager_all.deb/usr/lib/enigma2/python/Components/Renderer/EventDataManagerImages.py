##
## EventDataManager Image-Renderer
##
# Version 1.0-r18

from __future__ import print_function
from __future__ import absolute_import
from enigma import ePixmap, eCanvas
from Components.config import config
from Components.Renderer.Renderer import Renderer
from Components.ServiceList import PiconLoader
from os import path as os_path, listdir as os_listdir, remove as os_remove
from Tools.BoundFunction import boundFunction
from Tools.LoadPixmap import LoadPixmap
from Tools.Directories import fileExists, resolveFilename, SCOPE_CURRENT_SKIN, SCOPE_SKIN_IMAGE
from enigma import ePicLoad, gPixmapPtr, ePixmap, gFont, eRect, iServiceInformation, iPlayableServicePtr, eServiceReference, eServiceCenter
from Components.AVSwitch import AVSwitch
from skin import parseColor
try:
	from Plugins.Extensions.EventDataManager.plugin import getExistEventImageName, getEventImageName, downloadEventImage, downloadContentImage, edm_print
	edmPluginInstalled = True
except:
	edmPluginInstalled = False

class EventDataManagerImages(Renderer):
	def __init__(self):
		Renderer.__init__(self)
		self.eventImageName = ""
		self.defaultImageName = ""
		self.defaultPiconName = ""
		self.imagetype = "event,backdrop"
		self.imagetype_list = self.imagetype.split(",")
		self.picload = ePicLoad()
		self.loadColor = parseColor("#80212121")
		self.showAltLogoText = 0
		self.lastEventID = None
		self.force_changed = False

	def applySkin(self, desktop, parent):
		attribs = [ ]
		for (attrib, value) in self.skinAttributes:
			if attrib == "defaultimage":
				self.defaultImageName = value
			elif attrib == "defaultpicon":
				self.defaultPiconName = value
			elif attrib == "imagetype":
				self.imagetype = value.lower()
				self.imagetype_list = self.imagetype.split(",")
			elif attrib == "showAltLogoText":
				self.showAltLogoText = value
			else:
				attribs.append((attrib,value))
		self.skinAttributes = attribs
		return Renderer.applySkin(self, desktop, parent)

	GUI_WIDGET = eCanvas #has ePixmap as base-class

	def postWidgetCreate(self, instance):
		instance.setDefaultAnimationEnabled(self.source.isAnimated)

	def changed(self, what):
		if self.instance:
			if what[0] == self.CHANGED_ANIMATED:
				self.instance.setDefaultAnimationEnabled(self.source.isAnimated)
				return
			
			if not edmPluginInstalled:
				print("[EDM] Renderer change - plugin is not installed")
				return
			
			eventImageName = ""
			showLogo = "logo" in self.imagetype
			currentService = None
			event = self.source.event
			eventName = ""
			#print("[EDM] Renderer change self.source", self.source, self.imagetype)
			
			if hasattr(self.source, "service"):
				service = self.source.service
				if isinstance(service, iPlayableServicePtr): #for movieplayer
					info = service and service.info()
					currentService = info.getInfoString(iServiceInformation.sServiceref)
					event = info and info.getEvent(0)
					if event:
						eventName = event.getEventName()
					info = eServiceCenter.getInstance().info(eServiceReference(currentService))
					if info:
						currentService = info.getInfoString(eServiceReference(currentService), iServiceInformation.sServiceref)
					#print("[EDM] Renderer change - iplayable service", currentService, eventName)
				elif isinstance(service, eServiceReference):
					currentService = service.toString()
			
			#for live-tv
			elif hasattr(self.source, "navcore"):
				currentService = self.source.navcore.getCurrentServiceReference().toString()
				if currentService.startswith("-1:"): 
					currentService = None
				event = self.source.event
				if event:
					eventName = event.getEventName()
				#print("[EDM] Renderer change - navcore service", currentService, eventName)

			# if hasattr(self.source, "info"):
				# print("[EDM] Renderer change - currentService info", currentService, self.source.info)
				# event = self.source.info and self.source.info.getEvent(self.source.service)
			
			#print("[EDM] Renderer change - used currentService", currentService, self.source)
			
			imagetype = self.imagetype
			self.force_changed = False
			if len(what)>1 and what[1] == "force_changed":
				self.force_changed = True
			
			picon_pixmap = None
			if "picon" in self.imagetype and currentService:
				picon_pixmap = PiconLoader().getPicon(currentService)
				if not picon_pixmap:
					picon_pixmap = LoadPixmap(self.getDefaultPicon())
			
			if what[0] != self.CHANGED_CLEAR:
				self.loadingImage = False #break show downloaded image if change event
				if event is not None:
					currentEventID = "%s_%s_%s" % (event.getEventId(), event.getEventName(),currentService)
					if not self.force_changed and currentEventID == self.lastEventID:
						edm_print("[EDM] Renderer - no change action because no new event")
						return
					edm_print("[EDM] Renderer - change event, event, lastEvent", currentEventID, self.lastEventID)
					self.lastEventID = currentEventID
					edm_print("[EDM] Renderer changed", what, self.imagetype, self.imagetype_list, self, self.source, event.getEventName())
					#try to load image live from url
					existFilename = ""
					
					for imagetype in self.imagetype_list:
						if "event" == imagetype:
							existFilename = downloadEventImage(event, boundFunction(self.downloadCallback, imagetype, showLogo, event), boundFunction(self.downloadErrorInfoEvent, event, showLogo,""))
							if existFilename == True: # not existing, but download from url
								edm_print("[EDM] Renderer - clear Image on event", event.getEventName())
								self.resetPixmap(picon_pixmap, gradient=True)
								self.loadingImage = True
								edm_print("[EDM] Renderer download with downloadEventImage", existFilename, self.imagetype, event.getEventName())
								return
							edm_print("[EDM] Renderer existFilename after downloadEventImage", existFilename, self.imagetype, event.getEventName())
						
						if "backdrop" == imagetype and not existFilename:
							existFilename = downloadContentImage(event, self.downloadCallbackContent, self.downloadErrorInfo, imageType="backdrop")
							if existFilename == True: # not existing, but download from url
								edm_print("[EDM] Renderer - clear Image on backdrop", event.getEventName())
								self.resetPixmap(picon_pixmap)
								self.loadingImage = True
								edm_print("[EDM] Renderer download backdrop with downloadContentImage", existFilename, self.imagetype, event.getEventName())
								return
							edm_print("[EDM] Renderer existFilename after downloadContentImage", existFilename, self.imagetype, event.getEventName())
						
						if "cover" == imagetype and not existFilename:
							existFilename = downloadContentImage(event, self.downloadCallbackContent, self.downloadErrorInfo, imageType="cover")
							if existFilename == True: # not existing, but download from url
								edm_print("[EDM] Renderer - clear Image on cover")
								self.resetPixmap(picon_pixmap)
								edm_print("[EDM] Renderer download cover with downloadContentImage", existFilename, self.imagetype)
								self.loadingImage = True
								return
						
						if "logo" == imagetype and not existFilename:
							existFilename = downloadContentImage(event, self.downloadCallbackContent, self.downloadErrorInfo, imageType="logo")
							if existFilename == True: # not existing, but download from url
								edm_print("[EDM] Renderer - clear Image on logo")
								self.resetPixmap(picon_pixmap)
								edm_print("[EDM] Renderer download logo with downloadContentImage", existFilename, self.imagetype)
								self.loadingImage = True
								return
						
						if existFilename:
							break
					
					edm_print("[EDM] Renderer existFilename", existFilename, self.imagetype)
					if not existFilename:
						#try to load existing images from image-folder
						showEvent = "event" in self.imagetype
						showBackdrop = "backdrop" in self.imagetype
						showCover = "cover" in self.imagetype
						edm_print("[EDM] Renderer check for existEventImage", imagetype)
						eventImageName = getExistEventImageName(event.getEventName().encode('utf-8'), event.getBeginTime(), checkEvent=showEvent, checkBackdrop=showBackdrop, checkCover=showCover, checkLogo=showLogo)
					else:
						eventImageName = existFilename
			
			if picon_pixmap and eventImageName == "":
				eventImageName = "picon_" + currentService
				if self.eventImageName != eventImageName:
					self.instance.setPixmap(picon_pixmap)
					self.force_changed = False
					edm_print("[EDM] Renderer set picon - current, last, type", eventImageName, self.eventImageName, self.imagetype)
					self.eventImageName = eventImageName
				else:
					edm_print("[EDM] Renderer set picon not needed - same picon", eventImageName)
			
			#get default imagename if no eventImage was found
			if eventImageName == "":
				eventImageName = self.getDefaultImage(event, showLogo)

			#set image from folder
			if self.force_changed or self.eventImageName != eventImageName:
				edm_print("[EDM] Renderer set local image - current, last, type", eventImageName, self.eventImageName, imagetype)
				self.resetPixmap(picon_pixmap)
				self.setImage(eventImageName, imagetype, showLogo, event)
			elif eventImageName.startswith("picon_"):
				pass
			else:
				edm_print("[EDM] Renderer set image not needed  - same Image", eventImageName, imagetype)
			
			if event:
				currentEventID = "%s_%s_%s" % (event.getEventId(), event.getEventName(),currentService)
				if self.lastEventID != currentEventID:
					edm_print("[EDM] Renderer - change event, currentEvent, lastEvent", currentEventID, self.lastEventID)
					self.lastEventID = currentEventID
			else:
				self.lastEventID = None

	def resetPixmap(self, picon_pixmap=None, gradient=False):
		if picon_pixmap:
			self.instance.setPixmap(picon_pixmap)
		else:
			self.instance.setPixmap(gPixmapPtr())
			if gradient:
				self.instance.setGradient(self.loadColor,self.loadColor,ePixmap.GRADIENT_HORIZONTAL)

	def getDefaultPicon(self):
		PiconImageName = ""
		if self.defaultPiconName:
			PiconImageName = self.defaultPiconName
		else:
			tmp = resolveFilename(SCOPE_CURRENT_SKIN, "picon_default.png")
			if fileExists(tmp):
				PiconImageName = tmp
			else:
				PiconImageName = resolveFilename(SCOPE_SKIN_IMAGE, "skin_default/picon_default.png")
		return PiconImageName

	def getDefaultImage(self, event=None, showLogo=None):
		eventImageName = ""
		if event and showLogo and self.showAltLogoText:
			self.writeEventText(event)
		else:
			if self.defaultImageName:
				eventImageName = self.defaultImageName
			else:
				tmp = resolveFilename(SCOPE_CURRENT_SKIN, "picon_default.png")
				if fileExists(tmp):
					eventImageName = tmp
				else:
					eventImageName = resolveFilename(SCOPE_SKIN_IMAGE, "skin_default/picon_default.png")
		return eventImageName
		
	def setImage(self, eventImageName, imagetype=None, showLogo=False, event=None):
		#set image to the widget
		size = self.instance.size()
		self.scale = AVSwitch().getFramebufferScale()
		self.picload.setPara((size.width(), size.height(), self.scale[0], self.scale[1], False, 0, "#FF000000"))
		res = self.picload.startDecode(str(eventImageName), False)
		if not res:
			ptr = self.picload.getData()
			if ptr != None:
				self.instance.setPixmap(ptr)
				self.loadingImage = False
			else:
				if imagetype == "event" and "backdrop" in self.imagetype:
					self.downloadErrorInfoEvent(event, showLogo, eventImageName, "Error on set eventImage", "none")
					return
				edm_print("[EDM] Renderer try to show defaultImage after image could not load with ePicload", eventImageName)
				eventImageName = self.getDefaultImage()
				res = self.picload.startDecode(str(eventImageName), False)
				if not res:
					ptr = self.picload.getData()
					if ptr != None:
						self.instance.setPixmap(ptr)
						self.loadingImage = False
		self.eventImageName = eventImageName

	def writeEventText(self, event):
		#write Event-Title in the image
		self.instance.setPixmap(gPixmapPtr())
		self.font = gFont("Regular", 40)
		self.backgroundColor = parseColor("background")
		self.foregroundColor = parseColor("#00FFFFFF")
		self.instance.setGradient(self.backgroundColor,self.backgroundColor,ePixmap.GRADIENT_HORIZONTAL)
		size = self.instance.size()
		rect = eRect(0,0, size.width(), size.height())
		self.instance.writeText(rect, self.foregroundColor, self.backgroundColor, self.font, event.getEventName().encode('utf-8'), 2|8)
		#useable Flags: 
		#RT_HALIGN_LEFT=0, RT_HALIGN_RIGHT=1, RT_HALIGN_CENTER=2, RT_HALIGN_BLOCK=4,
		#RT_VALIGN_CENTER=8, RT_VALIGN_BOTTOM=16, RT_WRAP=32

	def downloadCallback(self, imagetype="", showLogo=False, event=None, retValue=None, eventImageName=""):
		if self.force_changed or self.eventImageName != eventImageName:
			if self.loadingImage:
				edm_print("[EDM] Renderer set downloaded image", self.eventImageName, eventImageName)
				self.setImage(eventImageName, imagetype, showLogo, event)

	def downloadCallbackContent(self, retValue, eventImageName):
		if self.force_changed or self.eventImageName != eventImageName:
			if self.loadingImage:
				edm_print("[EDM] Renderer set downloaded content-image", self.eventImageName, eventImageName)
				filename, file_extension = os_path.splitext(eventImageName)
				if file_extension == ".svg": #convert to png
					self.pixmap = ePixmap(None)
					self.pixmap.setPixmapFromFile(eventImageName)
					file_extension = ".png"
					self.pixmap.save(ePixmap.FMT_PNG, filename + file_extension)
					os_remove(eventImageName)
				self.setImage(filename + file_extension)

	def downloadErrorInfoEvent(self, event, showLogo, last_eventImageName, error, url):
		edm_print("[EDM] Renderer EventImageDownload ERROR:", self.imagetype, error, url)
		edm_print("[EDM] Renderer try to load exist EventImage after error on EventImageDownload")
		eventImageName = getExistEventImageName(event.getEventName().encode('utf-8'), event.getBeginTime(), checkEvent=True, checkBackdrop=False, checkCover=False, checkLogo=showLogo, event=event)
		if eventImageName == last_eventImageName and "backdrop" in self.imagetype:
			edm_print("[EDM] Renderer try to load backdrop after error on EventImageDownload")
			existFilename = downloadContentImage(event, self.downloadCallbackContent, self.downloadErrorInfo, imageType="backdrop")
			if existFilename == True: # not existing, but download from url
				edm_print("[EDM] Renderer - clear Image on ErrorInfoEvent")
				self.instance.setPixmap(gPixmapPtr())
				self.loadingImage = True
				edm_print("[EDM] Renderer download backdrop with downloadContentImage", existFilename, self.imagetype)
				return
			elif existFilename:
				eventImageName = existFilename
			else:
				eventImageName = self.getDefaultImage(event, showLogo)

		edm_print("[EDM] Renderer set local image on error - current, last, type", eventImageName, self.eventImageName, self.imagetype)
		self.instance.setPixmap(gPixmapPtr())
		self.setImage(eventImageName)

	def downloadErrorInfo(self, error, url):
		edm_print("[EDM] Renderer ImageDownload ERROR:", error, url)
		self.loadingImage = False
		eventImageName = self.getDefaultImage()
		if self.force_changed or self.eventImageName != eventImageName:
			edm_print("[EDM] Renderer try to set default image after error - current, last", eventImageName, self.eventImageName)
			self.instance.setPixmap(gPixmapPtr())
			self.setImage(eventImageName)

