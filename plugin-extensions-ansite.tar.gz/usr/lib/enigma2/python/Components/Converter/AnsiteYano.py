from Components.Converter.Converter import Converter
from Components.Element import cached
from Screens.InfoBar import InfoBar
from Tools.Directories import fileExists
from enigma import eTimer
from enigma import iServiceInformation
from Components.ConfigList import ConfigListScreen
from Components.Converter.Poll import Poll
from Components.config import config, getConfigListEntry, ConfigText, ConfigPassword, ConfigClock, ConfigSelection, ConfigSubsection, ConfigYesNo, configfile, NoSave
from threading import Thread
from socket import socket, AF_INET, SOCK_STREAM, SOCK_DGRAM
from os import system as os_system, path as os_path
import array, struct, fcntl
class AnsiteYano(Poll, Converter, object):
    IP = 0
    NETMASK = 1
    GATEWAY = 2
    MEMTOTAL = 3
    MEMFREE = 4
    STB = 5
    VIDEOMODE = 6
    SKIN = 7
    PROV = 8
    CW0 = 9
    CW1 = 10
    SOURCE = 11
    TMP = 12
    INFO0 = 13
    ALL = 14
    IMAGE = 15
    ALL1 = 16
    VNCAMOSCAM = 17
    PORTNCAMOSCAM = 18
    CONECT = 19

    def __init__(self, type):
        Converter.__init__(self, type)
        Poll.__init__(self)
        self.poll_interval = 1000
        self.poll_enabled = True
        self.testOK = False
        self.type = {'ip': self.IP,
         'netmask': self.NETMASK,
         'gateway': self.GATEWAY,
         'memtotal': self.MEMTOTAL,
         'memfree': self.MEMFREE,
         'stb': self.STB,
         'videomode': self.VIDEOMODE,
         'skin': self.SKIN,
         'prov': self.PROV,
         'cw0': self.CW0,
         'cw1': self.CW1,
         'source': self.SOURCE,
         'tmp': self.TMP,
         'info0': self.INFO0,
         'all': self.ALL,
         'all1': self.ALL1,
         'image': self.IMAGE,
         'vncam': self.VNCAMOSCAM,
         'portncam': self.PORTNCAMOSCAM,
         'connect': self.CONECT,
         }[type]
    def get_iface_list(self):
        names = array.array('B', '\x00' * 4096)
        sck = socket(AF_INET, SOCK_DGRAM)
        bytelen = struct.unpack('iL', fcntl.ioctl(sck.fileno(), 35090, struct.pack('iL', 4096, names.buffer_info()[0])))[0]
        sck.close()
        namestr = names.tostring()
        return [ namestr[i:i + 32].split('\x00', 1)[0] for i in range(0, bytelen, 32) ]
    @cached
    def getText(self):
        if self.type == self.NETMASK:
            if fileExists('/etc/network/interfaces'):
                try:
                    for line in open('/etc/network/interfaces'):
                        if 'netmask' in line:
                            return 'Netmask : '+line.split(' ')[1]

                except:
                    return
        elif self.type == self.IP:
            if fileExists('/etc/network/interfaces'):
                try:
                    for line in open('/etc/network/interfaces'):
                        if 'address' in line:
                            return 'Ip Box : '+line.split(' ')[1]
                except:
                    return
        elif self.type == self.GATEWAY:
            if fileExists('/etc/network/interfaces'):
                try:
                    for line in open('/etc/network/interfaces'):
                        if 'gateway' in line:
                            return 'Gateway : '+line.split(' ')[1]
                except:
                    return
        elif self.type == self.MEMTOTAL:
            if fileExists('/proc/meminfo'):
                try:
                    for line in open('/proc/meminfo'):
                        if 'MemTotal' in line:
                            return 'MemTotal : '+line.split(':')[1]

                except:
                    return
        elif self.type == self.MEMFREE:
            if fileExists('/proc/meminfo'):
                try:
                    for line in open('/proc/meminfo'):
                        if 'MemFree' in line:
                            return 'MemFree : '+line.split(':')[1]
                except:
                    return
        elif self.type == self.STB:
            if fileExists('/etc/image-version'):
                try:
                    for line in open('/etc/image-version'):
                        if 'version' in line:
                            return 'Version_' + line.split('=')[1]
                except:
                    return
        elif self.type == self.VIDEOMODE:
            if fileExists('/etc/videomode'):
                return open('/etc/videomode').read()
        elif self.type == self.SKIN:
            if fileExists('/etc/enigma2/settings'):
                try:
                    for line in open('/etc/enigma2/settings'):
                        if 'config.skin.primary_skin' in line:
                            return 'Skin : '+line.replace('/skin.xml', ' ').split('=')[1]
                except:
                    return
        elif self.type == self.PROV:
            if fileExists('/tmp/ecm.info'):
                for line in open('/tmp/ecm.info'):
                    if 'prov' in line:
                        return 'Prov : '+line.split(':')[1]

        elif self.type == self.CW0:
            if fileExists('/tmp/ecm.info'):
                for line in open('/tmp/ecm.info'):
                    if 'cw0' in line:
                        return 'CW0 : '+line.split(':')[1]
        elif self.type == self.CW1:
            if fileExists('/tmp/ecm.info'):
                for line in open('/tmp/ecm.info'):
                    if 'cw1' in line:
                        return 'CW1 : '+line.split(':')[1]
        elif self.type == self.SOURCE:
            if fileExists('/tmp/ecm.info'):
                for line in open('/tmp/ecm.info'):
                    if 'source' in line:
                        return 'Source : '+line.replace('source:', ' ')
                    if 'from' in line:
                        return 'From : '+line.replace('from:', ' ')
        elif self.type == self.TMP:
            if fileExists('/tmp/ecm.info'):
                for line in open('/tmp/ecm.info'):
                    if 'msec' in line:
                        return 'Tmp : ' + line.split(' ')[0]
        elif self.type == self.INFO0:
            if fileExists('/tmp/ecm.info'):
                for line in open('/tmp/ecm.info'):
                    if '=' in line:
                        return line.replace('=', '')
        elif self.type == self.ALL:
            if fileExists('/tmp/ecm.info'):
                return open('/tmp/ecm.info').read()
            else:
                return '/tmp/ecm.info  Not Found or FTA Channel'
        elif self.type == self.IMAGE:
            if fileExists('/etc/image-version'):
                try:
                    for line in open('/etc/image-version'):
                        if 'creator' in line:
                            return 'Creator : '+line.split('=')[1]
                except:
                    return
        elif self.type == self.VNCAMOSCAM:
            ncam = ''
            oscam = ''
            if not fileExists('/tmp/.ncam/ncam.version') and not fileExists('/tmp/.oscam/oscam.version'):
                return 'Version Ncam : Not Found'+'\n'+'Version Oscam : Not Found'
            elif fileExists('/tmp/.ncam/ncam.version') and not fileExists('/tmp/.oscam/oscam.version'):
                try:
                    for line in open('/tmp/.ncam/ncam.version'):
                        if 'Version' in line:
                            return 'Version Ncam : '+(line.split(':')[1]).replace('\n','').replace('\t','').replace('\r','').replace(' ','')+'\n'+'Version Oscam : Not Found'
                except:
                    return 'Version Ncam : Not Found'+'\n'+'Version Oscam : Not Found'
            elif fileExists('/tmp/.oscam/oscam.version') and not fileExists('/tmp/.ncam/ncam.version'):
                try:
                    for line in open('/tmp/.oscam/oscam.version'):
                        if 'Version' in line:
                            return 'Version Oscam : '+(line.split(':')[1]).replace('\n','').replace('\t','').replace('\r','').replace(' ','').replace('build-DreamOSat-1.20_svn-',' ')+'\n'+'Version Ncam : Not Found'
                except:
                    return 'Version Ncam : Not Found'+'\n'+'Version Oscam : Not Found'
            else:
                try:
                    for line in open('/tmp/.ncam/ncam.version'):
                        if 'Version' in line:
                            ncam = 'Version Ncam : '+(line.split(':')[1]).replace('\n','').replace('\t','').replace('\r','').replace(' ','')
                except:
                     ncam = 'Version Ncam : Not Found'
                try:
                    for line in open('/tmp/.oscam/oscam.version'):
                        if 'Version' in line:
                            oscam = 'Version Oscam : '+(line.split(':')[1]).replace('\n','').replace('\t','').replace('\r','').replace(' ','').replace('build-DreamOSat-1.20_svn-',' ')
                except:
                     oscam ='Version Oscam : Not Found'
                return ncam+'\n'+oscam
        elif self.type == self.PORTNCAMOSCAM:
            ncam = ''
            oscam = ''
            if not fileExists('/tmp/.ncam/ncam.version') and not fileExists('/tmp/.oscam/oscam.version'):
                return 'WebifPort Ncam : Not Found'+'\n'+'WebifPort Oscam : Not Found'
            elif fileExists('/tmp/.ncam/ncam.version') and not fileExists('/tmp/.oscam/oscam.version'):
                try:
                    for line in open('/tmp/.ncam/ncam.version'):
                        if 'WebifPort' in line:
                            return 'WebifPort Ncam : '+(line.split(':')[1]).replace('\n','').replace('\t','').replace('\r','').replace(' ','')+'\n'+'WebifPort Oscam : Not Found'
                except:
                    return 'WebifPort Ncam : Not Found'+'\n'+'WebifPort Oscam : Not Found'
            elif fileExists('/tmp/.oscam/oscam.version') and not fileExists('/tmp/.ncam/ncam.version'):
                try:
                    for line in open('/tmp/.oscam/oscam.version'):
                        if 'WebifPort' in line:
                            return 'WebifPort Ncam : Not Found\n'+'WebifPort Oscam : '+(line.split(':')[1]).replace('\n','').replace('\t','').replace('\r','').replace(' ','')
                except:
                    return 'WebifPort Ncam : Not Found'+'\n'+'WebifPort Oscam : Not Found'
            else:
                try:
                    for line in open('/tmp/.ncam/ncam.version'):
                        if 'WebifPort' in line:
                            ncam = 'WebifPort Ncam : '+(line.split(':')[1]).replace('\n','').replace('\t','').replace('\r','').replace(' ','')
                except:
                     ncam = 'WebifPort Ncam : Not Found'
                try:
                    for line in open('/tmp/.oscam/oscam.version'):
                        if 'WebifPort' in line:
                            oscam = 'WebifPort Oscam : '+(line.split(':')[1]).replace('\n','').replace('\t','').replace('\r','').replace(' ','')
                except:
                     oscam ='WebifPort Oscam : Not Found'
                return ncam+'\n'+oscam
        elif self.type == self.ALL1:
            f = ''
            b = ''
            h = ''
            M = ''
            if fileExists('/tmp/ecm.info') and fileExists('/etc/network/interfaces'):
                f = open('/tmp/ecm.info').read()
                b = open('/etc/network/interfaces')
                try:
                    for line in b:
                        if 'address' in line:
                            return 'IP Box : '+(line.split(' ')[1]).replace('\n','').replace('\t','').replace('\r','')+'\n'+f
                except:
                    return ''
            elif fileExists('/tmp/ecm.info') and not fileExists('/etc/network/interfaces'):
                f = open('/tmp/ecm.info').read()
                return f
            elif not fileExists('/tmp/ecm.info') and fileExists('/etc/network/interfaces'):
                b = open('/etc/network/interfaces')
                try:
                    for line in b:
                        if 'address' in line:
                            return 'IP Box : '+(line.split(' ')[1]).replace('\n','').replace('\t','').replace('\r','')
                except:
                    return ''
            else:
                return ''
        elif self.type == self.CONECT:
            prevOK = self.testOK
            link = 'down'
            for iface in self.get_iface_list():
                if 'lo' in iface:
                    continue
                if os_path.exists('/sys/class/net/%s/operstate' % iface):
                    fd = open('/sys/class/net/%s/operstate' % iface, 'r')
                    link = fd.read().strip()
                    fd.close()
                if link != 'down':
                    break
            if link != 'down':
                s = socket(AF_INET, SOCK_STREAM)
                s.settimeout(1.0)
                try:
                    self.testOK = not bool(s.connect_ex(('172.217.12.195', 80)))
                except:
                    self.testOK = False
                s.close()
            else:
                self.testOK = False
            if self.testOK:
                return 'Connection : Online'
            else:
                return 'Connection : Offline'

    text = property(getText)