# -*- coding: utf-8 -*-
#RAEDQuickSignal (c) RAED 07-02-2014

import os
from Components.config import *
from Plugins.Extensions.RaedQuickSignal.plugin import *
from Plugins.Plugin import PluginDescriptor
from Tools.Directories import resolveFilename, SCOPE_PLUGINS
from Components.config import config, configfile, ConfigSubsection, getConfigListEntry, ConfigSelection, ConfigText, ConfigYesNo
from Components.ConfigList import ConfigListScreen

FONTSPATH = '/usr/share'
FONTPLUGIN=resolveFilename(SCOPE_PLUGINS, "Extensions/RaedQuickSignal/images")
GETPath = os.path.join(FONTSPATH + '/fonts')


if os.path.exists(FONTSPATH + '/fonts/nmsbd.ttf'):
	DEFAULTFont = FONTSPATH + '/fonts/nmsbd.ttf'
	print("DEFAULTFont :", DEFAULTFont)
else:
	DEFAULTFont = FONTPLUGIN + '/nmsbd.ttf'
	print("DEFAULTFont :", DEFAULTFont)

fonts = []
try:
    if os.path.exists(GETPath):
        for fontName in os.listdir(GETPath):
            fontNamePath = os.path.join(GETPath, fontName)
            if fontName.endswith('.ttf'):
                fontName = fontName[:-4]
                fonts.append((fontNamePath, fontName))
except Exception as error:
	trace_error()

############# plugins
config.plugins.RaedQuickSignal = ConfigSubsection()
config.plugins.RaedQuickSignal.updateonline = ConfigYesNo(default=True)
config.plugins.RaedQuickSignal.enabled = ConfigYesNo(default=True)

############# fonts
config.plugins.RaedQuickSignal.fontsenable = ConfigYesNo(default=False)
config.plugins.RaedQuickSignal.fonts = ConfigSelection(default=DEFAULTFont, choices=fonts)

############# keymap
config.plugins.RaedQuickSignal.keyname = ConfigSelection(default = "KEY_TEXT", choices = [
                ("KEY_TEXT", "TEXT"),
                ("KEY_TV", "TV"),
                ("KEY_RADIO", "RADIO"),
                ("KEY_OK", "OK"),
                ("KEY_HELP", "HELP"),
                ("KEY_INFO", "INFO"),
                ("KEY_RED", "RED"),
                ("KEY_GREEN", "GREEN"),
                ("KEY_BLUE", "BLUE"),
                ("KEY_PVR", "PVR"),
                ("KEY_0", "0"),
                ("KEY_1", "1"),
                ("KEY_2", "2"),
                ("KEY_3", "3"),
                ("KEY_F1", "f1"),
                ("KEY_F2", "f2"),
                ("KEY_F3", "f3"),
                ])

############# style of skin
config.plugins.RaedQuickSignal.style = ConfigSelection(default = "AGC1", choices = [
                ("AGC1", "AGC Progress + Picon"),
                ("AGC2", "AGC Progress + Event Description"),
                ("AGC3", "AGC Progress + Weather"),
                ("Event1", "Event Progress + Picon"),
                ("Event2", "Event Progress + Event Description"),
                ("Event3", "Event Progress + Weather"),
                ("Full1", "Full Screen without any extra functions1"),
                ("Full2", "Full Screen without any extra functions2"),
                ("Full3", "Full Screen  + Picon + Virtical"),
                ("Full4", "Full Screen  + Picon + Ecm + Virtical1"),
                ("Full5", "Full Screen  + Picon + Ecm + Virtical2"),
                ("Full6", "Full Screen  + Picon + Ecm + Virtical3"),
                ])

############# DB Value
config.plugins.RaedQuickSignal.enabledBD = ConfigSelection(default = "Enable", choices = [
                ("Enable", "Enable show db value"),
                ("Disable", "Disable show db value")
                ])

############# DB Value
config.plugins.RaedQuickSignal.numbers = ConfigSelection(default = "Numbers", choices = [
                ("Numbers", "Show channels numbers"),
                ("Resolution", "Show Resolution info")
                ])

############# Piocns
config.plugins.RaedQuickSignal.piconpath = ConfigSelection(default = "PLUGIN", choices = [
                ("PLUGIN", "Set Picon Path from Plugin"),
                ("MEDIA", "Set Picon Path from /media"),
                ])
                
############# Weather 
config.plugins.RaedQuickSignal.refreshInterval = ConfigNumber(default=30) #in minutes
config.plugins.RaedQuickSignal.city = ConfigText(default="Manama", visible_width = 250, fixed_size = False)       
config.plugins.RaedQuickSignal.windtype = ConfigSelection(default="ms", choices = [
                ("ms", _("m/s")),
                ("fts", _("ft/s")),
                ("kmh", _("km/h")),
                ("mph", _("mp/h")),
                ("knots", _("knots"))])
config.plugins.RaedQuickSignal.degreetype = ConfigSelection(default="C", choices = [
                ("C", _("Celsius")),
                ("F", _("Fahrenheit"))])
config.plugins.RaedQuickSignal.weather_location= ConfigText(default="bh-BH", visible_width = 250, fixed_size = False)       
