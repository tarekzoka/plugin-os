#!/usr/bin/python
# -*- coding: utf-8 -*-
#RAEDQuickSignal (c) RAED 07-02-2014

from Tools.Directories import resolveFilename, SCOPE_PLUGINS
import os,sys

### Share path
SHAREPATH='/usr/share/enigma2/'
### Picons + Icons path
EMUPATH=resolveFilename(SCOPE_PLUGINS, "Extensions/RaedQuickSignal/PICONS/emu")
WEATHEPATH=resolveFilename(SCOPE_PLUGINS, "Extensions/RaedQuickSignal/PICONS/weather")
PICONSATPATH=resolveFilename(SCOPE_PLUGINS, "Extensions/RaedQuickSignal/PICONS/piconSat")
PICONPROVPATH=resolveFilename(SCOPE_PLUGINS, "Extensions/RaedQuickSignal/PICONS/piconProv")
PICONCRYPTPATH=resolveFilename(SCOPE_PLUGINS, "Extensions/RaedQuickSignal/PICONS/piconCrypt")

try:
	if not os.path.exists(SHAREPATH + 'emu'):
		os.symlink(EMUPATH, SHAREPATH + 'emu')
	if not os.path.exists(SHAREPATH + 'weather'):
		os.symlink(WEATHEPATH, SHAREPATH + 'weather')
	if not os.path.exists(SHAREPATH + 'piconSat'):
		os.symlink(PICONSATPATH, SHAREPATH + 'piconSat')
	if not os.path.exists(SHAREPATH + 'piconProv'):
		os.symlink(PICONPROVPATH, SHAREPATH + 'piconProv')
	if not os.path.exists(SHAREPATH + 'piconCrypt'):
		os.symlink(PICONCRYPTPATH, SHAREPATH + 'piconCrypt')
except:
	pass
