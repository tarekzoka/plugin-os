#!/usr/bin/python
# encoding: utf-8

#  Advanced Quickbutton
#
#  $Id$
#
#  Quickbutton Coded by Dr.Best (c) 2009
#  Support: www.dreambox-tools.info
#  new Code for Advanced QuickButton by Sven H (c) 2018-2019
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.

from __future__ import print_function
from Screens.Screen import Screen
from Screens.ChannelSelection import ChannelSelection
from Plugins.Plugin import PluginDescriptor
from Components.ActionMap import ActionMap, HelpableActionMap
from Components.PluginComponent import plugins
from Plugins.Plugin import PluginDescriptor
from Components.ConfigList import ConfigList, ConfigListScreen
from Components.config import config, ConfigSubsection, ConfigText, configfile, ConfigSelection, getConfigListEntry, ConfigYesNo, NoSave
from Components.Button import Button
from Screens.MessageBox import MessageBox
from Screens.ChoiceBox import ChoiceBox
from os import path as os_path
from operator import itemgetter
from enigma import getDesktop
from Tools.BoundFunction import boundFunction

version = "v0.9"

#== language-support ====================================
from Components.Language import language
from os import environ as os_environ 
import gettext
from Tools.Directories import resolveFilename, SCOPE_LANGUAGE, SCOPE_PLUGINS
lang = language.getLanguage()
os_environ["LANGUAGE"] = lang[:2]
gettext.bindtextdomain("enigma2", resolveFilename(SCOPE_LANGUAGE))
gettext.textdomain("enigma2")
gettext.bindtextdomain("enigma2-plugins", resolveFilename(SCOPE_LANGUAGE))
gettext.bindtextdomain("Quickbutton", "%s%s" % (resolveFilename(SCOPE_PLUGINS), "Extensions/Quickbutton/locale"))

def _(txt):
	t = gettext.dgettext("Quickbutton", txt)
	if t == txt:
		t = gettext.gettext(txt)
	if t == txt:
		t = gettext.dgettext("enigma2-plugins", txt)
	return t
#== end language support ================================

config.plugins.Quickbutton = ConfigSubsection()
config.plugins.Quickbutton.overwritehbbtvredbutton = ConfigYesNo(default = False)
config.plugins.Quickbutton.overwriteEMCbutton = ConfigYesNo(default = False)
config.plugins.Quickbutton.sortMultipeActions = ConfigYesNo(default = True)
config.plugins.Quickbutton.red = ConfigText(default = _("Nothing"), visible_width = 50, fixed_size = False)
config.plugins.Quickbutton.red_b = ConfigText(default = _("Nothing"), visible_width = 50, fixed_size = False)
config.plugins.Quickbutton.green = ConfigText(default = _("Nothing"), visible_width = 50, fixed_size = False)
config.plugins.Quickbutton.green_b = ConfigText(default = _("Nothing"), visible_width = 50, fixed_size = False)
config.plugins.Quickbutton.yellow = ConfigText(default = _("Nothing"), visible_width = 50, fixed_size = False)
config.plugins.Quickbutton.yellow_b = ConfigText(default = _("Nothing"), visible_width = 50, fixed_size = False)
config.plugins.Quickbutton.blue = ConfigText(default = _("Nothing"), visible_width = 50, fixed_size = False)
config.plugins.Quickbutton.blue_b = ConfigText(default = _("Nothing"), visible_width = 50, fixed_size = False)
config.plugins.Quickbutton.radio_b = ConfigText(default = _("Nothing"), visible_width = 50, fixed_size = False)
config.plugins.Quickbutton.radio_l = ConfigText(default = _("Nothing"), visible_width = 50, fixed_size = False)
config.plugins.Quickbutton.text_b = ConfigText(default = _("Nothing"), visible_width = 50, fixed_size = False)
config.plugins.Quickbutton.text_l = ConfigText(default = _("Nothing"), visible_width = 50, fixed_size = False)
config.plugins.Quickbutton.pvr_b = ConfigText(default = _("Nothing"), visible_width = 50, fixed_size = False)
config.plugins.Quickbutton.pvr_l = ConfigText(default = _("Nothing"), visible_width = 50, fixed_size = False)

from Screens.InfoBarGenerics import InfoBarPlugins, InfoBarTeletextPlugin

sz_w = getDesktop(0).size().width()

baseInfoBarPlugins__init__ = None
ENABLE_RED_BUTTON = False
EMC_InfoBarSupport_ori_init = None
EMC_EMCMediaCenter_ori_init = None
EPGActions_showEventList_org = None
InfoBarActions_showRadio_org = None
TeletextActions_startTeletext_org = None
InstantExtensionsActions_org = None
InfoBarActions_movieList_org = None
GP4BluePanelInstalled = False
hbbtvinstalled = False

class ChoiceBox_summary(Screen):
	pass
	
class MultipleActionsChoiceBox(ChoiceBox):
	if sz_w == 1920:
		skin = """
		<screen name="MultipleActionsChoiceBox" position="center,200" size=" 1000,650" title="Input">
			<widget font="Regular;30" name="text" position="10,10" size="980,40" />
			<eLabel position="5,50" size="990,2" backgroundColor="grey" />
			<widget enableWrapAround="1" name="list" position="5,60" scrollbarMode="showOnDemand" size="980,495" transparent="1" />
			<eLabel position="5,565" size="990,2" backgroundColor="grey" />
			<ePixmap pixmap="skin_default/buttons/red.png" position="10,575" size="240,70" scale="stretch" alphatest="on" />
			<ePixmap pixmap="skin_default/buttons/green.png" position="250,575" size="240,70" scale="stretch" alphatest="on" />
			<ePixmap pixmap="skin_default/buttons/yellow.png" position="500,575" size="240,70" scale="stretch" alphatest="on" />
			<ePixmap pixmap="skin_default/buttons/blue.png" position="750,575" size="240,70" scale="stretch" alphatest="on" />
			<widget name="key_red" position="10,575" size="240,70" zPosition="1" font="Regular;30" halign="center" valign="center" backgroundColor="#9f1313" transparent="1" shadowColor="black" shadowOffset="-2,-2" />
			<widget name="key_green" position="250,575" size="240,70" zPosition="1" font="Regular;30" halign="center" valign="center" backgroundColor="#1f771f" transparent="1" shadowColor="black" shadowOffset="-2,-2" />
			<widget name="key_yellow" position="500,575" size="240,70" zPosition="1" font="Regular;30" halign="center" valign="center" backgroundColor="#a08500" transparent="1" shadowColor="black" shadowOffset="-2,-2" />
			<widget name="key_blue" position="750,575" size="240,70" zPosition="1" font="Regular;30" halign="center" valign="center" backgroundColor="#18188b" transparent="1" shadowColor="black" shadowOffset="-2,-2" />
		</screen>"""
	else:
		skin = """
		<screen name="MultipleActionsChoiceBox" position="center,150" size=" 650,410" title="Input">
			<widget font="Regular;22" name="text" position="10,10" size="640,25" />
			<eLabel position="5,45" size="640,1" backgroundColor="grey" />
			<widget enableWrapAround="1" itemHeight="30" name="list" position="0,55" scrollbarMode="showOnDemand" size="640,300" transparent="1" />
			<eLabel position="5,360" size="640,1" backgroundColor="grey" />
			<ePixmap pixmap="skin_default/buttons/red.png" position="10,365" size="155,40" scale="stretch" alphatest="on" />
			<ePixmap pixmap="skin_default/buttons/green.png" position="165,365" size="155,40" scale="stretch" alphatest="on" />
			<ePixmap pixmap="skin_default/buttons/yellow.png" position="320,365" size="155,40" scale="stretch" alphatest="on" />
			<ePixmap pixmap="skin_default/buttons/blue.png" position="475,365" size="155,40" scale="stretch" alphatest="on" />
			<widget name="key_red" position="10,365" size="155,40" zPosition="1" font="Regular;20" halign="center" valign="center" backgroundColor="#9f1313" transparent="1" shadowColor="black" shadowOffset="-2,-2" />
			<widget name="key_green" position="165,365" size="155,40" zPosition="1" font="Regular;20" halign="center" valign="center" backgroundColor="#1f771f" transparent="1" shadowColor="black" shadowOffset="-2,-2" />
			<widget name="key_yellow" position="320,365" size="155,40" zPosition="1" font="Regular;20" halign="center" valign="center" backgroundColor="#a08500" transparent="1" shadowColor="black" shadowOffset="-2,-2" />
			<widget name="key_blue" position="475,365" size="155,40" zPosition="1" font="Regular;20" halign="center" valign="center" backgroundColor="#18188b" transparent="1" shadowColor="black" shadowOffset="-2,-2" />
		</screen>"""

	def __init__(self, session, title = "", list = [], keys = None, selection = 0, skin_name = [], windowTitle = None, allow_cancel = True, titlebartext = _("Input"),pluginlist=[], config_key=None):
		ChoiceBox.__init__(self, session, title = title, list = list, keys = keys, selection = selection, skin_name = skin_name, windowTitle = windowTitle, allow_cancel = allow_cancel, titlebartext = titlebartext)
		self.skinName = "MultipleActionsChoiceBox"
		self.pluginlist = pluginlist
		self.key_values = config_key.value.strip("||").split("||")
		self.key_values_start = self.key_values[:]
		
		self["key_red"]   = Button(_("Cancel"))
		self["key_green"] = Button(_("Save"))
		self["key_yellow"] = Button(_("Delete"))
		self["key_blue"] = Button(_("New"))
		
		self.reloadActionsList()

	def createSummary(self):
		return ChoiceBox_summary
	
	def go(self):
		cursel = self["list"].l.getCurrentSelection()
		pluginlist = self.pluginlist[:]
		if cursel[0][0] != _("Nothing"):
			pluginlist.remove((_("Nothing"),_("Nothing")))
		
		listselection = 0
		index=0
		for x in pluginlist:
			if x[0] == cursel[0][0]:
				listselection = index
				break
			index += 1
		
		self.oldkeyaction = cursel[0][0]
		self.session.openWithCallback(
			self.menuCallbackChange,
			ChoiceBox,
			title = _("Change the key-action"),
			list = pluginlist,
			selection = listselection
		)
	def keyGreen(self):
		actions_list = "||".join(self.key_values)
		self.close((actions_list,""))

	def keyBlue(self):
		pluginlist = self.pluginlist[:]
		pluginlist.remove((_("Nothing"),_("Nothing")))
		self.session.openWithCallback(
			self.menuCallbackAdd,
			ChoiceBox,
			title = _("Select a new key-action"),
			list = pluginlist,
			selection = 0
		)

	def keyYellow(self):
		cursel = self["list"].l.getCurrentSelection()
		self.key_values.remove(cursel[0][0])
		if len(self.key_values) == 0:
			self.key_values.append(_("Nothing"))
		self.reloadActionsList()

	def reloadActionsList(self, action=""):
		from Screens.ChoiceBox import ChoiceEntryComponent
		selection =0
		self.list = []
		self.summarylist = []
		self.__keys = len(self.pluginlist) * [""]
		self.keymap = {}
		pos = 0
		
		if config.plugins.Quickbutton.sortMultipeActions.value:
			for x in self.pluginlist:
				if x[0] in self.key_values:
					strpos = str(self.__keys[pos])
					self.list.append(ChoiceEntryComponent(key = strpos, text = x))
					self.summarylist.append((self.__keys[pos],x[0]))
					pos += 1
		else:
			for v in self.key_values:
				for x in self.pluginlist:
					if x[0] == v:
						strpos = str(self.__keys[pos])
						self.list.append(ChoiceEntryComponent(key = strpos, text = x))
						self.summarylist.append((self.__keys[pos],x[0]))
						pos += 1
		
		self["list"].l.setList(self.list)
		
		if action in ("add","change"):
			listselection=0
			for x in self.list:
				if x[0][0] == self.newkeyaction:
					self["list"].moveToIndex(listselection)
					break
				listselection += 1
		
		self.updateSummary()

	def cancelConfirm(self, result):
		if not result:
			return
		self.close(None)

	def keyRed(self):
		if self.key_values != self.key_values_start:
			self.session.openWithCallback(self.cancelConfirm, MessageBox, _("Really close without saving settings?"))
		else:
			self.close(None)
	
	def cancel(self):
		self.keyRed()

	def menuCallbackChange(self, ret):
		if ret:
			if ret[0] not in self.key_values:
				index = self.key_values.index(self.oldkeyaction)
				self.key_values.remove(self.oldkeyaction)
				self.key_values.insert(index, ret[0])
				self.newkeyaction = ret[0]
				self.reloadActionsList(action="change")
			else:
				self.session.open(MessageBox, _("This action already exist in multiple actions!"), MessageBox.TYPE_INFO)

	def menuCallbackAdd(self, ret):
		if ret:
			self.newkeyaction = ret[0]
			if ret[0] not in self.key_values:
				self.key_values.append(ret[0])
				self.reloadActionsList(action="add")
			else:
				self.session.open(MessageBox, _("This action already exist in multiple actions!"), MessageBox.TYPE_INFO)

def getHBBTVInstalled():
	try:
		from Plugins.Extensions.HbbTV.HbbTV import HbbTV
		return config.plugins.hbbtv.enabled.value
	except ImportError:
		return False

def getGP4BluePanelInstalled():
	try:
		from Plugins.GP4.geminibluepanel.gbluepanel import gBluePanel
		return True
	except ImportError:
		return False
		pass

def autostart(reason, **kwargs):
	global baseInfoBarPlugins__init__,ENABLE_RED_BUTTON, EMC_InfoBarSupport_ori_init, EMC_EMCMediaCenter_ori_init
	
	if "session" in kwargs:
		session = kwargs["session"]
		if baseInfoBarPlugins__init__ is None:
			baseInfoBarPlugins__init__ = InfoBarPlugins.__init__
		
		InfoBarPlugins.__init__ = InfoBarPlugins__init__
		InfoBarPlugins.greenlong = greenlong
		InfoBarPlugins.yellowlong = yellowlong
		InfoBarPlugins.redlong = redlong
		InfoBarPlugins.bluelong = bluelong
		InfoBarPlugins.blue = blue
		InfoBarPlugins.yellow = yellow
		InfoBarPlugins.green = green
		InfoBarPlugins.radio = radio
		InfoBarPlugins.radiolong = radiolong
		InfoBarPlugins.text = text
		InfoBarPlugins.textlong = textlong
		InfoBarPlugins.pvr = text
		InfoBarPlugins.pvrlong = textlong
		
		if config.misc.rcused.value != 1:
			ENABLE_RED_BUTTON = True
			InfoBarPlugins.red = red
		
		if config.plugins.Quickbutton.overwriteEMCbutton.value:
			if os_path.exists("/usr/lib/enigma2/python/Plugins/Extensions/EnhancedMovieCenter"):
				import Plugins.Extensions.EnhancedMovieCenter.InfoBarSupport
				if EMC_InfoBarSupport_ori_init is None:
					EMC_InfoBarSupport_ori_init= Plugins.Extensions.EnhancedMovieCenter.InfoBarSupport.InfoBarSupport.__init__
					Plugins.Extensions.EnhancedMovieCenter.InfoBarSupport.InfoBarSupport.__init__ = EMC_InfoBarSupport__init__
				import Plugins.Extensions.EnhancedMovieCenter.EMCMediaCenter
				if EMC_EMCMediaCenter_ori_init is None:
					EMC_EMCMediaCenter_ori_init= Plugins.Extensions.EnhancedMovieCenter.EMCMediaCenter.EMCMediaCenter.__init__
					Plugins.Extensions.EnhancedMovieCenter.EMCMediaCenter.EMCMediaCenter.__init__ = EMC_EMCMediaCenter__init__

#overwrite radio-key and pvr-key
def startInfoBar(session, **kwargs):
		# delete radio-key-action from InfoBar
		from Screens.InfoBar import InfoBar
		actions = InfoBar.instance["actions"].actions
		if actions.has_key('showRadio'):
			global InfoBarActions_showRadio_org
			InfoBarActions_showRadio_org = actions['showRadio']
			del actions['showRadio']
		
		#overwrite pvr-key
		if actions.has_key('showMovies'):
			global InfoBarActions_movieList_org
			InfoBarActions_movieList_org = actions['showMovies']
			del actions['showMovies']

def setup(session,**kwargs):
	session.open(QuickbuttonSetup)

def Plugins(**kwargs):
	list = [PluginDescriptor(where = PluginDescriptor.WHERE_SESSIONSTART, fnc = autostart)]	
	list.append(PluginDescriptor(name="Setup Advanced Quickbutton", description=_("Setup for Advanced Quickbutton (%s)" % version), where = [PluginDescriptor.WHERE_PLUGINMENU], icon = "setup_quickbutton.png", fnc=setup))
	list.append(PluginDescriptor(where=[PluginDescriptor.WHERE_INFOBAR,], fnc=startInfoBar))
	return list

def EMC_InfoBarSupport__init__(self):
	global EMC_InfoBarSupport_ori_init
	EMC_InfoBarSupport_ori_init(self)
	if config.plugins.Quickbutton.overwriteEMCbutton.value and config.plugins.Quickbutton.yellow_b.value != _("Nothing"):
		actions = self["EPGActions"].actions
		# delete yellow-key-action from EMC_InfoBarSupport
		del actions['showEventList']
		print("[QuickButton] deleted yellow_key_action from EMC_InfoBarSupport (InfoBarEPG)")

def EMC_EMCMediaCenter__init__(self, session, playlist, playall=None, lastservice=None):
	global EMC_EMCMediaCenter_ori_init
	EMC_EMCMediaCenter_ori_init(self, session, playlist, playall, lastservice)
	
	if config.plugins.Quickbutton.overwriteEMCbutton.value:
		if config.plugins.Quickbutton.green_b.value != _("Nothing"):
			# delete green-key-action from EMCMediaCenter
			actions = self["GeneralPlayerPlaybackActions"].actions
			del actions['EMCGreen']
			print("[QuickButton] deleted green_key_action from EMCMediaCenter (CoolAVSwitch)")
	
		if config.plugins.Quickbutton.radio_b.value != _("Nothing"):
			# delete radio-key-action from EMCMediaCenter
			actions = self["GeneralPlayerPlaybackActions"].actions
			del actions['showExtensions']
			print("[QuickButton] deleted radio_key_action from EMCMediaCenter (showExtensions)")

def InfoBarPlugins__init__(self):
	print("[QuickButton] InfoBarPlugins__init__")
	from Screens.InfoBarGenerics import InfoBarEPG, InfobarHbbtvPlugin, InfoBarTeletextPlugin, InfoBarExtensions
	global baseInfoBarPlugins__init__, ENABLE_RED_BUTTON
	print("[QuickButton] InfoBarPlugins__init__ self_type_name: ", type(self).__name__)
	
	if isinstance(self, InfoBarEPG) or isinstance(self, InfoBarTeletextPlugin) or type(self).__name__ == "MoviePlayer" or type(self).__name__ == "MoviePlayerExtended":
		print("[QuickButton] InfoBarPlugins__init__ isinstance or MoviePlayer or MoviePlayerExtended")
		
		InfoBarPlugins.greenlong = greenlong
		InfoBarPlugins.yellowlong = yellowlong
		InfoBarPlugins.redlong = redlong
		InfoBarPlugins.bluelong = bluelong
		InfoBarPlugins.blue = blue
		InfoBarPlugins.yellow = yellow
		InfoBarPlugins.green = green
		InfoBarPlugins.radio = radio
		InfoBarPlugins.radiolong = radiolong
		InfoBarPlugins.text = text
		InfoBarPlugins.textlong = textlong
		InfoBarPlugins.pvr = pvr
		InfoBarPlugins.pvrlong = pvrlong
		if config.misc.rcused.value != 1:
			ENABLE_RED_BUTTON = True
			InfoBarPlugins.red = red

		#overwrite yellow-key
		if isinstance(self, InfoBarEPG):
			actions = self["EPGActions"].actions
			# delete yellow-key-action from InfoBarEPG
			if actions.has_key('showEventList'):
				global EPGActions_showEventList_org
				EPGActions_showEventList_org = actions['showEventList']
				del actions['showEventList']
		
		#overwrite blue-key
		if isinstance(self, InfoBarExtensions):
			actions = self["InstantExtensionsActions"].actions
			# delete blue-key-action from InfoBar
			if actions.has_key('extensions'):
				global InstantExtensionsActions_org
				InstantExtensionsActions_org = actions['extensions']
				del actions['extensions']
		
		#overwrite text-key
		if isinstance(self, InfoBarTeletextPlugin):
			actions = self["TeletextActions"].actions
			# delete text-key-action from InfoBar
			if actions.has_key('startTeletext'):
				global TeletextActions_startTeletext_org
				TeletextActions_startTeletext_org = actions['startTeletext']
				del actions['startTeletext']
		
		x = {
			"green_l": (self.greenlong, _("Assign plugin to long green key pressed")),
			"green_b": (self.green, _("Assign plugin to green key pressed")),
			"yellow_l": (self.yellowlong, _("Assign plugin to long yellow key pressed")),
			"yellow_b": (self.yellow, _("Assign plugin to yellow key pressed")),
			"red_l": (self.redlong, _("Assign plugin to long red key pressed")),
			"blue_l": (self.bluelong, _("Assign plugin to long blue key pressed")),
			"blue_b": (self.blue, _("Assign plugin to blue key pressed")),
			"radio_b": (self.radio, _("Assign plugin to radio key pressed")),
			"radio_l": (self.radiolong, _("Assign plugin to long radio key pressed")),
			"text_b": (self.text, _("Assign plugin to text key pressed")),
			"text_l": (self.textlong, _("Assign plugin to long text key pressed")),
			"video_b": (self.pvr, _("Assign plugin to pvr key pressed")),
			"video_l": (self.pvrlong, _("Assign plugin to long pvr key pressed"))
			}
		if ENABLE_RED_BUTTON:
			x["red_b"] = (self.red, _("Assign plugin to red key pressed"))
			hbbtvinstalled = getHBBTVInstalled()
			if isinstance(self, InfobarHbbtvPlugin) and config.plugins.Quickbutton.overwritehbbtvredbutton.value and hbbtvinstalled:
				self["HbbtvActions"].setEnabled(False)
		self["QuickbuttonActions"] = HelpableActionMap(self, "QuickbuttonActions",x)
		
	else:
		print("[QuickButton] InfoBarPlugins__init__ else")
		InfoBarPlugins.__init__ = InfoBarPlugins.__init__
		InfoBarPlugins.greenlong = None
		InfoBarPlugins.green = None
		InfoBarPlugins.yellowlong = None
		InfoBarPlugins.yellow = None
		InfoBarPlugins.redlong = None
		InfoBarPlugins.bluelong = None
		InfoBarPlugins.blue = None
		InfoBarPlugins.radio = None
		InfoBarPlugins.radiolong = None
		InfoBarPlugins.text = None
		InfoBarPlugins.textlong = None
		InfoBarPlugins.pvr = None
		InfoBarPlugins.pvrlong = None
		if ENABLE_RED_BUTTON:
			InfoBarPlugins.red = None
	print("[QuickButton] baseInfoBarPlugins__init__")
	baseInfoBarPlugins__init__(self)

def pvrlong(self):
	print("[QuickButton] self_type_name: ", type(self).__name__)
	startPlugin(self, str(config.plugins.Quickbutton.pvr_l.value))

def pvr(self):
	print("[QuickButton] self_type_name: ", type(self).__name__)
	if config.plugins.Quickbutton.pvr_b.value != _("Nothing"):
		print("[QuickButton] own pvr-key")
		startPlugin(self, str(config.plugins.Quickbutton.pvr_b.value))
	else:
		print("[QuickButton] org pvr-key")
		InfoBarActions_movieList_org.__func__(self)

def radiolong(self):
	print("[QuickButton] self_type_name: ", type(self).__name__)
	startPlugin(self, str(config.plugins.Quickbutton.radio_l.value))

def radio(self):
	print("[QuickButton] self_type_name: ", type(self).__name__)
	if config.plugins.Quickbutton.overwriteEMCbutton.value == False and type(self).__name__ == "EMCMediaCenter":
		print("[QuickButton] don't overwrite EMC radio-key")
		return
	if config.plugins.Quickbutton.radio_b.value != _("Nothing"):
		print("[QuickButton] own radio-key")
		startPlugin(self, str(config.plugins.Quickbutton.radio_b.value))
	else:
		print("[QuickButton] org radio-key")
		InfoBarActions_showRadio_org.__func__(self)

def textlong(self):
	print("[QuickButton] self_type_name: ", type(self).__name__)
	startPlugin(self, str(config.plugins.Quickbutton.text_l.value))

def text(self):
	if config.plugins.Quickbutton.text_b.value != _("Nothing"):
		print("[QuickButton] own text-key")
		startPlugin(self, str(config.plugins.Quickbutton.text_b.value))
	else:
		print("[QuickButton] org text-key")
		TeletextActions_startTeletext_org.__func__(self)

def greenlong(self):
	print("[QuickButton] greenlong key")
	startPlugin(self,str(config.plugins.Quickbutton.green.value))

def green(self):
	print("[QuickButton] self_type_name: ", type(self).__name__)
	if config.plugins.Quickbutton.overwriteEMCbutton.value == False and type(self).__name__ == "EMCMediaCenter":
		print("[QuickButton] don't overwrite EMC green-key")
		return
	if config.plugins.Quickbutton.green_b.value != _("Nothing"):
		print("[QuickButton] green key")
		startPlugin(self, str(config.plugins.Quickbutton.green_b.value))

def yellowlong(self):
	print("[QuickButton] yellowlong")
	startPlugin(self, str(config.plugins.Quickbutton.yellow.value))

def yellow(self):
	if config.plugins.Quickbutton.yellow_b.value != _("Nothing"):
		print("[QuickButton] own yellow key")
		startPlugin(self, str(config.plugins.Quickbutton.yellow_b.value))
	else:
		print("[QuickButton] org yellow key")
		EPGActions_showEventList_org.__func__(self)

def redlong(self):
	print("[QuickButton] own redlong key")
	startPlugin(self, str(config.plugins.Quickbutton.red.value))

def red(self):
	print("[QuickButton] own red key")
	startPlugin(self, str(config.plugins.Quickbutton.red_b.value))

def blue(self):
	if config.plugins.Quickbutton.blue_b.value != _("Nothing"):
		print("[QuickButton] own blue key")
		startPlugin(self, str(config.plugins.Quickbutton.blue_b.value))
	else:
		print("[QuickButton] org blue key")
		InstantExtensionsActions_org.__func__(self)

def bluelong(self):
	startPlugin(self, str(config.plugins.Quickbutton.blue.value))

def startPluginCallBack(self, ret):
	if ret:
		startPlugin(self, ret[0])

def startPlugin(self,pname):
	actions = pname.split("||")
	if len(actions)>1:
		pluginlist = getActionsList(pname)
		
		#check and open multiple actions
		if not config.plugins.Quickbutton.sortMultipeActions.value:
			unsortedPluginlist = []
			for v in actions:
				for x in pluginlist:
					if x[0] == v:
						unsortedPluginlist.append(x)
			pluginlist = unsortedPluginlist
		
		self.session.openWithCallback(
			boundFunction(startPluginCallBack, self),
			ChoiceBox,
			title = _("Select a key-action"),
			titlebartext = _("Advanced Quickbutton"),
			list = pluginlist,
		)
		return
	msgText = _("Unknown Error")
	no_plugin = True
	if pname != _("Nothing"):
		if pname == _("Single EPG"):
			from Screens.InfoBarGenerics import InfoBarEPG
			if isinstance(self, InfoBarEPG):
				self.openSingleServiceEPG()
			no_plugin = False
		elif pname == _("Multi EPG"):
			from Screens.InfoBarGenerics import InfoBarEPG
			if isinstance(self, InfoBarEPG):
				self.openMultiServiceEPG()
			no_plugin = False
		elif pname == _("MediaPlayer"):
			try: # falls es nicht installiert ist
				from Plugins.Extensions.MediaPlayer.plugin import MediaPlayer
				self.session.open(MediaPlayer)
				no_plugin = False
			except Exception, e:
				msgText = _("Error!\nError Text: %s"%e)
		elif pname == _("Plugin browser"):
			from Screens.PluginBrowser import PluginBrowser
			self.session.open(PluginBrowser)
			no_plugin = False
		elif pname == _("switch 4:3 content display"):
			ar = {"pillarbox": _("Pillarbox"), 
				"panscan": _("Pan&Scan"),  
				"scale": _("Just Scale"),
				"nonlinear": _("Nonlinear")}
			switch = { "pillarbox":"panscan", "panscan":"scale", "scale":"nonlinear", "nonlinear":"pillarbox" }
			config.av.policy_43.value =  switch[config.av.policy_43.value]
			config.av.policy_43.save()
			self.session.open(MessageBox,_("Display 4:3 content as") + " '" + ar[config.av.policy_43.value] +"'", MessageBox.TYPE_INFO, timeout = 3)
			no_plugin = False
		elif pname == _("Activate Picture in Picture"):
			from Screens.InfoBarGenerics import InfoBarPiP
			InfoBarPiP.showPiP(self)
			no_plugin = False
		elif pname == _("Teletext"):
			from Screens.InfoBarGenerics import InfoBarTeletextPlugin
			InfoBarTeletextPlugin.startTeletext(self)
			no_plugin = False
		elif pname == _("Radio"):
			from Screens.InfoBar import InfoBar
			InfoBar.showRadio(InfoBar.instance)
			no_plugin = False
		elif pname == _("Extensionsmenu"):
			from Screens.InfoBarGenerics import InfoBarExtensions
			if isinstance(self, InfoBarExtensions):
				self.showExtensionSelection()
				no_plugin = False
		elif pname == _("Timer"):
			from Screens.TimerEdit import TimerEditList
			self.session.open(TimerEditList)
			no_plugin = False
		elif pname == _("Movielist"):
			InfoBarActions_movieList_org.__func__(self)
			no_plugin = False
		elif pname == _("Audio Options..."):
			from Screens.AudioSelection import AudioSelection
			self.session.openWithCallback(self.audioSelected, AudioSelection, infobar=self)
			no_plugin = False
		elif pname == _("Blue Panel"):
			try:
				from Plugins.GP4.geminibluepanel.gbluepanel import gBluePanel
				self.session.open(gBluePanel)
				no_plugin = False
			except ImportError:
				no_plugin = True
		elif pname == _("HbbTV Applications"):
			try:
				from Plugins.Extensions.HbbTV.HbbTV import HbbTV
				no_plugin = not config.plugins.hbbtv.enabled.value
			except ImportError:
				no_plugin = True
			finally:
				if not no_plugin:
					hbbtv_instance = HbbTV.instance
					if hbbtv_instance:
						hbbtv_instance._showApplicationList()
		elif pname == _("HbbTV red key"):
			from Screens.InfoBarGenerics import InfobarHbbtvPlugin
			if isinstance(self, InfobarHbbtvPlugin):
				self.startHbbtv()
				no_plugin = False
		else:
			plugin = None
			if hasattr(plugins, 'pluginHider_baseGetPlugins'):
				fnc = plugins.pluginHider_baseGetPlugins
			else:
				fnc = plugins.getPlugins
			for p in fnc(where = [PluginDescriptor.WHERE_EXTENSIONSMENU, PluginDescriptor.WHERE_PLUGINMENU]):
				if pname == str(p.name):
					plugin = p
			if plugin is not None:
				try:
					self.runPlugin(plugin)
					no_plugin = False
				except Exception, e:
					msgText = _("Error!\nError Text: %s"%e)
			else: 
				msgText = _("Plugin not found!")
	else:
		msgText = _("No plugin assigned!")
	if no_plugin:
		msgText = "== Advanced Quickbutton ==\n\n" + msgText
		self.session.open(MessageBox,msgText, MessageBox.TYPE_INFO)

def getActionsList(actions="", getAll=False, sort=True):
	# Vorgaben aus EXTENSIONSMENU, PLUGINMENU
	if hasattr(plugins, 'pluginHider_baseGetPlugins'):
		fnc = plugins.pluginHider_baseGetPlugins
	else:
		fnc = plugins.getPlugins
	pluginlist = []
	actions = actions.split("||")
	for p in fnc(where = [PluginDescriptor.WHERE_EXTENSIONSMENU, PluginDescriptor.WHERE_PLUGINMENU]):
		if getAll or p.name in actions:
			if not [(i[0]) for i in pluginlist if i[0] == p.name]:
				pluginlist.append((str(p.name),p))
	
	from Screens.InfoBarGenerics import InfoBarMenu
	if getAll or _("Movielist") in actions:
		pluginlist.append((_("Movielist"), InfoBarMenu.__init__))
	if getAll or _("Timer") in actions:
		pluginlist.append((_("Timer"), InfoBarMenu.__init__))
	if getAll or _("Activate Picture in Picture") in actions:
		from Screens.InfoBarGenerics import InfoBarPiP
		pluginlist.append((_("Activate Picture in Picture"),InfoBarPiP.showPiP))
	if getAll or _("Audio Options...") in actions:
		pluginlist.append((_("Audio Options..."),InfoBarMenu.__init__))
	if GP4BluePanelInstalled and (getAll or _("Blue Panel") in actions):
		from Plugins.GP4.geminibluepanel.gbluepanel import gBluePanel
		pluginlist.append((_("Blue Panel"),gBluePanel.__init__))
	if getAll or _("Plugin browser") in actions:
		pluginlist.append((_("Plugin browser"),InfoBarMenu.__init__))
	if getAll or _("Extensionsmenu") in actions:
		pluginlist.append((_("Extensionsmenu"),InfoBarMenu.__init__))
	if getAll or _("Teletext") in actions:
		pluginlist.append((_("Teletext"),InfoBarMenu.__init__))
	if getAll or _("Radio") in actions:
		pluginlist.append((_("Radio"),InfoBarMenu.__init__))
	if getAll or _("Single EPG") in actions:
		pluginlist.append((_("Single EPG"),InfoBarMenu.__init__))
	if getAll or _("switch 4:3 content display") in actions:
		pluginlist.append((_("switch 4:3 content display"),InfoBarMenu.__init__))
	if getAll or _("Multi EPG") in actions:
		pluginlist.append((_("Multi EPG"),InfoBarMenu.__init__))
	if getAll or _("MediaPlayer") in actions:
		try: # falls es nicht installiert ist
			from Plugins.Extensions.MediaPlayer.plugin import MediaPlayer
			pluginlist.append((_("MediaPlayer"),MediaPlayer.__init__))
		except:
			pass
	if hbbtvinstalled:
		from Plugins.Extensions.HbbTV.HbbTV import HbbTV
		if getAll or _("HbbTV Applications") in actions:
			pluginlist.append((_("HbbTV Applications"),HbbTV.__init__))
		if getAll or _("HbbTV red key") in actions:
			pluginlist.append((_("HbbTV red key"),HbbTV.__init__))
	
	if sort:
		pluginlist = sorted(pluginlist, key=lambda s: s[0].lower())
	
	if getAll or _("Nothing") in actions:
		pluginlist.insert(0,(_("Nothing"),_("Nothing")))
	
	return pluginlist

class QuickbuttonSetup(ConfigListScreen, Screen):

	if sz_w == 1920:
		skin = """
			<screen name="AdvancedQuickbuttonSetup" position="center,100" size="1200,940" title="Quickbutton Setup">
				<ePixmap pixmap="skin_default/buttons/red.png" position="10,5" size="295,70" alphatest="on" />
				<ePixmap pixmap="skin_default/buttons/green.png" position="305,5" size="295,70" alphatest="on" />
				<ePixmap pixmap="skin_default/buttons/yellow.png" position="600,5" size="295,70" alphatest="on" />
				<widget name="key_red" position="10,5" size="295,70" zPosition="1" font="Regular;30" halign="center" valign="center" backgroundColor="#9f1313" transparent="1" shadowColor="black" shadowOffset="-2,-2" />
				<widget name="key_green" position="305,5" size="295,70" zPosition="1" font="Regular;30" halign="center" valign="center" backgroundColor="#1f771f" transparent="1" shadowColor="black" shadowOffset="-2,-2" />
				<widget name="key_yellow" position="600,5" size="295,70" zPosition="1" font="Regular;30" halign="center" valign="center" backgroundColor="#a08500" transparent="1" shadowColor="black" shadowOffset="-2,-2" />
				<eLabel position="10,80" size="1180,1" backgroundColor="grey" />
				<widget name="config" position="10,100" size="1180,810" enableWrapAround="1" scrollbarMode="showOnDemand" />
			</screen>"""
	else:
		skin = """
			<screen name="AdvancedQuickbuttonSetup" position="center,80" size="720,605" title="Quickbutton Setup">
				<ePixmap pixmap="skin_default/buttons/red.png" position="10,5" size="200,40" alphatest="on" />
				<ePixmap pixmap="skin_default/buttons/green.png" position="210,5" size="200,40" alphatest="on" />
				<ePixmap pixmap="skin_default/buttons/yellow.png" position="410,5" size="200,40" alphatest="on" />
				<widget name="key_red" position="10,5" size="200,40" zPosition="1" font="Regular;20" halign="center" valign="center" backgroundColor="#9f1313" transparent="1" shadowColor="black" shadowOffset="-2,-2" />
				<widget name="key_green" position="210,5" size="200,40" zPosition="1" font="Regular;20" halign="center" valign="center" backgroundColor="#1f771f" transparent="1" shadowColor="black" shadowOffset="-2,-2" />
				<widget name="key_yellow" position="410,5" size="200,40" zPosition="1" font="Regular;20" halign="center" valign="center" backgroundColor="#a08500" transparent="1" shadowColor="black" shadowOffset="-2,-2" />
				<eLabel position="10,50" size="700,1" backgroundColor="grey" />
				<widget name="config" position="10,60" seperation="300" size="700,540" enableWrapAround="1" scrollbarMode="showOnDemand" />
			</screen>"""
	

	def __init__(self, session, args = None):
		Screen.__init__(self, session)
		self["key_red"]   = Button(_("Cancel"))
		self["key_green"] = Button(_("Save"))
		self["key_yellow"] = Button(_("Multiple Actions"))
		self.entryguilist = []
		self.setTitle("Advanced Quickbutton Setup " + version)
		self.skinName = "AdvancedQuickbuttonSetup"
		self["setupActions"] = ActionMap(["SetupActions", "ColorActions"],
		{
			"green": self.keySave,
			"cancel": self.keyClose,
			"ok": self.keyMenu,
			"left": self.keyLeft,
			"right": self.keyRight,
			"yellow": self.multipleActions,
		}, -2)
		ConfigListScreen.__init__(self, [], session = session)
		global hbbtvinstalled
		hbbtvinstalled = getHBBTVInstalled()
		self.overwriteHBBTVButton = config.plugins.Quickbutton.overwritehbbtvredbutton
		global GP4BluePanelInstalled
		GP4BluePanelInstalled = getGP4BluePanelInstalled()
		self.createSetup("config")
		self.pluginlist = None

	def getConfigSelection(self, config):
		keyactions = str(config.value).split("||")
		if len(keyactions)>1:
			choices = [(config.value,_("<< Multiple Actions >>"))]
		else:
			choices = [(config.value,config.value)]
		default = config.value
		return ConfigSelection(default = default, choices = choices)

	def createSetup(self, widget):
		cfglist = []
		
		cfglist.append(getConfigListEntry(_("sort multiple actions"), config.plugins.Quickbutton.sortMultipeActions))
		if os_path.exists("/usr/lib/enigma2/python/Plugins/Extensions/EnhancedMovieCenter"):
			cfglist.append(getConfigListEntry(_("overwrite EMC-Keys (green/yellow/radio)"), config.plugins.Quickbutton.overwriteEMCbutton))
		
		self.overwriteHBBTVButtonEntry = None
		if hbbtvinstalled and ENABLE_RED_BUTTON:
			self.overwriteHBBTVButtonEntry = getConfigListEntry(_("overwrite HBBTV-red-button"), self.overwriteHBBTVButton)
			cfglist.append(self.overwriteHBBTVButtonEntry)
		
		cfglist.append(getConfigListEntry(_("KEY ASSIGNMENT"), )) 
		if ENABLE_RED_BUTTON and (self.overwriteHBBTVButton.value or not hbbtvinstalled):
			self.red_b_choice = self.getConfigSelection(config.plugins.Quickbutton.red_b)
			cfglist.append(getConfigListEntry(_("assigned to red"), self.red_b_choice))
		
		self.red_l_choice = self.getConfigSelection(config.plugins.Quickbutton.red)
		cfglist.append(getConfigListEntry(_("assigned to red long"), self.red_l_choice))
		
		self.green_b_choice = self.getConfigSelection(config.plugins.Quickbutton.green_b)
		cfglist.append(getConfigListEntry(_("assigned to green"), self.green_b_choice))
		
		self.green_l_choice = self.getConfigSelection(config.plugins.Quickbutton.green)
		cfglist.append(getConfigListEntry(_("assigned to green long"), self.green_l_choice))
		
		self.yellow_b_choice = self.getConfigSelection(config.plugins.Quickbutton.yellow_b)
		cfglist.append(getConfigListEntry(_("assigned to yellow"), self.yellow_b_choice))
		
		self.yellow_l_choice = self.getConfigSelection(config.plugins.Quickbutton.yellow)
		cfglist.append(getConfigListEntry(_("assigned to yellow long"), self.yellow_l_choice))
		
		self.blue_b_choice = self.getConfigSelection(config.plugins.Quickbutton.blue_b)
		cfglist.append(getConfigListEntry(_("assigned to blue"), self.blue_b_choice))
		
		self.blue_l_choice = self.getConfigSelection(config.plugins.Quickbutton.blue)
		cfglist.append(getConfigListEntry(_("assigned to blue long"), self.blue_l_choice))
		
		self.radio_b_choice = self.getConfigSelection(config.plugins.Quickbutton.radio_b)
		cfglist.append(getConfigListEntry(_("assigned to radio"), self.radio_b_choice))
		
		self.radio_l_choice = self.getConfigSelection(config.plugins.Quickbutton.radio_l)
		cfglist.append(getConfigListEntry(_("assigned to radio long"), self.radio_l_choice))
		
		self.text_b_choice = self.getConfigSelection(config.plugins.Quickbutton.text_b)
		cfglist.append(getConfigListEntry(_("assigned to text"), self.text_b_choice))
		
		self.text_l_choice = self.getConfigSelection(config.plugins.Quickbutton.text_l)
		cfglist.append(getConfigListEntry(_("assigned to text long"), self.text_l_choice))
		
		self.pvr_b_choice = self.getConfigSelection(config.plugins.Quickbutton.pvr_b)
		cfglist.append(getConfigListEntry(_("assigned to pvr"), self.pvr_b_choice))
		
		self.pvr_l_choice = self.getConfigSelection(config.plugins.Quickbutton.pvr_l)
		cfglist.append(getConfigListEntry(_("assigned to pvr long"), self.pvr_l_choice))
		
		self[widget].list = cfglist
		self[widget].l.setList(cfglist)

	def keyLeft(self):
		ConfigListScreen.keyLeft(self)
		self.newConfig()

	def keyRight(self):
		ConfigListScreen.keyRight(self)
		self.newConfig()

	def newConfig(self):
		cur = self["config"].getCurrent()
		if cur and (cur == self.overwriteHBBTVButtonEntry):
			self.createSetup("config")

	def menuCallback(self, ret):
		if ret:
			cur = self["config"].getCurrent()[1]
			if hasattr(self, "red_b_choice") and cur == self.red_b_choice:
				config.plugins.Quickbutton.red_b.value = str(ret[0])
			elif cur == self.red_l_choice:
				config.plugins.Quickbutton.red.value = str(ret[0])
			elif cur == self.green_b_choice:
				config.plugins.Quickbutton.green_b.value = str(ret[0])
			elif cur == self.green_l_choice:
				config.plugins.Quickbutton.green.value = str(ret[0])
			elif cur == self.yellow_b_choice:
				config.plugins.Quickbutton.yellow_b.value = str(ret[0])
			elif cur == self.yellow_l_choice:
				config.plugins.Quickbutton.yellow.value = str(ret[0])
			elif cur == self.blue_b_choice:
				config.plugins.Quickbutton.blue_b.value = str(ret[0])
			elif cur == self.blue_l_choice:
				config.plugins.Quickbutton.blue.value = str(ret[0])
			elif cur == self.text_b_choice:
				config.plugins.Quickbutton.text_b.value = str(ret[0])
			elif cur == self.text_l_choice:
				config.plugins.Quickbutton.text_l.value = str(ret[0])
			elif cur == self.radio_b_choice:
				config.plugins.Quickbutton.radio_b.value = str(ret[0])
			elif cur == self.radio_l_choice:
				config.plugins.Quickbutton.radio_l.value = str(ret[0])
			elif cur == self.pvr_b_choice:
				config.plugins.Quickbutton.pvr_b.value = str(ret[0])
			elif cur == self.pvr_l_choice:
				config.plugins.Quickbutton.pvr_l.value = str(ret[0])
			self.createSetup("config")

	def isKeyConfig(self, conf):
		if conf[1] in (config.plugins.Quickbutton.overwriteEMCbutton, config.plugins.Quickbutton.sortMultipeActions) or conf==self.overwriteHBBTVButtonEntry:
			return False
		else:
			return True

	def multipleActions(self):
		cur = self["config"].getCurrent()
		if not self.isKeyConfig(cur):
			self.session.open(MessageBox, _("To set mutiple key actions please select first a key-option!"), MessageBox.TYPE_INFO)
			return
		
		pluginlist = getActionsList((str(cur[1].value)))
		
		self.session.openWithCallback(
			self.menuCallback,
			MultipleActionsChoiceBox,
			keys=[],
			title = _("Edit multiple key-actions"),
			list = pluginlist,
			titlebartext = _("Multiple Actions") + " - " + cur[0],
			pluginlist = getActionsList((""),getAll=True),
			config_key = cur[1],
		)
	def keyMenu(self):
		cur = self["config"].getCurrent()
		if not self.isKeyConfig(cur):
			return
		
		#check if multiple actions
		actions = cur[1].value.split("||")
		if len(actions)>1:
			self.multipleActions()
			return
		
		if self.pluginlist is None:
			self.pluginlist = getActionsList((""),getAll=True)
		
		listselection = 0
		index=0
		for x in self.pluginlist:
			if x[0] == cur[1].value:
				listselection = index
				break
			index += 1
		
		self.session.openWithCallback(
			self.menuCallback,
			ChoiceBox,
			title = _("Select a key-action") + " - " + cur[0],
			list = self.pluginlist,
			selection = listselection
		)

	def keySave(self):
		self.overwriteHBBTVButton.save()
		config.plugins.Quickbutton.save()
		configfile.save()
		
		#overwrite hbbtv-key on save
		if ENABLE_RED_BUTTON and config.plugins.Quickbutton.overwritehbbtvredbutton.value or not getHBBTVInstalled():
			try:
				from Screens.InfoBar import InfoBar
				InfoBar.instance["HbbtvActions"].setEnabled(False)
			except:
				pass
		elif ENABLE_RED_BUTTON and not config.plugins.Quickbutton.overwritehbbtvredbutton.value and getHBBTVInstalled():
			from Screens.InfoBar import InfoBar
			InfoBar.instance["HbbtvActions"].setEnabled(True)
		
		#overwrite EMC-keys after set to True
		if config.plugins.Quickbutton.overwriteEMCbutton.value:
			if os_path.exists("/usr/lib/enigma2/python/Plugins/Extensions/EnhancedMovieCenter"):
				global EMC_InfoBarSupport_ori_init
				if EMC_InfoBarSupport_ori_init is None:
					import Plugins.Extensions.EnhancedMovieCenter.InfoBarSupport
					EMC_InfoBarSupport_ori_init= Plugins.Extensions.EnhancedMovieCenter.InfoBarSupport.InfoBarSupport.__init__
					Plugins.Extensions.EnhancedMovieCenter.InfoBarSupport.InfoBarSupport.__init__ = EMC_InfoBarSupport__init__
				global EMC_EMCMediaCenter_ori_init
				if EMC_EMCMediaCenter_ori_init is None:
					import Plugins.Extensions.EnhancedMovieCenter.EMCMediaCenter
					EMC_EMCMediaCenter_ori_init= Plugins.Extensions.EnhancedMovieCenter.EMCMediaCenter.EMCMediaCenter.__init__
					Plugins.Extensions.EnhancedMovieCenter.EMCMediaCenter.EMCMediaCenter.__init__ = EMC_EMCMediaCenter__init__

		self.close()

	def cancelConfirm(self, result):
		if not result:
			return

		config.plugins.Quickbutton.overwritehbbtvredbutton.cancel()
		config.plugins.Quickbutton.overwriteEMCbutton.cancel()
		config.plugins.Quickbutton.sortMultipeActions.cancel()
		config.plugins.Quickbutton.red.cancel()
		config.plugins.Quickbutton.red_b.cancel()
		config.plugins.Quickbutton.green.cancel()
		config.plugins.Quickbutton.green_b.cancel()
		config.plugins.Quickbutton.yellow.cancel()
		config.plugins.Quickbutton.yellow_b.cancel()
		config.plugins.Quickbutton.blue.cancel()
		config.plugins.Quickbutton.blue_b.cancel()
		config.plugins.Quickbutton.radio_b.cancel()
		config.plugins.Quickbutton.radio_l.cancel()
		config.plugins.Quickbutton.text_b.cancel()
		config.plugins.Quickbutton.text_l.cancel()
		config.plugins.Quickbutton.pvr_b.cancel()
		config.plugins.Quickbutton.pvr_l.cancel()
		
		self.close()

	def getConfigValue(self, conf):
		if isinstance(conf.value, bool):
			return str(conf.value).lower()
		return str(conf.value)

	def isChanged(self):
		changed=False
		for conf in (config.plugins.Quickbutton.overwritehbbtvredbutton,config.plugins.Quickbutton.overwriteEMCbutton,config.plugins.Quickbutton.sortMultipeActions,config.plugins.Quickbutton.red,config.plugins.Quickbutton.red_b,config.plugins.Quickbutton.green,config.plugins.Quickbutton.green_b,config.plugins.Quickbutton.yellow,config.plugins.Quickbutton.yellow_b,config.plugins.Quickbutton.blue,config.plugins.Quickbutton.blue_b,config.plugins.Quickbutton.radio_b,config.plugins.Quickbutton.radio_l,config.plugins.Quickbutton.text_b,config.plugins.Quickbutton.text_l,config.plugins.Quickbutton.pvr_b,config.plugins.Quickbutton.pvr_l):
			if conf.saved_value is None and self.getConfigValue(conf) == conf.default:
				pass
			elif self.getConfigValue(conf) != conf.saved_value:
				changed = True
				print("=== conf changed", conf.__dict__)
				break
		return changed

	def keyClose(self):
		if self.isChanged():
			self.session.openWithCallback(self.cancelConfirm, MessageBox, _("Really close without saving settings?"))
		else:
			self.close()
