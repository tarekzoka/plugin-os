# -*- coding: utf-8 -*-
# EvgIPChecker
# Copyright (c) Evg77734 2021
# 

from Components.Converter.Converter import Converter
from Components.Element import cached
from Tools.Directories import fileExists
from os import path, popen
import re
import os
import os.path, time
import sys

try:
    py_version = sys.version_info.major
except:
    py_version = 3
    
if py_version == 2:
	from Poll import Poll
else:
	from Components.Converter.Poll import Poll

class EvgIPChecker(Poll, Converter, object):
	IPChecker = 0
	
	def __init__(self, type):
		Converter.__init__(self, type)
		Poll.__init__(self)
		self.poll_interval = 60000
		self.poll_enabled = True
		self.type = {'IPChecker': self.IPChecker
		}[type]		

	@cached	
	def getText(self):
		if self.type == self.IPChecker:
					
			if os.path.exists("/tmp/ip.res") == True:
				t = os.path.getmtime("/tmp/ip.res")
				now = time.time()
				t1 = now - t
				if t1 < 3600.0:
					with open("/tmp/ip.res", "r") as file:
						contents = file.readlines()
						s = str(contents[0])
						res = s.rstrip()
						file.close()
						c = 'IP: ' + res
				else:
					try:
						os.system("wget -qO- http://ipecho.net/plain -O /tmp/ip.res")
					except:
						pass
						
					if os.path.exists("/tmp/ip.res") == True:
						with open("/tmp/ip.res", "r") as file:
							contents = file.readlines()
							s = str(contents[0])
							res = s.rstrip()
							file.close()
							c = 'IP: ' + res
					else:
						c = 'n/a'
						
			else:
				try:
					os.system("wget -qO- http://ipecho.net/plain -O /tmp/ip.res")
				except:
					pass
				
				if os.path.exists("/tmp/ip.res") == True:
					with open("/tmp/ip.res", "r") as file:
						contents = file.readlines()
						s = str(contents[0])
						res = s.rstrip()
						file.close()
						c = 'IP: ' + res
				else:
					c = 'n/a'
				
			return c

	text = property(getText)
