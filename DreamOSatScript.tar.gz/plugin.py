from Screens.Screen import Screen
from Screens.Console import Console
from Components.MenuList import MenuList
from Components.ActionMap import ActionMap
from Plugins.Plugin import PluginDescriptor

from enigma import getDesktop
#######################################################
# Constants
NAME = "DreamOSatScript"
VERSION = "6.4.4"
DESCRIPTION = _("DreamOSatScript")

DESKHEIGHT = getDesktop(0).size().height()
skin_path = "/usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/Skin/"

class Myaudi06(Screen):

    def __init__(self, session, args = None):
        self.session = session
        if DESKHEIGHT < 1000:		
            skin = skin_path + 'menuhd.xml'
        else:	
		     skin = skin_path + 'menufullhd.xml'
        f = open(skin, 'r')
        self.skin = f.read()
        f.close()

#    def __init__(self, session, args = 0):
#        self.session = session
        list = []
        list.append((' (0) DreamOSatScript info', 'com_0'))
        list.append((' (1) Key Updater ', 'com_1'))
        list.append((' (2) PowerVU ALL Keys ', 'com_2'))
        list.append((' (3) OSCam Free Server Freecline.com ', 'com_3'))
        list.append((' (4) OSCam Free Server Testious.com ', 'com_4'))
        list.append((' (5) CCcam Free Server ', 'com_5'))
        list.append((' (6) N-Line Free Server Freecline.com ', 'com_6'))
        list.append((' (7) N-Line Free Server Testious.com ', 'com_7'))
        list.append((' (8) Keys FreeColor 36.E ', 'com_8'))
        list.append((' (9) Keys FreeColor 56.E ', 'com_9'))
        list.append(('===================================', 'com'))
        list.append(('(10) Ip Adress Ogrenme ', 'com_10'))
        list.append(('(11) MAC Adress Ogrenme ', 'com_11'))
        list.append(('(12) Free Space ', 'com_12'))
        list.append(('(13) Emu info ', 'com_13'))
        list.append(('(14) Delete all Crashlogs ', 'com_14'))
        list.append(('(15) Info All ', 'com_15'))
        list.append(('(16) Info Cpu ', 'com_16'))
        list.append(('(17) Info Drivers ', 'com_17'))
        list.append(('(18) Info Internet Ping ', 'com_18'))
        list.append(('(19) Cccam TO OSCam Converter ', 'com_19'))
        list.append(('===================================', 'com'))
        list.append(('(20) OE2.5 HDD Mount ', 'com_20'))
        list.append(('(21) OE2.5 USB Mount ', 'com_21'))
        list.append(('(22) OE2.5 Microcard Mount ', 'com_22'))
        list.append(('(23) OE2.5 Iptv Updater ', 'com_23'))
        list.append(('(24) DreamOSat IPTV Genel ', 'com_24'))
        list.append(('(25) DreamOSat IPTV Belgesel ', 'com_25'))
        list.append(('(26) DreamOSat IPTV Spor ', 'com_26'))
        list.append(('(27) DreamOSat IPTV Sinema ', 'com_27'))
        list.append(('(28) DreamOSat IPTV Music ', 'com_28'))
        list.append(('(29) DreamOSat IPTV Porn ', 'com_29'))
        list.append(('===================================', 'com'))
        list.append(('(30) OSCam EMU Updater ALL [mipsel,arm] OE2.0 ', 'com_30'))
        list.append(('(31) OSCam EMU Updater dreambox_fpu OE2.0-OE2.5', 'com_31'))
        list.append(('(32) OSCam EMU Updater mips-openpli40 OE2.0', 'com_32'))
        list.append(('(33) OSCam EMU Updater [ARM] dreambox,vuplus,mutant,octagon,gigablue', 'com_33'))
        list.append(('(34) OSCam EMU Updater dm900 LIBUSB OE2.5 ', 'com_34'))
        list.append(('(35) OSCam Updater armV7 (download.oscam.cc) OE2.0 ', 'com_35'))
        list.append(('(36) OSCam EMU Updater mips-tuxbox OE2.0 ', 'com_36'))
        list.append(('(37) OSCam EMU Updater mips-tuxbox OE1.6 ', 'com_37'))
        list.append(('(38) NCam EMU Updater ALL [mipsel,arm] OE2.0 ', 'com_38'))
        list.append(('(39) GCam EMU Updater ALL [mipsel,arm] OE2.0 ', 'com_39'))
        list.append(('===================================', 'com'))
        list.append(('(40) OpenVPNbook.com Free Server #1: Euro1 ', 'com_40'))
        list.append(('(41) OpenVPNbook.com Free Server #2: Euro2 ', 'com_41'))
        list.append(('(42) OpenVPNbook.com Free Server #3: US1 ', 'com_42'))
        list.append(('(43) OpenVPNbook.com Free Server #4: US2 ', 'com_43'))
        list.append(('(44) OpenVPNbook.com Free Server #5: CA (Canada) ', 'com_44'))
        list.append(('(45) OpenVPNbook.com Free Server #6: DE (Germany) ', 'com_45'))
        list.append(('(46) OpenVPNbook.com Free Server #7: FR (France) ', 'com_46'))
        list.append(('===================================', 'com'))
        list.append(('(47) Server Bilgilerimi Yedekle ', 'com_47'))
        list.append(('(48) Settings Yedek Al ', 'com_48'))
        list.append(('(49) Settings chveneburi', 'com_49'))
        list.append(('(50) Satellites.xlm Updater', 'com_50'))
        list.append(('(51) IPTVPlayer Install ', 'com_51'))
        list.append(('(52) INT IPTV www.destek.korax.com ', 'com_52'))
        list.append(('(53) INT 2017 Movies', 'com_53'))
        list.append(('(54) INT 2017 Movies 2', 'com_54'))
#        list.append(('(55) ', 'com_55'))
#        list.append(('(56) ', 'com_56'))
#        list.append(('(57) ', 'com_57'))
#        list.append(('(58) ', 'com_58'))
#        list.append(('(59) ', 'com_59'))
########################### Picon ###########################
        list.append(('===================================', 'com'))
        list.append(('(60) ALL PiconTranparent 220x132 45.0W-85.1E (150.MiB) ', 'com_60'))
        list.append(('(61) PiconTranparent 220x132 42.0E  (8.MB) ', 'com_61'))
        list.append(('(62) PiconTranparent 220x132 13.0E (14.MB) ', 'com_62'))
        list.append(('(63) PiconTranparent 220x132 19.2E  (7.MB) ', 'com_63'))
        list.append(('(64) PiconTranparent 220x132 28.2E  (7.MB) ', 'com_64'))
        list.append(('(65) PiconTranparent 220x132 23.5E  (2.MB) ', 'com_65'))
        list.append(('(66) PiconTranparent 220x132 16.0E  (5.MB) ', 'com_66'))
        list.append(('(67) PiconTranparent 220x132  7.0E  (3.MB) ', 'com_67'))
        list.append(('(68) PiconTranparent 220x132  4.8E  (3.MB) ', 'com_68'))
        list.append(('(69) PiconTranparent 220x132  0.8W  (4.MB) ', 'com_69'))
#=========================================
        list.append(('===================================', 'com'))
        list.append(('(70) PiconTranparent 220x132 45.0W  (2.MB) ', 'com_70'))
        list.append(('(71) PiconTranparent 220x132 30.0W  (3.MB) ', 'com_71'))
        list.append(('(72) PiconTranparent 220x132 27.5W  (1.MB) ', 'com_72'))
        list.append(('(73) PiconTranparent 220x132 24.5W  (1.MB) ', 'com_73'))
        list.append(('(74) PiconTranparent 220x132 22.0W  (1.MB) ', 'com_74'))
        list.append(('(75) PiconTranparent 220x132 15.0W  (1.MB) ', 'com_75'))
        list.append(('(76) PiconTranparent 220x132 14.0W  (1.MB) ', 'com_76'))
        list.append(('(77) PiconTranparent 220x132 12.5W  (1.MB) ', 'com_77'))
        list.append(('(78) PiconTranparent 220x132 11.0W  (1.MB) ', 'com_78'))
        list.append(('(79) PiconTranparent 220x132  8.0W  (3.MB) ', 'com_79'))
        list.append(('(80) PiconTranparent 220x132  7.0W (13.MB) ', 'com_80'))
        list.append(('(81) PiconTranparent 220x132  5.0W  (3.MB) ', 'com_81'))
        list.append(('(82) PiconTranparent 220x132  4.0W  (2.MB) ', 'com_82'))
#===========================================
        list.append(('(83) PiconTranparent 220x132  1.9E  (1.MB) ', 'com_83'))
        list.append(('(84) PiconTranparent 220x132  3.1E  (1.MB) ', 'com_84'))
        list.append(('(85) PiconTranparent 220x132  4.9E  (3.MB) ', 'com_85'))
        list.append(('(86) PiconTranparent 220x132  9.0E  (4.MB) ', 'com_86'))
        list.append(('(87) PiconTranparent 220x132 10.0E  (1.MB) ', 'com_87'))
        list.append(('(88) PiconTranparent 220x132 21.6E  (7.MB) ', 'com_88'))
        list.append(('(89) PiconTranparent 220x132 26.0E  (7.MB) ', 'com_89'))
        list.append(('(90) PiconTranparent 220x132 31.5E  (3.MB) ', 'com_90'))
        list.append(('(91) PiconTranparent 220x132 33.0E  (1.MB) ', 'com_91'))
        list.append(('(92) PiconTranparent 220x132 36.0E  (8.MB) ', 'com_92'))
        list.append(('(93) PiconTranparent 220x132 39.0E  (3.MB) ', 'com_93'))
        list.append(('(94) PiconTranparent 220x132 45.0E  (2.MB) ', 'com_94'))
        list.append(('(95) PiconTranparent 220x132 46.0E  (1.MB) ', 'com_95'))
        list.append(('(96) PiconTranparent 220x132 52.0E  (1.MB) ', 'com_96'))
        list.append(('(97) PiconTranparent 220x132 52.5E  (1.MB) ', 'com_97'))
        list.append(('(98) PiconTranparent 220x132 53.0E  (1.MB) ', 'com_98'))
        list.append(('(99) PiconTranparent 220x132 54.9E  (1.MB) ', 'com_99'))
        list.append(('(100) PiconTranparent 220x132 56.0E (1.MB) ', 'com_100'))
        list.append(('(101) PiconTranparent 220x132 57.0E (1.MB) ', 'com_101'))
        list.append(('(102) PiconTranparent 220x132 62.0E (1.MB) ', 'com_102'))
        list.append(('(103) PiconTranparent 220x132 66.0E (1.MB) ', 'com_103'))
        list.append(('(104) PiconTranparent 220x132 68.5E (3.MB) ', 'com_104'))
        list.append(('(105) PiconTranparent 220x132 70.5E (1.MB) ', 'com_105'))
        list.append(('(106) PiconTranparent 220x132 74.9E (4.MB) ', 'com_106'))
        list.append(('(107) PiconTranparent 220x132 75.0E (4.MB) ', 'com_107'))
        list.append(('(108) PiconTranparent 220x132 85.0E (3.MB) ', 'com_108'))
        list.append(('(109) PiconTranparent 220x132 85.1E (3.MB) ', 'com_109'))
########################### endebar ###########################
        list.append(('===================================', 'com'))
        list.append(('(150) Altin_Fiyatlari ', 'com_150'))
        list.append(('(151) Beinspor_Superlig_ve_1nci_Lig_Mac_Programi ', 'com_151'))
        list.append(('(152) Cccam_to_Oscam ', 'com_152'))
        list.append(('(153) Doviz_Kuru ', 'com_153'))
        list.append(('(154) Ekran_Resmi_Cek ', 'com_154'))
        list.append(('(155) Epg-Turkce_karakter_sorunu_cozumu ', 'com_155'))
        list.append(('(156) FTP_Sifresini_Sifirla ', 'com_156'))
        list.append(('(157) Google_DNS_Ayarla ', 'com_157'))
        list.append(('(158) Hdd_USB_Maunt ', 'com_158'))
        list.append(('(159) Ipk_ve _Tar_gz_Yukleme ', 'com_159'))
        list.append(('(160) Kanal_Ses_Dilini_TR_Yap ', 'com_160'))
        list.append(('(161) Kanal_Yedekleme_ve_Geri_Yukleme ', 'com_161'))
        list.append(('(162) M3u_to_Buket ', 'com_162'))
        list.append(('(163) Mynet_Spor_Haberleri ', 'com_163'))
        list.append(('(164) Satellites_xml_Guncelle - Copy ', 'com_164'))
        list.append(('(165) Son_Dakika_Ekonomi_Haberleri ', 'com_165'))
        list.append(('(166) Son_Dakika_Spor_Haberleri ', 'com_166'))
        list.append(('(167) Son_Depremler ', 'com_167'))
        list.append(('(168) Sozcu_com_tr_Haberleri - Copy ', 'com_168'))
        list.append(('(169) Turkiye_Super_Ligi_Mac_Sonuclari ', 'com_169'))
        list.append(('(170) Ucretli_Iptv_Guncelle ', 'com_170'))

        list.append((_('Exit'), 'exit'))
        Screen.__init__(self, session)
        self['myMenu'] = MenuList(list)
        self['myActionMap'] = ActionMap(['SetupActions'], {'ok': self.go,
         'cancel': self.cancel}, -1)

    def go(self):
        returnValue = self['myMenu'].l.getCurrentSelection()[1]
        print '\n[Myaudi06] returnValue: ' + returnValue + '\n'
        if returnValue is not None:
            if returnValue is 'com_0':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; wget http://dreamosat.net/depo/CaMs-EmU/ReadMe.txt -qO /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/ReadMe.txt > /dev/null; cat /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/ReadMe.txt ; wget http://dreamosat.net/depo/CaMs-EmU/0_INFO.sh -qO /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/0_INFO.sh > /dev/null ;bash /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/0_INFO.sh')
            elif returnValue is 'com_1':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/1_KeyUpdater.sh')
            elif returnValue is 'com_2':
                self.prombt('/bin/echo ; /bin/echo Watching Pay TV without a valid subscription is illegal ; cd /tmp ; /usr/bin/wget -q http://najmsat2018.com/powervu-keys-2/ --header="User-Agent: Mozilla/5.0 (Windows NT 5.1; rv:23.0) Gecko/20100101 Firefox/23.0" &> /dev/null ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/2_PowerVu-keys-all.sh')
            elif returnValue is 'com_3':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/3_OSCam-server_Freecline.com.sh')
            elif returnValue is 'com_4':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/4_OSCam-server_Testious.com.sh')
            elif returnValue is 'com_5':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/5_CCcam-server.sh')
            elif returnValue is 'com_6':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/6_N-Line_Server_Freecline.com.sh')
            elif returnValue is 'com_7':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/7_N-Line_Server_Testious.com.sh')
            elif returnValue is 'com_8':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/8_Key-FreeColor36e.sh')
            elif returnValue is 'com_9':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/9_Key-FreeColor56e.sh')
            elif returnValue is 'com_10':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/10_Ip-adres-ogrenme.sh')
            elif returnValue is 'com_11':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/11_MAC-adres-ogrenme.sh')
            elif returnValue is 'com_12':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/12_Free_Space.sh')
            elif returnValue is 'com_13':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/13_Emu_info.sh')
            elif returnValue is 'com_14':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/14_Delete_all_Crashlogs.sh')
            elif returnValue is 'com_15':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/15_Info_All.sh')
            elif returnValue is 'com_16':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/16_Info_Cpu.sh')
            elif returnValue is 'com_17':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/17_Info_Drivers.sh')
            elif returnValue is 'com_18':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/18_Info_Internet_Ping.sh')
            elif returnValue is 'com_19':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/19_Cccam-to-Oscam-converter.sh')
            elif returnValue is 'com_20':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/20_OE2.5-HDD-Mount.sh')
            elif returnValue is 'com_21':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/21_OE2.5-USB-Mount.sh')
            elif returnValue is 'com_22':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/22_OE2.5-Microcard-Mount.sh')
            elif returnValue is 'com_23':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/23_OE2.5-Iptv-guncelle.sh')
            elif returnValue is 'com_24':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/24_DreamOSat-IPTV-Genel.sh')
            elif returnValue is 'com_25':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/25_DreamOSat-IPTV-Belgesel.sh')
            elif returnValue is 'com_26':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/26_DreamOSat-IPTV-Spor.sh')
            elif returnValue is 'com_27':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/27_DreamOSat-IPTV-Sinema.sh')
            elif returnValue is 'com_28':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/28_DreamOSat-IPTV-Music.sh')
            elif returnValue is 'com_29':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/29_DreamOSat-IPTV-Porn.sh')
            elif returnValue is 'com_30':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/30_OSCam_Updater_ALL.sh')
            elif returnValue is 'com_31':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/31_OSCam_Updater_dreambox_fpu.sh')
            elif returnValue is 'com_32':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/32_OSCam_Updater_mips-openpli40.sh')
            elif returnValue is 'com_33':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/33_OSCam_Updater_arm.sh')
            elif returnValue is 'com_34':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/34_OSCam_Updater_dm900-libusb.sh')
            elif returnValue is 'com_35':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/35_OSCam-svn_Updater_armV7.sh')
            elif returnValue is 'com_36':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/36_OSCam_Updater_mips-tuxbox-oe2.0.sh')
            elif returnValue is 'com_37':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/37_OSCam_Updater_mips-tuxbox-oe1.6.sh')
            elif returnValue is 'com_38':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/38_NCam_Updater_ALL.sh')
            elif returnValue is 'com_39':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/39_GCam_Updater_ALL.sh')
################################### OpenVPN ###############################
            elif returnValue is 'com_40':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/40_OpenVPN-Free_VPNbook.com-Server1-Euro1.sh')
            elif returnValue is 'com_41':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/41_OpenVPN-Free_VPNbook.com-Server2-Euro2.sh')
            elif returnValue is 'com_42':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/42_OpenVPN-Free_VPNbook.com-Server3-US1.sh')
            elif returnValue is 'com_43':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/43_OpenVPN-Free_VPNbook.com-Server4-US2.sh')
            elif returnValue is 'com_44':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/44_OpenVPN-Free_VPNbook.com-Server5-CA.sh')
            elif returnValue is 'com_45':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/45_OpenVPN-Free_VPNbook.com-Server6-DE.sh')
            elif returnValue is 'com_46':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/46_OpenVPN-Free_VPNbook.com-Server7-FR.sh')
###################################  ###############################
            elif returnValue is 'com_47':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/47_Server-Bilgilerimi-Yedekle.sh')
            elif returnValue is 'com_48':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/48_Settings-Yedek-Al.sh')
            elif returnValue is 'com_49':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/49_Settings-chveneburi.sh')
            elif returnValue is 'com_50':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/50_Satellites-guncelle.sh')
            elif returnValue is 'com_51':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/51_IPTVPlayer.sh')
            elif returnValue is 'com_52':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/52_INT_IPTV-destek.korax.com.sh')
            elif returnValue is 'com_53':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/53_INT_2017_Movies.sh')
            elif returnValue is 'com_54':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/54_INT_2017_Movies.sh')
#            elif returnValue is 'com_55':
#                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/')
#            elif returnValue is 'com_56':
#                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/')
#            elif returnValue is 'com_57':
#                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/')
#            elif returnValue is 'com_58':
#                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/')
#            elif returnValue is 'com_59':
#                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/')
################################### Picon ###############################
            elif returnValue is 'com_60':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/60_ALL-picontranparent-220x132-45.0W-85.1E.sh')
            elif returnValue is 'com_61':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/61_picontranparent-220x132-42.0E.sh')
            elif returnValue is 'com_62':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/62_picontranparent-220x132-13.0E.sh')
            elif returnValue is 'com_63':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/63_picontranparent-220x132-19.2E.sh')
            elif returnValue is 'com_64':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/64_picontranparent-220x132-28.2E.sh')
            elif returnValue is 'com_65':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/65_picontranparent-220x132-23.5E.sh')
            elif returnValue is 'com_66':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/66_picontranparent-220x132-16.0E.sh')
            elif returnValue is 'com_67':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/67_picontranparent-220x132-7.0E.sh')
            elif returnValue is 'com_68':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/68_picontranparent-220x132-4.8E.sh')
            elif returnValue is 'com_69':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/69_picontranparent-220x132-0.8W.sh')
            elif returnValue is 'com_70':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/70_picontranparent-220x132-45.0W.sh')
            elif returnValue is 'com_71':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/71_picontranparent-220x132-30.0W.sh')
            elif returnValue is 'com_72':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/72_picontranparent-220x132-27.5W.sh')
            elif returnValue is 'com_73':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/73_picontranparent-220x132-24.5W.sh')
            elif returnValue is 'com_74':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/74_picontranparent-220x132-22.0W.sh')
            elif returnValue is 'com_75':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/75_picontranparent-220x132-15.0W.sh')
            elif returnValue is 'com_76':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/76_picontranparent-220x132-14.0W.sh')
            elif returnValue is 'com_77':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/77_picontranparent-220x132-12.5W.sh')
            elif returnValue is 'com_78':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/78_picontranparent-220x132-11.0W.sh')
            elif returnValue is 'com_79':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/79_picontranparent-220x132-8.0W.sh')
            elif returnValue is 'com_80':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/80_picontranparent-220x132-7.0W.sh')
            elif returnValue is 'com_81':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/81_picontranparent-220x132-5.0W.sh')
            elif returnValue is 'com_82':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/82_picontranparent-220x132-4.0W.sh')
            elif returnValue is 'com_83':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/83_picontranparent-220x132-1.9E.sh')
            elif returnValue is 'com_84':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/84_picontranparent-220x132-3.1E.sh')
            elif returnValue is 'com_85':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/85_picontranparent-220x132-4.9E.sh')
            elif returnValue is 'com_86':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/86_picontranparent-220x132-9.0E.sh')
            elif returnValue is 'com_87':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/87_picontranparent-220x132-10.0E.sh')
            elif returnValue is 'com_88':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/88_picontranparent-220x132-21.6E.sh')
            elif returnValue is 'com_89':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/89_picontranparent-220x132-26.0E.sh')
            elif returnValue is 'com_90':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/90_picontranparent-220x132-31.5E.sh')
            elif returnValue is 'com_91':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/91_picontranparent-220x132-33.0E.sh')
            elif returnValue is 'com_92':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/92_picontranparent-220x132-36.0E.sh')
            elif returnValue is 'com_93':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/93_picontranparent-220x132-39.0E.sh')
            elif returnValue is 'com_94':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/94_picontranparent-220x132-45.0E.sh')
            elif returnValue is 'com_95':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/95_picontranparent-220x132-46.0E.sh')
            elif returnValue is 'com_96':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/96_picontranparent-220x132-52.0E.sh')
            elif returnValue is 'com_97':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/97_picontranparent-220x132-52.5E.sh')
            elif returnValue is 'com_98':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/98_picontranparent-220x132-53.0E.sh')
            elif returnValue is 'com_99':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/99_picontranparent-220x132-54.9E.sh')
            elif returnValue is 'com_100':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/106_picontranparent-220x132-56.0E.sh')
            elif returnValue is 'com_101':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/100_picontranparent-220x132-57.0E.sh')
            elif returnValue is 'com_102':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/101_picontranparent-220x132-62.0E.sh')
            elif returnValue is 'com_103':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/102_picontranparent-220x132-66.0E.sh')
            elif returnValue is 'com_104':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/103_picontranparent-220x132-68.5E.sh')
            elif returnValue is 'com_105':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/104_picontranparent-220x132-70.5E.sh')
            elif returnValue is 'com_106':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/105_picontranparent-220x132-74.9E.sh')
            elif returnValue is 'com_107':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/107_picontranparent-220x132-75.0E.sh')
            elif returnValue is 'com_108':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/107_picontranparent-220x132-85.0E.sh')
            elif returnValue is 'com_109':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/107_picontranparent-220x132-85.1E.sh')

################################### endebar script ###############################
            elif returnValue is 'com_150':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/endebar/Altin_Fiyatlari.sh')
            elif returnValue is 'com_151':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/endebar/Beinspor_Superlig_ve_1nci_Lig_Mac_Programi.sh')
            elif returnValue is 'com_152':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/endebar/Cccam_to_Oscam.sh')
            elif returnValue is 'com_153':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/endebar/Doviz_Kuru.sh')
            elif returnValue is 'com_154':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/endebar/Ekran_Resmi_Cek.sh')
            elif returnValue is 'com_155':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/endebar/Epg-Turkce_karakter_sorunu_cozumu.sh')
            elif returnValue is 'com_156':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/endebar/FTP_Sifresini_Sifirla.sh')
            elif returnValue is 'com_157':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/endebar/Google_DNS_Ayarla.sh')
            elif returnValue is 'com_158':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/endebar/Hdd_USB_Maunt.sh')
            elif returnValue is 'com_159':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/endebar/Ipk_ve _Tar_gz_Yukleme.sh')
            elif returnValue is 'com_160':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/endebar/Kanal_Ses_Dilini_TR_Yap.sh')
            elif returnValue is 'com_161':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/endebar/Kanal_Yedekleme_ve_Geri_Yukleme.sh')
            elif returnValue is 'com_162':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/endebar/M3u_to_Buket.sh')
            elif returnValue is 'com_163':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/endebar/Mynet_Spor_Haberleri.sh')
            elif returnValue is 'com_164':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/endebar/Satellites_xml_Guncelle-Copy.sh')
            elif returnValue is 'com_165':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/endebar/Son_Dakika_Ekonomi_Haberleri.sh')
            elif returnValue is 'com_166':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/endebar/Son_Dakika_Spor_Haberleri.sh')
            elif returnValue is 'com_167':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/endebar/Son_Depremler.sh')
            elif returnValue is 'com_168':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/endebar/Sozcu_com_tr_Haberleri-Copy.sh')
            elif returnValue is 'com_169':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/endebar/Turkiye_Super_Ligi_Mac_Sonuclari.sh')
            elif returnValue is 'com_170':
                self.prombt('/bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/endebar/Ucretli_Iptv_Guncelle.sh')

            else:
                print '\n[Myaudi06] cancel\n'
                self.close(None)

    def prombt(self, com):
        self.session.open(Console, _('start shell com: %s') % com, ['%s' % com])

    def cancel(self):
        print '\n[Myaudi06] cancel\n'
        self.close(None)


def main(session, **kwargs):
    print '\n[Myaudi06] start\n'
    session.open(Myaudi06)


def Plugins(**kwargs):
    return [
	PluginDescriptor(name='DreamOSatScript',
	description=_("console bash shell script")+ " (" + VERSION + ")",
	where=PluginDescriptor.WHERE_PLUGINMENU, icon='plugin.png', fnc=main), 

	PluginDescriptor(name='DreamOSatScript', 
	description=_("console bash shell script")+ " (" + VERSION + ")",
	where=PluginDescriptor.WHERE_EXTENSIONSMENU, icon='plugin.png', fnc=main)]


