#!/bin/sh
#Created By audi06_19 @https://dreamosat-forum.com
echo ""
echo "Kanal Listenizin yedeği Alınıyor...";
echo "Lütfen Bekleyin";
DATE=$(date +%Y-%m-%d_%H%M%S)
echo "";
[ -d /media/hdd/backup ] || mkdir -p /media/hdd/backup
cd /;
echo "";
tar -czvf enigma2-settings-backup-$DATE.tar.gz /etc/enigma2/*tv /etc/enigma2/*radio /etc/enigma2/blacklist /etc/enigma2/lamedb /etc/enigma2/whitelist /etc/tuxbox/satellites.xml > /dev/null 2>&1
echo "";
mv enigma2-settings-backup-$DATE.tar.gz /media/hdd/backup > /dev/null 2>&1
echo "";
chmod 644 /media/hdd/backup/enigma2-settings-backup-$DATE.tar.gz > /dev/null 2>&1
echo "";
echo "Kanal Listenizin yedeği Alındı, HDD içerisine yazıldı ...";
echo ""
echo "iyi seyirler...";
echo "";
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*             << audi06_19 >>             *";
echo "*  ..:: https://dreamosat-forum.com ::..  *";
echo "*******************************************";
sleep 1;
exit 0
