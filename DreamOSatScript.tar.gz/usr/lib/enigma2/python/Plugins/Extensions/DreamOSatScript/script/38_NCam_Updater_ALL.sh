#!/bin/sh
#Created By audi06_19 @https://dreamosat-forum.com 2017
FIN="==================================================="
echo $FIN
echo ".....:: LÜTFEN BEKLEYİNİZ .... PLEASE WAIT ::....."
STOP1=$(ps -A | awk '/NCam*/{print $4}')
STOP2=$(ps -A | awk '/Ncam*/{print $4}')
STOP3=$(ps -A | awk '/ncam*/{print $4}')
sleep 1;
echo $FIN
echo ":Yüklü NCamlar Aranıyor..."
echo ":Searching for installed NCam ..."
sleep 1;
echo $FIN
echo ":NCam Dosya yolları..."
echo ":NCam File Paths ..."
echo $FIN
find /usr/bin/ -iname ncam*
sleep 1;
echo $FIN
echo ":Çalışan NCamlar..."
echo ":Working NCams ..."
sleep 1;
ps -A | awk '/NCam*/{print $4}'
ps -A | awk '/Ncam*/{print $4}'
ps -A | awk '/ncam*/{print $4}'
sleep 1;
echo $FIN
echo ":NCam Stop"
killall /usr/bin/$STOP1 2>/dev/null
killall /usr/bin/$STOP2 2>/dev/null
killall /usr/bin/$STOP3 2>/dev/null
sleep 1;
##################################################################################################
[ -d /tmp/DreamOSat ] || mkdir -p /tmp/DreamOSat > /dev/null;
[ -d /usr/camscript ] || mkdir -p /usr/camscript > /dev/null;
sleep 1;
echo $FIN
echo ":Cihazınızın işlemcisini kontrol ediyorum..."
echo ":I'm checking your device's processor ..."
uname -m >> /tmp/DreamOSat/name.txt
sleep 1;
if grep -qs 'armv7l' cat /tmp/DreamOSat/name.txt ; then
	sleep 1;
	echo $FIN
	echo ":ARM işlemci kullandığınızı tespit ettim... :)"
	echo ":I have detected that you are using an ARM processor ... :)"
	www="http://oscam.dreamosat.net/index.php?&direction=0&order=mod&directory=1.20_NCAM-EMU/arm_dm900-solo4k&"
	wget $www -q -O /tmp/ncam.info
	sleep 1;
	version=$(cat /tmp/ncam.info | grep -A 32 "archives" | grep ".cortexa9hf-vfp-neon.zip"|sed 's/[ ][ ]*/'/g''|cut -b 31-33)
	LINK='http://oscam.dreamosat.net/index.php?action=downloadfile&filename=ncam-'$version'.cortexa9hf-vfp-neon.zip&directory=1.20_NCAM-EMU/arm_dm900-solo4k&'
	sleep 1;
	echo $FIN
	echo ":Kopyalanıyor ARM NCam_r$version"
	echo ":Copying ARM NCam_r$version"
	wget $LINK -q -O /tmp/NcamUpdate-audi06_19.zip
	[ -e /tmp/ncam.info ] && rm /tmp/ncam.info
	unzip /tmp/NcamUpdate-audi06_19.zip -d /tmp/ > /dev/null;
#	[ -e /tmp/*-arm_dream-list_smargo ] && rm /tmp/*-arm_dream-list_smargo
	mv /tmp/ncam* /tmp/NCam_r$version
	[ -e /usr/bin/NCam_r* ] && rm -rf /usr/bin/NCam_r*
	[ -e /usr/camscript/NCam_r$version ] && rm -rf /usr/camscript/NCam_r$version
sleep 1;
echo $FIN
echo ":Kopyalandı ARM NCam_$version /usr/bin"
echo ":Copied ARM NCam_$version /usr/bin"
	cp -rf /tmp/NCam_r$version /usr/bin/NCam_r$version
#	[ -e /tmp/doc ] && rm -rf /tmp/doc 
#	[ -e /tmp/ncam.info ] && rm /tmp/ncam.info 
	[ -e /tmp/NcamUpdate-audi06_19.zip ] && rm /tmp/NcamUpdate-audi06_19.zip
	[ -e /tmp/NCam_r$version ] && rm /tmp/NCam_r$version
#	[ -e /tmp/CHANGES ] && rm /tmp/CHANGES
	[ -e /usr/camscript/NCam_r* ] && rm -rf /usr/camscript/NCam_r*
sleep 1;
echo $FIN
dest="/usr/camscript/NCam_r$version.sh"
echo ":NCam_r$version için Script oluşturuluyor... "$dest
echo ":Creating Script for NCam_r$version ... "$dest
echo -e "#!/bin/sh" > $dest
echo -e "" >> $dest
echo -e "CAM=\0042NCam_r$version\0042" >> $dest
echo -e "OSD=\0042NCam r$version\0042" >> $dest
echo -e "PID=\0044CAM" >> $dest
echo -e "Action=\00441" >> $dest
echo -e "" >> $dest
echo -e "cam_clean () {" >> $dest
echo -e "		rm -rf /tmp/*.info*	/tmp/.oscam /tmp/*.pid" >> $dest
echo -e "}" >> $dest
echo -e "" >> $dest
echo -e "cam_handle () {" >> $dest
echo -e "		if test	-z \0042\0044{PID}\0042	; then" >> $dest
echo -e "				cam_up;" >> $dest
echo -e "		else" >> $dest
echo -e "				cam_down;" >> $dest
echo -e "		fi;" >> $dest
echo -e "}" >> $dest
echo -e "" >> $dest
echo -e "cam_down ()	{" >> $dest
echo -e "		killall	-9 \0044CAM 2>/dev/null" >> $dest
echo -e "		sleep 2" >> $dest
echo -e "		cam_clean" >> $dest
echo -e "}" >> $dest
echo -e "" >> $dest
echo -e "cam_up () {" >> $dest
echo -e "		/usr/bin/\0044CAM -c /etc/tuxbox/config/ncam &" >> $dest
echo -e "}" >> $dest
echo -e "" >> $dest
echo -e "if test	\0042\0044Action\0042 =	\0042cam_startup\0042 ;	then" >> $dest
echo -e "	if test	-z \0042\0044{PID}\0042 ; then" >> $dest
echo -e "		cam_down" >> $dest
echo -e "		cam_up" >> $dest
echo -e "	else" >> $dest
echo -e "		echo \0042\0044CAM already running, exiting...\0042" >> $dest
echo -e "	fi" >> $dest
echo -e "elif test	\0042\0044Action\0042 =	\0042cam_res\0042 ;	then" >> $dest
echo -e "		cam_down" >> $dest
echo -e "		cam_up" >> $dest
echo -e "elif test \0042\0044Action\0042	= \0042cam_down\0042 ; then" >> $dest
echo -e "		cam_down" >> $dest
echo -e "elif test \0042\0044Action\0042	= \0042cam_up\0042 ; then" >> $dest
echo -e "		cam_up" >> $dest
echo -e "else" >> $dest
echo -e "		cam_handle" >> $dest
echo -e "fi" >> $dest
echo -e "" >> $dest
echo -e "exit 0" >> $dest
sleep 1;
chmod 755 $dest > /dev/null;
chmod 755 /usr/bin/NCam_r$version > /dev/null;
sleep 1;
echo $FIN
echo ":Güncel NCam r$version indirildi"
echo ":Updated NCam r$version downloaded"
sleep 1;
echo $FIN
echo ":En Yeni NCam çalıştırılmaya hazır"
echo ":The latest NCam is ready to run"
sleep 1;
echo $FIN
echo ":== DİKKAT ==>... DreamOSat camManager açın ve NCam r$version çalıştırın..."
echo ":== ATTENTION ==>... Open DreamOSat camManager and run NCam r$version ..."
else
uname -m >> /tmp/DreamOSat/name2.txt
sleep 1;
if grep -qs 'mips' cat /tmp/DreamOSat/name2.txt ; then
	sleep 1;
	echo $FIN
	echo ":MIPS işlemci kullandığınızı tespit ettim... :)"
	echo ":I have detected that you are using an MIPS processor ... :)"
	www="http://oscam.dreamosat.net/index.php?&direction=0&order=mod&directory=1.20_NCAM-EMU/mips-tuxbox-oe2.0"
	wget $www -q -O /tmp/ncam.info
	sleep 1;
	version=$(cat /tmp/ncam.info | grep -A 32 "archives" | grep ".mips.zip"|sed 's/[ ][ ]*/'/g''|cut -b 31-33)
	LINK='http://oscam.dreamosat.net/index.php?action=downloadfile&filename=ncam-'$version'.mips.zip&directory=1.20_NCAM-EMU/mips-tuxbox-oe2.0&'
	sleep 1;
	echo $FIN
	echo ":Kopyalanıyor MIPS NCam_r$version"
	echo ":Copying MIPS NCam_r$version"
	wget $LINK -q -O /tmp/NcamUpdate-audi06_19.zip > /dev/null;
	[ -e /tmp/ncam.info ] && rm /tmp/ncam.info
	unzip /tmp/NcamUpdate-audi06_19.zip -d /tmp/ > /dev/null;
#	[ -e /tmp/*-arm_dream-list_smargo ] && rm /tmp/*-arm_dream-list_smargo
	mv /tmp/ncam* /tmp/NCam_r$version
	[ -e /usr/bin/NCam_r* ] && rm -rf /usr/bin/NCam_r*
	[ -e /usr/camscript/NCam_r$version ] && rm -rf /usr/camscript/NCam_r$version
sleep 1;
echo $FIN
echo ":Kopyalandı MIPS NCam_$version /usr/bin"
echo ":Copied MIPS NCam_$version /usr/bin"
	cp -rf /tmp/NCam_r$version /usr/bin/NCam_r$version
#	[ -e /tmp/doc ] && rm -rf /tmp/doc 
#	[ -e /tmp/ncam.info ] && rm /tmp/ncam.info 
	[ -e /tmp/NcamUpdate-audi06_19.zip ] && rm /tmp/NcamUpdate-audi06_19.zip
	[ -e /tmp/NCam_r$version ] && rm /tmp/NCam_r$version
#	[ -e /tmp/CHANGES ] && rm /tmp/CHANGES
	[ -e /usr/camscript/NCam_r* ] && rm -rf /usr/camscript/NCam_r*
sleep 1;
echo $FIN
dest="/usr/camscript/NCam_r$version.sh"
echo ":NCam_r$version için Script oluşturuluyor... "$dest
echo ":Creating Script for NCam_r$version ... "$dest
echo -e "#!/bin/sh" > $dest
echo -e "" >> $dest
echo -e "CAM=\0042NCam_r$version\0042" >> $dest
echo -e "OSD=\0042NCam r$version\0042" >> $dest
echo -e "PID=\0044CAM" >> $dest
echo -e "Action=\00441" >> $dest
echo -e "" >> $dest
echo -e "cam_clean () {" >> $dest
echo -e "		rm -rf /tmp/*.info*	/tmp/.oscam /tmp/*.pid" >> $dest
echo -e "}" >> $dest
echo -e "" >> $dest
echo -e "cam_handle () {" >> $dest
echo -e "		if test	-z \0042\0044{PID}\0042	; then" >> $dest
echo -e "				cam_up;" >> $dest
echo -e "		else" >> $dest
echo -e "				cam_down;" >> $dest
echo -e "		fi;" >> $dest
echo -e "}" >> $dest
echo -e "" >> $dest
echo -e "cam_down ()	{" >> $dest
echo -e "		killall	-9 \0044CAM 2>/dev/null" >> $dest
echo -e "		sleep 2" >> $dest
echo -e "		cam_clean" >> $dest
echo -e "}" >> $dest
echo -e "" >> $dest
echo -e "cam_up () {" >> $dest
echo -e "		/usr/bin/\0044CAM -c /etc/tuxbox/config/ncam &" >> $dest
echo -e "}" >> $dest
echo -e "" >> $dest
echo -e "if test	\0042\0044Action\0042 =	\0042cam_startup\0042 ;	then" >> $dest
echo -e "	if test	-z \0042\0044{PID}\0042 ; then" >> $dest
echo -e "		cam_down" >> $dest
echo -e "		cam_up" >> $dest
echo -e "	else" >> $dest
echo -e "		echo \0042\0044CAM already running, exiting...\0042" >> $dest
echo -e "	fi" >> $dest
echo -e "elif test	\0042\0044Action\0042 =	\0042cam_res\0042 ;	then" >> $dest
echo -e "		cam_down" >> $dest
echo -e "		cam_up" >> $dest
echo -e "elif test \0042\0044Action\0042	= \0042cam_down\0042 ; then" >> $dest
echo -e "		cam_down" >> $dest
echo -e "elif test \0042\0044Action\0042	= \0042cam_up\0042 ; then" >> $dest
echo -e "		cam_up" >> $dest
echo -e "else" >> $dest
echo -e "		cam_handle" >> $dest
echo -e "fi" >> $dest
echo -e "" >> $dest
echo -e "exit 0" >> $dest
sleep 1;
chmod 755 $dest > /dev/null;
chmod 755 /usr/bin/NCam_r$version > /dev/null;
sleep 1;
echo $FIN
echo ":Güncel NCam r$version indirildi"
echo ":Updated NCam r$version downloaded"
sleep 1;
echo $FIN
echo ":En Yeni NCam çalıştırılmaya hazır"
echo ":The latest NCam is ready to run"
sleep 1;
echo $FIN
echo ":== DİKKAT ==>... DreamOSat camManager açın ve NCam r$version çalıştırın..."
echo ":== ATTENTION ==>... Open DreamOSat camManager and run NCam r$version ..."
else
sleep 1;
echo $FIN
echo "Üzgünüm, cihazınıza uygun NCam yok :("
echo "Sorry, your device does not have the proper NCam :("
fi
fi
rm -rf /tmp/DreamOSat > /dev/null;
sleep 1;
echo "";
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*             << audi06_19 >>             *";
echo "*  ..:: https://dreamosat-forum.com ::..  *";
echo "*******************************************";
sleep 2
exit 0
