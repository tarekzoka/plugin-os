#!/bin/sh
#Created By audi06_19 @https://dreamosat-forum.com
echo ""
[ -d /media/hdd/backup ] || mkdir -p /media/hdd/backup
cd /;
echo "Server yedeği Alınıyor...";
echo "Lütfen Bekleyin";
DATE=$(date +%Y-%m-%d_%H%M%S)

CONFIG="/etc/tuxbox/config"
KEYS="/usr/keys"
ETC="/etc/CCcam.cfg"
echo "";
tar -czvf enigma2-server-backup-$DATE.tar.gz $CONFIG $KEYS $ETC > /dev/null 2>&1
echo "";
mv enigma2-server-backup-$DATE.tar.gz /media/hdd/backup > /dev/null 2>&1
echo "";
chmod 644 /media/hdd/backup/enigma2-server-backup-$DATE.tar.gz > /dev/null 2>&1
echo "";
echo "Server yedeği yedeği Alındı, media/hdd/backup içerisine yazıldı ...";
echo ""
echo "iyi seyirler...";
echo "";
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*             << audi06_19 >>             *";
echo "*  ..:: https://dreamosat-forum.com ::..  *";
echo "*******************************************";
sleep 1;
exit 0
