#!/bin/sh
#Created By audi06_19 @https://dreamosat-forum.com
FIN="=================================================="
echo $FIN
echo ".....:: LÜTFEN BEKLEYİNİZ .... PLEASE WAIT ::....."
echo $FIN
systemctl disable enigma2-iptv-start.service;
sleep 2;
echo "systemctl disable enigma2-iptv";
cd /lib/systemd/system;
rm -rf enigma2-iptv-start.service;
cat > enigma2-iptv-start.service << EOF
[Unit]
Before=enigma2.service
After=network-online.target

[Service]
Type=forking
ExecStart=/bin/sh /etc/enigma2/iptv.sh > /dev/null 2>&1 &
NonBlocking=true
NotifyAccess=main

[Install]
WantedBy=multi-user.target
EOF
chmod 755 enigma2-iptv-start.service;
cd /;
echo "";
systemctl enable enigma2-iptv-start.service
sleep 2;
echo "systemctl enable enigma2-iptv";
echo $FIN
echo "Uydu alıcınızı yeniden başlattığınızda IPTV'niz güncellenecektir. iyi seyirler...";
echo "Your IPTV will be updated when you restart your satellite receiver. good looking ...";
echo "";
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*             << audi06_19 >>             *";
echo "*  ..:: https://dreamosat-forum.com ::..  *";
echo "*******************************************";
sleep 1;
exit 0
