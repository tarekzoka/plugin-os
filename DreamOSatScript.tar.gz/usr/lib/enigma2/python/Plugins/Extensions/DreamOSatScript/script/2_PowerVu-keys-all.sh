#!/bin/bash
#Created By audi06_19 @https://dreamosat-forum.com
FIN="=================================================="
echo ".....:: LÜTFEN BEKLEYİNİZ .... PLEASE WAIT ::....."
cd /;
rm -rf /tmp/keyupdate;
[ -d /usr/keys ] || mkdir -p /usr/keys;
[ -d /etc/tuxbox/config ] || mkdir -p /etc/tuxbox/config;
[ -d /etc/tuxbox/config/ncam ] || mkdir -p /etc/tuxbox/config/ncam;
[ -d /tmp/keyupdate ] || mkdir -p /tmp/keyupdate;
wget http://dreamosat.net/depo/CaMs-EmU/SoftCam-2.Key -qO /tmp/keyupdate/SoftCam.Key > /dev/null;
chmod 0755 /tmp/keyupdate/ -R;
cd /tmp/keyupdate;
cp -rd SoftCam.Key /usr/keys/ > /dev/null;
cp -rd SoftCam.Key /etc/tuxbox/config/ > /dev/null;
cp -rd SoftCam.Key /etc/tuxbox/config/ncam/ > /dev/null;
cd /;
rm -rf /tmp/keyupdate;
echo $FIN
################################################# FIND-SOFTCAM #################################################
> /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/PowerVu/Your-Softcam-Key-Location
find /usr /var/ /etc -iname Softcam.key > /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/PowerVu/Your-Softcam-Key-Location
        echo "Cihazınızda yüklü SoftCam.Key dosyalarını arıyorum..."
        echo "I'am looking for your SoftCam.Key file/s hold on a sec"

if [ -s /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/PowerVu/Your-Softcam-Key-Location ]
then
	echo $FIN
        echo "Aşağıdaki konumda SoftCam.Key dosyanızı buldum ;)"
        echo "Found SoftCam.Key file/s in the following location/s ;)"
	echo $FIN
        cat /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/PowerVu/Your-Softcam-Key-Location
else
        echo $FIN
        echo "Cihazınızda yüklü SoftCam.Key dosyası yok ????"
        echo "I can't find your SoftCam.Key file have you got one ????"
        echo $FIN
        echo "etc/tuxbox/config/ içerisine SoftCam.Key dosyası oluşturuyorum..."
        echo "I am creating an SoftCam.Key file in etc/tuxbox/config/ ..."
fi
echo $FIN
################################################################################################################
#################################################### AUKEYS ####################################################
if [ -s /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/PowerVu/Your-Softcam-Key-Location ]
then
        echo "SoftCam.Key dosyasını buldum"
        echo "I found your SoftCam.Key file ;) "
	echo $FIN
else
        echo
        echo "SoftCam.Key dosyasını bulamıyorum ;("
        echo "I can't find your SoftCam.Key ;("
	echo $FIN
        exit 0
fi

while read line
do
sed -i '/AU KEYS/,/AU KEYS end/d' $line
echo "########################### AU KEYS #########################" >> $line
cat /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/PowerVu/.au >> $line
echo "########################### AU KEYS end #####################" >> $line
done < /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/PowerVu/Your-Softcam-Key-Location

echo "OSCAM'I YENİDEN YENİDEN BAŞLATIN (ALL AU) KEYS GÜNCELLENDİ"
echo "PLEASE RESTART OSCAM (ALL AU) KEYS UPDATED"

echo $FIN
################################################################################################################
##################################################### AFN ######################################################
> new
> tosort
> SoftCam.Key.AFN
sed -e 's/<[^>]*>//g' /tmp/index.html > new
#grep -A2 -i 003E7E84 new > tosort
grep -A3 -i 003E7E84 new > tosort
#grep -i "KEY0" tosort  | sed '/^$/d;s/[[:blank:]]//g' | cut -f 2 -d ':' | cut -f 1 -d '&' > 00
#grep -i "KEY1" tosort  | sed '/^$/d;s/[[:blank:]]//g' | cut -f 2 -d ':' | cut -f 1 -d '&' > 01
grep -i 'P 0000 00' tosort | cut -f 2 -d ':' | sed '/^$/d;s/[[:blank:]]//g' | sed -e 's/^\(.\{21\}\).*/\1/' > 00
grep -i 'P 0000 01' tosort | cut -f 2 -d ':' | sed '/^$/d;s/[[:blank:]]//g' | sed -e 's/^\(.\{21\}\).*/\1/' > 01

sed -i 's/P000000 //g' 00
sed -i 's/P000000//g' 00
sed -i 's/P000001 //g' 01
sed -i 's/P000001//g' 01

while read line
do
cat 00 | sed "s/^/P $line 00 /g" >> SoftCam.Key.AFN.tmp
cat 01 | sed "s/^/P $line 01 /g" >> SoftCam.Key.AFN.tmp
done < /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/PowerVu/sids/P_AFN
rm tosort new 00 01 
echo "################# AFN KEYs added by POWERVU_KEY_UPDATER #################" >> SoftCam.Key.AFN
cat SoftCam.Key.AFN.tmp | grep ^P | cut -c 1-28 >> SoftCam.Key.AFN
echo "################# AFN KEYs end #################" >> SoftCam.Key.AFN
rm SoftCam.Key.AFN.tmp

while read line
do
sed -i '/AFN KEYs added/,/AFN KEYs end/d' $line
cat SoftCam.Key.AFN >> $line
done < /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/PowerVu/Your-Softcam-Key-Location
rm SoftCam.Key.AFN

echo "Eutelsat 9.0°E 11766-V-27500 & 11804-V-27500"
echo "OSCAM'I YENİDEN YENİDEN BAŞLATIN (AFN) KEYS GÜNCELLENDİ"
echo "PLEASE RESTART OSCAM (AFN) KEYS UPDATED"

echo $FIN
################################################################################################################
################################################# DISCOVERY-1W #################################################
> new
> tosort
> SoftCam.Key.Discovery-Networks
sed -e 's/<[^>]*>//g' /tmp/index.html > new
grep -B2 -i 00623910 new > tosort
grep -i 'P 0000 00' tosort | cut -f 2 -d ':' | sed '/^$/d;s/[[:blank:]]//g' | sed -e 's/^\(.\{23\}\).*/\1/' > 00
grep -i 'P 0000 01' tosort | cut -f 2 -d ':' | sed '/^$/d;s/[[:blank:]]//g' | sed -e 's/^\(.\{23\}\).*/\1/' > 01

sed -i 's/P000000 //g' 00
sed -i 's/P000000//g' 00
sed -i 's/P000001 //g' 01
sed -i 's/P000001//g' 01

while read line
do
cat 00 | sed "s/^/P $line 00 /g" >> SoftCam.Key.Discovery-Networks.tmp
cat 01 | sed "s/^/P $line 01 /g" >> SoftCam.Key.Discovery-Networks.tmp
done < /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/PowerVu/sids/P_Discovery-1W
sed -i 's/  / /g' SoftCam.Key.Discovery-Networks
rm tosort new 00 01
echo "################# Discovery-Networks KEYs added by POWERVU_KEY_UPDATER #################" >> SoftCam.Key.Discovery-Networks
cat SoftCam.Key.Discovery-Networks.tmp | grep ^P | cut -c 1-28 >> SoftCam.Key.Discovery-Networks
echo "################# Discovery-Networks KEYs end #################" >> SoftCam.Key.Discovery-Networks
rm SoftCam.Key.Discovery-Networks.tmp

while read line
do
sed -i '/Discovery-Networks KEYs added/,/Discovery-Networks KEYs end/d' $line
cat SoftCam.Key.Discovery-Networks >> $line
done < /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/PowerVu/Your-Softcam-Key-Location
rm SoftCam.Key.Discovery-Networks

echo "Thor1°W- 12303-V-27500  0  &  Astra 4.8°E 12360V 27500"
echo "OSCAM'I YENİDEN YENİDEN BAŞLATIN (Discovery Networks) KEYS GÜNCELLENDİ"
echo "PLEASE RESTART OSCAM (Discovery Networks) KEYS UPDATED"

echo $FIN
################################################################################################################
############################################### DISCOVERY-EUROPE ###############################################
# wget http://najmsat2018.com/powervu-keys-2/
> new
> tosort
> SoftCam.Key.Euro
sed -e 's/<[^>]*>//g' /tmp/index.html > new
echo "################# EURO KEYs added by POWERVU_KEY_UPDATER #################" >> SoftCam.Key.Euro
grep -A7 -i "DISCOVERY EUROPE" new > tosort
grep -i 'P 0000 00' tosort | cut -f 2 -d ':' | sed '/^$/d;s/[[:blank:]]//g' | sed -e 's/^\(.\{23\}\).*/\1/' > 00
grep -i 'P 0000 01' tosort | cut -f 2 -d ':' | sed '/^$/d;s/[[:blank:]]//g' | sed -e 's/^\(.\{23\}\).*/\1/' > 01

sed -i 's/P000000 //g' 00
sed -i 's/P000000//g' 00
sed -i 's/P000001 //g' 01
sed -i 's/P000001//g' 01

while read line
do
cat 00 | sed "s/^/P $line 00 /g" >> SoftCam.Key.Euro
cat 01 | sed "s/^/P $line 01 /g" >> SoftCam.Key.Euro
done < /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/PowerVu/sids/P_Discovery-Networks_Euro
echo "################# EURO KEYs end #################" >> SoftCam.Key.Euro
rm tosort new 00 01 

while read line
do
sed -i '/EURO KEYs added/,/EURO KEYs end/d' $line
cat SoftCam.Key.Euro >> $line
done < /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/PowerVu/Your-Softcam-Key-Location
rm SoftCam.Key.Euro
echo PLEASE RESTART OSCAM DISCOVERY-EUROPE KEYS UPDATED

echo "Astra 4.8°E 12322 V 27500"
echo "OSCAM'I YENİDEN YENİDEN BAŞLATIN (Discovery Europe) KEYS GÜNCELLENDİ"
echo "PLEASE RESTART OSCAM (Discovery Europe) KEYS UPDATED"

echo $FIN
################################################################################################################
#################################################### FIGHT #####################################################
> new
> tosort
> SoftCam.Key.FIGHT
sed -e 's/<[^>]*>//g' /tmp/index.html > new
echo "################# FIGHT KEYs added by POWERVU_KEY_UPDATER #################" >> SoftCam.Key.FIGHT
grep -A2 12707 new | grep -iv tele > tosort
sed -i 's/ECMKey1:  /ECMKey1: /g' tosort
sed -i 's/ ECMKey1: /ECMKey1: /g' tosort
sed -i 's/ECMKey0:  /ECMKey0: /g' tosort
sed -i 's/ ECMKey0: /ECMKey0: /g' tosort
grep -i Key0 tosort | cut -f 2 -d ':' | sed '/^$/d;s/[[:blank:]]//g' | sed -e 's/^\(.\{14\}\).*/\1/' > 00
grep -i 01  tosort | awk '{print $4}' > 01
cat 00 | sed "s/^/P 01FE 00 /g" >> SoftCam.Key.FIGHT
cat 01 | sed "s/^/P 01FE 01 /g" >> SoftCam.Key.FIGHT
echo "################# FIGHT KEYs end #################" >> SoftCam.Key.FIGHT
rm tosort new 00 01 

while read line
do
sed -i '/FIGHT KEYs added/,/FIGHT KEYs end/d' $line
cat SoftCam.Key.FIGHT >> $line
done < /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/PowerVu/Your-Softcam-Key-Location
rm SoftCam.Key.FIGHT

echo "Telestar 15.0°W 12707 H 4055"
echo "OSCAM'I YENİDEN YENİDEN BAŞLATIN (FIGHT Network) KEYS GÜNCELLENDİ"
echo "PLEASE RESTART OSCAM (FIGHT Network) KEYS UPDATED"

echo $FIN
################################################################################################################
###################################################### HBB #####################################################
> ne
> tosort
> SoftCam.Key.HBO
> 00
> 01
echo "################# HBO KEYs added by POWERVU_KEY_UPDATER #################" >> SoftCam.Key.HBO
sed -e 's/<[^>]*>//g' /tmp/index.html | grep -A7 -i "HBO/CineMax"  > tosort
grep -i "0000 00" tosort | awk '{print $4$5$6$7$8$9$10}' > 00
grep -i "0000 01" tosort | awk '{print $4$5$6$7$8$9$10}' > 01
grep -i KEY0 tosort | cut -f 2 -d ':' | sed '/^$/d;s/[[:blank:]]//g' | sed -e 's/^\(.\{14\}\).*/\1/' >> 00
grep -i KEY1 tosort | cut -f 2 -d ':' | sed '/^$/d;s/[[:blank:]]//g' | sed -e 's/^\(.\{14\}\).*/\1/' >> 01
while read line
do
cat 00 | sed "s/^/P $line 00 /g" >> SoftCam.Key.HBO
cat 01 | sed "s/^/P $line 01 /g" >> SoftCam.Key.HBO
done < /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/PowerVu/sids/P_HBO
echo "################# HBO KEYs end #################" >> SoftCam.Key.HBO
rm ne tosort 00 01

while read line
do
sed -i '/HBO KEYs added/,/HBO KEYs end/d' $line
cat SoftCam.Key.HBO >> $line
done < /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/PowerVu/Your-Softcam-Key-Location
rm SoftCam.Key.HBO

echo "Amos 4°W -10934.00 H  13750 5/6"
echo "OSCAM'I YENİDEN YENİDEN BAŞLATIN (HBO) KEYS GÜNCELLENDİ"
echo "PLEASE RESTART OSCAM (HBO) KEYS UPDATED"

echo $FIN
################################################################################################################
###################################################### SIS #####################################################
> new
> tosort
> SoftCam.Key.SIS
sed -e 's/<[^>]*>//g' /tmp/index.html > new
echo "################# SIS KEYs added by POWERVU_KEY_UPDATER #################" >> SoftCam.Key.SIS
grep -A10 -i SIS-Live new > tosort
sed -i 's/Key1:  /Key1: /g' tosort
sed -i 's/ Key1: /Key1: /g' tosort
sed -i 's/Key0:  /Key0: /g' tosort
sed -i 's/ Key0: /Key0: /g' tosort
grep -i ^Key0 tosort | cut -f 2 -d ':' | sed '/^$/d;s/[[:blank:]]//g' | sed -e 's/^\(.\{14\}\).*/\1/' > 00
grep -i ^Key1 tosort | cut -f 2 -d ':' | sed '/^$/d;s/[[:blank:]]//g' | sed -e 's/^\(.\{14\}\).*/\1/' > 01

while read line
do
cat 00 | sed "s/^/P $line 00 /g" >> SoftCam.Key.SIS
cat 01 | sed "s/^/P $line 01 /g" >> SoftCam.Key.SIS
done < /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/PowerVu/sids/P_SIS
echo "################# SIS KEYs end #################" >> SoftCam.Key.SIS
rm tosort new 00 01 

while read line
do
sed -i '/SIS KEYs added/,/SIS KEYs end/d' $line
cat SoftCam.Key.SIS >> $line
done < /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/PowerVu/Your-Softcam-Key-Location
rm SoftCam.Key.SIS

echo "Astra 4.8°E 12149-H-27500 – 12418-H-27500"
echo "OSCAM'I YENİDEN YENİDEN BAŞLATIN (SIS) KEYS GÜNCELLENDİ"
echo "PLEASE RESTART OSCAM (SIS) KEYS UPDATED"

echo $FIN
################################################################################################################
############################################### MTN Worldwide TV ###############################################
# wget http://najmsat2018.com/powervu-keys-2/
> new
> tosort
> SoftCam.Key.MTNWorldwide
sed -e 's/<[^>]*>//g' /tmp/index.html > new
echo "################# MTN Worldwide KEYs added by POWERVU_KEY_UPDATER #################" >> SoftCam.Key.MTNWorldwide
grep -A7 -i "MTN Worldwide" new > tosort
#grep -i "P 0000 00" tosort  | sed '/^$/d;s/[[:blank:]]//g' | cut -f 2 -d ':' | cut -f 1 -d '&' > 00
#grep -i "P 0000 01" tosort  | sed '/^$/d;s/[[:blank:]]//g' | cut -f 2 -d ':' | cut -f 1 -d '&' > 01
#grep -o -i 'P 0000 00[^<]*' tosort | cut -f 2 -d ':' | sed '/^$/d;s/[[:blank:]]//g' | sed -e 's/^\(.\{23\}\).*/\1/' > 00
#grep -o -i 'P 0000 01[^<]*' tosort | cut -f 2 -d ':' | sed '/^$/d;s/[[:blank:]]//g' | sed -e 's/^\(.\{23\}\).*/\1/' > 01
grep -o -i 'P 0000 00[^<]*' tosort | cut -f 2 -d ':' | sed '/^$/d;s/[[:blank:]]//g' > 00
grep -o -i 'P 0000 01[^<]*' tosort | cut -f 2 -d ':' | sed '/^$/d;s/[[:blank:]]//g' > 01

sed -i 's/P000000 //g' 00
sed -i 's/P000000//g' 00
sed -i 's/P000001 //g' 01
sed -i 's/P000001//g' 01

sed 's/ */ /g' 00 >000
sed 's/ */ /g' 01 >001
awk '{ print $1$2$3$4$5$6$7$8$9$10$11$12$13$14 }' 000 >00
awk '{ print $1$2$3$4$5$6$7$8$9$10$11$12$13$14 }' 001 >01

while read line
do
cat 00 | sed "s/^/P $line 00 /g" >> SoftCam.Key.MTNWorldwide
cat 01 | sed "s/^/P $line 01 /g" >> SoftCam.Key.MTNWorldwide
done < /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/PowerVu/sids/P_MTNWorldwide
echo "################# MTN Worldwide KEYs end #################" >> SoftCam.Key.MTNWorldwide
rm tosort new 00 01

while read line
do
sed -i '/MTN Worldwide KEYs added/,/MTN Worldwide KEYs end/d' $line
cat SoftCam.Key.MTNWorldwide >> $line
done < /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/PowerVu/Your-Softcam-Key-Location
rm SoftCam.Key.MTNWorldwide

echo "NSS 20°W-12513 H 3319 3/4 + 12508 H 2081"
echo "OSCAM'I YENİDEN YENİDEN BAŞLATIN (MTN Worldwide) KEYS GÜNCELLENDİ"
echo "PLEASE RESTART OSCAM (MTN Worldwide) KEYS UPDATED"

echo $FIN
################################################################################################################
#################################################### Arqiva ####################################################
# wget -q http://najmsat2018.com/powervu-keys-2/
> new
> tosort
> SoftCam.Key.Arqiva
sed -e 's/<[^>]*>//g' /tmp/index.html > new
echo "################# Arqiva KEYs added by POWERVU_KEY_UPDATER #################" >> SoftCam.Key.Arqiva
grep -B2 -i "0024B5A6" new > tosort
grep -i "KEY0" tosort  | sed '/^$/d;s/[[:blank:]]//g' | cut -f 2 -d ':' | cut -f 1 -d '&' > 00
grep -i "KEY1" tosort  | sed '/^$/d;s/[[:blank:]]//g' | cut -f 2 -d ':' | cut -f 1 -d '&' > 01
sed -i 's/ECMKEY0=//g' 00
sed -i 's/ECMKEY1=//g' 01

while read line
do
cat 00 | sed "s/^/P $line 00 /g" >> SoftCam.Key.Arqiva
cat 01 | sed "s/^/P $line 01 /g" >> SoftCam.Key.Arqiva
done < /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/PowerVu/sids/P_Arqiva
echo "################# Arqiva KEYs end #################" >> SoftCam.Key.Arqiva
rm tosort new 00 01

while read line
do
sed -i '/Arqiva KEYs added/,/Arqiva KEYs end/d' $line
cat SoftCam.Key.Arqiva >> $line
done < /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/PowerVu/Your-Softcam-Key-Location
rm SoftCam.Key.Arqiva

echo "Astra 4.8°E 12303-H-25546"
echo "OSCAM'I YENİDEN YENİDEN BAŞLATIN Arqiva KEYS GÜNCELLENDİ"
echo "PLEASE RESTART OSCAM Arqiva KEYS UPDATED"

echo $FIN
################################################################################################################
rm /tmp/index.html
