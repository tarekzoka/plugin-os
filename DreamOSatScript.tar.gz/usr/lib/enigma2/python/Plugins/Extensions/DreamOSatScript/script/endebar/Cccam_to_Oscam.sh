#!/bin/sh
#Created By endebar ustaya tesekkurler
# cccam
awk '/C:/' /etc/CCcam.cfg >> /tmp/cccam.txt
awk 'NR==1' /tmp/cccam.txt >> /tmp/cccam1.txt
sed 's/ /&\port/2' /tmp/cccam1.txt >> /tmp/cccam2.txt
sed -i -e 's/ port/,/g' /tmp/cccam2.txt 
sed -i -e 's/C: /device=/g' /tmp/cccam2.txt
sed 's/ /&\user=/1' /tmp/cccam2.txt >> /tmp/cccam3.txt
sed 's/ /&\password=/2' /tmp/cccam3.txt >> /tmp/cccam4.txt
sed 's/ no *.*//g' /tmp/cccam4.txt >> /tmp/cccam5.txt
sed 's/\s\+/\n/g' /tmp/cccam5.txt >> /tmp/cccam6.txt
echo "[reader]" >> /tmp/oscam.txt
echo "label = cccam" >> /tmp/oscam.txt
echo "protocol = cccam" >> /tmp/oscam.txt
awk 'NR=1,3' /tmp/cccam6.txt >> /tmp/oscam.txt
echo "inactivitytimeout = -1" >> /tmp/oscam.txt
echo "reconnecttimeout = 30" >> /tmp/oscam.txt
echo "disablecrccws_only_for = 1811:003311,003315;0500:030B00,032830,032830,04280 0,042820" >> /tmp/oscam.txt
echo "group = 1" >> /tmp/oscam.txt
echo "cccversion = 2.1.3" >> /tmp/oscam.txt
echo "cccwantemu = 1" >> /tmp/oscam.txt
echo "audisabled = 1" >> /tmp/oscam.txt
sed -i -e 's/device=/device = /g' /tmp/oscam.txt
sed -i -e 's/user=/user = /g' /tmp/oscam.txt
sed -i -e 's/password=/password = /g' /tmp/oscam.txt
echo "" >> /tmp/oscam.txt
# newcamd
awk '/N:/' /etc/CCcam.cfg >> /tmp/newcamd.txt
awk 'NR==1' /tmp/newcamd.txt >> /tmp/newcamd1.txt
sed 's/ /&\port/2' /tmp/newcamd1.txt >> /tmp/newcamd2.txt
sed -i -e 's/ port/,/g' /tmp/newcamd2.txt 
sed -i -e 's/N: /device=/g' /tmp/newcamd2.txt
sed 's/ /&\user=/1' /tmp/newcamd2.txt >> /tmp/newcamd3.txt
sed 's/ /&\password=/2' /tmp/newcamd3.txt >> /tmp/newcamd4.txt
sed 's/ 01 *.*//g' /tmp/newcamd4.txt >> /tmp/newcamd5.txt
sed 's/\s\+/\n/g' /tmp/newcamd5.txt >> /tmp/newcamd6.txt
echo "[reader]" >> /tmp/oscam1.txt
echo "label = newcamd" >> /tmp/oscam1.txt
echo "protocol = newcamd" >> /tmp/oscam1.txt
awk 'NR=1,3' /tmp/newcamd6.txt >> /tmp/oscam1.txt
echo "inactivitytimeout = -1" >> /tmp/oscam1.txt
echo "reconnecttimeout = 30" >> /tmp/oscam1.txt
echo "caid = " >> /tmp/oscam1.txt
echo "group = 1" >> /tmp/oscam1.txt
echo "audisabled = 1" >> /tmp/oscam1.txt
sed -i -e 's/device=/device = /g' /tmp/oscam1.txt
sed -i -e 's/user=/user = /g' /tmp/oscam1.txt
sed -i -e 's/password=/password = /g' /tmp/oscam1.txt
echo "" >> /tmp/oscam1.txt
#camd 3
awk '/L:/' /etc/CCcam.cfg >> /tmp/camd3.txt
awk 'NR==1' /tmp/camd3.txt >> /tmp/camd31.txt
sed 's/ /&\port/2' /tmp/camd31.txt >> /tmp/camd32.txt
sed -i -e 's/ port/,/g' /tmp/camd32.txt 
sed -i -e 's/L: /device=/g' /tmp/camd32.txt
sed 's/ /&\user=/1' /tmp/camd32.txt >> /tmp/camd33.txt
sed 's/ /&\password=/2' /tmp/camd33.txt >> /tmp/camd34.txt
sed 's/ /&\caid=/3' /tmp/camd34.txt >> /tmp/camd35.txt
sed 's/ /&\ident=/4' /tmp/camd35.txt >> /tmp/camd36.txt
sed 's/\s\+/\n/g' /tmp/camd36.txt >> /tmp/camd37.txt
echo "[reader]" >> /tmp/oscam2.txt
echo "label = camd3" >> /tmp/oscam2.txt
echo "protocol = cs357x" >> /tmp/oscam2.txt
awk 'NR=1,5' /tmp/camd37.txt >> /tmp/oscam2.txt
echo "inactivitytimeout = -1" >> /tmp/oscam2.txt
echo "reconnecttimeout = 30" >> /tmp/oscam2.txt
echo "group = 1" >> /tmp/oscam2.txt
echo "audisabled = 1" >> /tmp/oscam2.txt
sed -i -e 's/device=/device = /g' /tmp/oscam2.txt
sed -i -e 's/user=/user = /g' /tmp/oscam2.txt
sed -i -e 's/password=/password = /g' /tmp/oscam2.txt
sed -i -e 's/caid=/caid = /g' /tmp/oscam2.txt
sed -i -e 's/ident=/ident = /g' /tmp/oscam2.txt
echo "" >> /tmp/oscam2.txt
if [[ -n $(find /etc/tuxbox/config/ -name "oscam.server") ]]; then
echo "" >> /etc/tuxbox/config/oscam.server
sed -n 1,50p /tmp/oscam.txt >> /etc/tuxbox/config/oscam.server
sed -n 1,50p /tmp/oscam1.txt >> /etc/tuxbox/config/oscam.server
sed -n 1,50p /tmp/oscam2.txt >> /etc/tuxbox/config/oscam.server
dos2unix /etc/tuxbox/config/oscam.server
else
mkdir -p /etc/tuxbox/config
touch /etc/tuxbox/config/oscam.server
echo "" >> /etc/tuxbox/config/oscam.server
sed -n 1,50p /tmp/oscam.txt >> /etc/tuxbox/config/oscam.server
sed -n 1,50p /tmp/oscam1.txt >> /etc/tuxbox/config/oscam.server
sed -n 1,50p /tmp/oscam2.txt >> /etc/tuxbox/config/oscam.server
dos2unix /etc/tuxbox/config/oscam.server
fi
#rm -rf /tmp/*.txt
wget -O /dev/null -q http://root:password@localhost/web/r...trol?command=1
wget -O /dev/null -q http://root:password@localhost/web/r...trol?command=1
wget -O /dev/null -q http://root:password@localhost/web/r...trol?command=1
wget -O /dev/null -q http://root:password@localhost/web/r...trol?command=1
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*              << endebar >>              *";
echo "*..:: https://www.turk-dreamworld.com ::..*";
echo "*******************************************";

exit 0
