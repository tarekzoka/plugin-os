#!/bin/sh
#Created By audi06_19 @https://dreamosat-forum.com
#http://thefreetvkingston.info/Wizard/Init/movies.txt
FIN="=================================================="
echo $FIN
echo ".....:: LÜTFEN BEKLEYİNİZ .... PLEASE WAIT ::....."
cd /;
[ -d /tmp/IPTV ] || mkdir -p /tmp/IPTV;
cd /tmp/IPTV;
sleep 1;

wget --quiet -O - http://bit.do/rip-the-guts-outter-me | grep -o 'http[^ ]*' > qzff ;sed -i -E 's|(.*/)(.*)|\2\n&|' qzff ;sed -i '1479,1482d' qzff ;sed -i '1i #NAME INT 2017 Movies' qzff ;sed -i 's/^/#EXTINF:-1,/' qzff ;sed 's/#EXTINF:-1,//;N' < qzff > 2017.m3u & rm -rf qzff
sleep 2;

sed '/#EXTINF:-1,/!s/:/%3a/g' 2017.m3u >0
sed 's/#EXTINF:-1,/#DESCRIPTION: /g' 0 >00
sed '/#SERVICE 4097:0:1:0:0:0:0:0:0:0:rt/!s/http%3a/#SERVICE 4097:0:1:0:0:0:0:0:0:0:http%3a/' 00 >000
sed -n '/^#DES.*/h;/^#SER.*/{p;x;p};/^#NA.*/p' 000 >userbouquet.INT_2017_Movies.tv

echo 'DOWNLOAD'
sleep 1;
cp /tmp/IPTV/userbouquet.INT_2017_Movies.tv /etc/enigma2/userbouquet.INT_2017_Movies.tv > /dev/null

echo $LINE


if grep -qs 'userbouquet.INT_2017_Movies.tv' cat /etc/enigma2/bouquets.tv  ; then
    echo "Lista esistente in Bouquet"
else 
	echo "[+]Install INT 2017 Movies ..."
	echo '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "userbouquet.INT_2017_Movies.tv" ORDER BY bouquet' >> /etc/enigma2/bouquets.tv
fi
cd /;
rm -rf /tmp/IPTV > /dev/null 2>&1
echo $LINE


wget -q -O - http://127.0.0.1/web/servicelistreload?mode=0 > /dev/null 2>&1
wget -q -O - http://127.0.0.1/web/servicelistreload?mode=2 > /dev/null 2>&1

echo "";
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*             << audi06_19 >>             *";
echo "*  ..:: https://dreamosat-forum.com ::..  *";
echo "*******************************************";
sleep 1;
exit 0



