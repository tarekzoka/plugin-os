#!/bin/sh
#Created By audi06_19 @https://dreamosat-forum.com 15-10-2017
FIN="=================================================="
echo $FIN
echo ".....:: LÜTFEN BEKLEYİNİZ .... PLEASE WAIT ::....."
echo $FIN
echo "HDD MOUT İŞLEMİ BAŞLATILDI"
echo "HDD MOUT OPERATION HAS STARTED"
[ -d /tmp/DreamOSat ] || mkdir -p /tmp/DreamOSat > /dev/null;

echo $FIN
echo " YAKINDA EKLENECEK..."
echo " WE WILL BE ADDED NEAR ..."

rm -rf /tmp/DreamOSat > /dev/null;
echo ""
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*             << audi06_19 >>             *";
echo "*  ..:: https://dreamosat-forum.com ::..  *";
echo "*******************************************";
sleep 3;
exit 0
