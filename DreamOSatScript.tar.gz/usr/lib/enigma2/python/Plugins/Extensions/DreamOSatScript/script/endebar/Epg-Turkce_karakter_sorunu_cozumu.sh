#!/bin/sh
#Created By endebar ustaya tesekkurler
wget -q -O - http://127.0.0.1/web/about > /tmp/a.txt
awk '/e2tsid|e2onid/' /tmp/a.txt > /tmp/b.txt
sed -i -e 's/<\/e2tsid>//g' -e 's/<\/e2onid>//g' -e 's/<e2onid>//g' -e 's/<e2tsid>//g' /tmp/b.txt
sed 's/^[ \t]*//' /tmp/b.txt > /tmp/c.txt
echo "ISO8859-9" >> /tmp/c.txt
while read line1; read line2; do read line3; echo "$line1 $line2 $line3"; done </tmp/c.txt>/tmp/d.txt
if [[ -n $(find /usr/share/enigma2/ -name "encoding.conf") ]]; then
echo ""
else
touch /usr/share/enigma2/encoding.conf
fi
echo "" >> /usr/share/enigma2/encoding.conf
cat /tmp/d.txt >> /usr/share/enigma2/encoding.conf
sed -i -e '/^\s*$/d' /usr/share/enigma2/encoding.conf
rm -rf /tmp/*.txt
cat /usr/share/enigma2/encoding.conf | sort -u > /usr/share/enigma2/encoding1.conf
mv /usr/share/enigma2/encoding1.conf /usr/share/enigma2/encoding.conf
rm -rf /media/hdd/epg.dat /media/usb/epg.dat /home/root/epg.dat /etc/enigma2/epg.db
wget -O /dev/null -q http://localhost/web/remotecontrol?command=1 > /dev/null &
wget -O /dev/null -q http://localhost/web/remotecontrol?command=1 > /dev/null &
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*              << endebar >>              *";
echo "*..:: https://www.turk-dreamworld.com ::..*";
echo "*******************************************";

exit 0
