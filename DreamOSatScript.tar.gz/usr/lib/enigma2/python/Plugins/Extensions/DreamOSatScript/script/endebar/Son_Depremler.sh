#!/bin/sh
#Created By endebar ustaya tesekkurler
wget -q http://www.koeri.boun.edu.tr/scripts/lst0.asp -O /tmp/deprem.txt
awk '/<pre>/ {for(i=1; i<=203; i++) {getline; print}}' /tmp/deprem.txt >> /tmp/deprem1.txt
sed '1,3 d' /tmp/deprem1.txt >> /tmp/deprem2.txt
sed -i -e 's/................$//' /tmp/deprem2.txt
sed -i -e 's/REVIZE01//g' /tmp/deprem2.txt
sed -i -e 's/(2017.//g' /tmp/deprem2.txt
sed -i -e 's/(2018.//g' /tmp/deprem2.txt
cat /tmp/deprem2.txt
rm -rf /tmp/*.txt
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*              << endebar >>              *";
echo "*..:: https://www.turk-dreamworld.com ::..*";
echo "*******************************************";

exit 0
