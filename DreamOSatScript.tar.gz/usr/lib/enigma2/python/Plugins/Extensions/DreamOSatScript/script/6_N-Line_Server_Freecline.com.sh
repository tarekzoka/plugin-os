#!/bin/sh
#Created By audi06_19 @https://dreamosat-forum.com
FIN="=================================================="
echo $FIN
echo ".....:: LÜTFEN BEKLEYİNİZ .... PLEASE WAIT ::....."
[ -d /usr/keys ] || mkdir -p /usr/keys > /dev/null;
DATUM0=$(date +%Y/%m/%d|awk -vFS="/" -vOFS="/" '{$3=$3;print}')
DATUM1=$(date +%Y/%m/%d|awk -vFS="/" -vOFS="/" '{$3=$3-1;print}')
DATUM2=$(date +%Y/%m/%d|awk -vFS="/" -vOFS="/" '{$3=$3-2;print}')
DATUM3=$(date +%Y/%m/%d|awk -vFS="/" -vOFS="/" '{$3=$3-3;print}')
DATUM4=$(date +%Y/%m/%d|awk -vFS="/" -vOFS="/" '{$3=$3-4;print}')
DATUM5=$(date +%Y/%m/%d|awk -vFS="/" -vOFS="/" '{$3=$3-5;print}')
DATUM6=$(date +%Y/%m/%d|awk -vFS="/" -vOFS="/" '{$3=$3-6;print}')
DATUM7=$(date +%Y/%m/%d|awk -vFS="/" -vOFS="/" '{$3=$3-7;print}')
DATUM8=$(date +%Y/%m/%d|awk -vFS="/" -vOFS="/" '{$3=$3-8;print}')
DATUM9=$(date +%Y/%m/%d|awk -vFS="/" -vOFS="/" '{$3=$3-9;print}')
#CONT=$(grep "CWS =" /usr/keys/newcamd.list) > /dev/null 2>&1
WGET1="http://www.freecline.com/history/Newcamd"
EMU="/usr/keys/newcamd.list"
EMU1="/usr/keys/newcamd-2.list"
EMU_CP="/usr/keys/newcamd-1.list"

if grep -qs 'CWS =' cat $EMU ; then
   cp -rd $EMU $EMU_CP > /dev/null 2>&1
   echo $FIN
   echo "usr keys içerisinden, newcamd.list Yedek alındı..."
   echo "newcamd.list Backup taken ..."
   echo $FIN
else
   echo "usr keys içerisinden, newcamd.list Yedek alınamadı..."
   echo "newcamd.list Failed to backup ..."
   echo $FIN
fi
rm -rf $EMU > /dev/null 2>&1
rm -rf $EMU1 > /dev/null 2>&1
cat > $EMU1 << EOF
#### "*******************************************"
#### "*          ..:: A U T H O R ::..          *"
#### "*             << audi06_19 >>             *"
#### "*  ..:: https://dreamosat-forum.com ::..  *"
#### "*******************************************"
CWS_KEEPALIVE = 300
CWS_INCOMING_PORT = 21000
EOF
chmod 755 $EMU > /dev/null 2>&1
echo "DATE N+Line server" $DATUM0
wget -U "$WGET1" --quiet -O - $WGET1/$DATUM0 | grep -B2 -i status_icon_online | sed -e 's/<[^>]*>//g' | grep -o 'N:[^<]*' | awk '{if (++dup[$0] == 1) print $0;}' >>$EMU1
echo "DATE N+Line server" $DATUM1
wget -U "$WGET1" --quiet -O - $WGET1/$DATUM1 | grep -B2 -i status_icon_online | sed -e 's/<[^>]*>//g' | grep -o 'N:[^<]*' | awk '{if (++dup[$0] == 1) print $0;}' >>$EMU1
echo "DATE N+Line server" $DATUM2
wget -U "$WGET1" --quiet -O - $WGET1/$DATUM2 | grep -B2 -i status_icon_online | sed -e 's/<[^>]*>//g' | grep -o 'N:[^<]*' | awk '{if (++dup[$0] == 1) print $0;}' >>$EMU1
echo "DATE N+Line server" $DATUM3
wget -U "$WGET1" --quiet -O - $WGET1/$DATUM3 | grep -B2 -i status_icon_online | sed -e 's/<[^>]*>//g' | grep -o 'N:[^<]*' | awk '{if (++dup[$0] == 1) print $0;}' >>$EMU1
echo "DATE N+Line server" $DATUM4
wget -U "$WGET1" --quiet -O - $WGET1/$DATUM4 | grep -B2 -i status_icon_online | sed -e 's/<[^>]*>//g' | grep -o 'N:[^<]*' | awk '{if (++dup[$0] == 1) print $0;}' >>$EMU1
echo "DATE N+Line server" $DATUM5
wget -U "$WGET1" --quiet -O - $WGET1/$DATUM5 | grep -B2 -i status_icon_online | sed -e 's/<[^>]*>//g' | grep -o 'N:[^<]*' | awk '{if (++dup[$0] == 1) print $0;}' >>$EMU1
echo "DATE N+Line server" $DATUM6
wget -U "$WGET1" --quiet -O - $WGET1/$DATUM6 | grep -B2 -i status_icon_online | sed -e 's/<[^>]*>//g' | grep -o 'N:[^<]*' | awk '{if (++dup[$0] == 1) print $0;}' >>$EMU1
echo "DATE N+Line server" $DATUM7
wget -U "$WGET1" --quiet -O - $WGET1/$DATUM7 | grep -B2 -i status_icon_online | sed -e 's/<[^>]*>//g' | grep -o 'N:[^<]*' | awk '{if (++dup[$0] == 1) print $0;}' >>$EMU1
echo "DATE N+Line server" $DATUM8
wget -U "$WGET1" --quiet -O - $WGET1/$DATUM8 | grep -B2 -i status_icon_online | sed -e 's/<[^>]*>//g' | grep -o 'N:[^<]*' | awk '{if (++dup[$0] == 1) print $0;}' >>$EMU1
echo "DATE N+Line server" $DATUM9
wget -U "$WGET1" --quiet -O - $WGET1/$DATUM9 | grep -B2 -i status_icon_online | sed -e 's/<[^>]*>//g' | grep -o 'N:[^<]*' | awk '{if (++dup[$0] == 1) print $0;}' >>$EMU1

#dos2unix $EMU1 > /dev/null 2>&1
#tail -50  $EMU >>$EMU1
#head -6 $EMU >>$EMU1

sed -e '100,$d' $EMU1 >>$EMU
rm -rf $EMU1 > /dev/null 2>&1
sed -i 's/0102030405060708091011121314/01 02 03 04 05 06 07 08 09 10 11 12 13 14/g' $EMU > /dev/null 2>&1

sed -i '3,100s/^N:/CWS =/g' $EMU > /dev/null 2>&1
#sed -i 's/^N:/#N:/g' $EMU > /dev/null 2>&1
#sed -i '102,$d/^g' $EMU > /dev/null 2>&1

#sed '$!N; /^\(.*\)\n\1$/!P; D' $EMU > /dev/null 2>&1
#sed '1,10d' $EMU
echo $FIN
if grep -qs 'CWS =' cat $EMU ; then
echo "N+Line server (www.freecline.com) indirildi, usr keys içerisine yazıldı..."
echo "N+Line server (www.freecline.com) downloaded, it was written in /usr/keys ...";
else
      if [ -f /usr/keys/newcamd.list ] ; then
         cp -rd $EMU_CP $EMU
      else
         echo $FIN
      fi
   echo "Server Off, (www.freecline.com) bağlantı kurulamadı..."
   echo "Server Off, unable to connect ...";
   echo $FIN
   echo "N+Line server Yedek geri yuklendi..."
   echo "N+Line server Backup uploaded back ..."
fi
echo ""
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*             << audi06_19 >>             *";
echo "*  ..:: https://dreamosat-forum.com ::..  *";
echo "*******************************************";
sleep 3;
exit 0


