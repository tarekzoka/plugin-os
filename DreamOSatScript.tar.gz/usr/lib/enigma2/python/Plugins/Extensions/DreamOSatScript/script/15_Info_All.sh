#!/bin/sh
echo "";
echo "startip"
ifconfig | grep   addr:
echo "endip"
echo "startdrivers"
opkg list | grep dvb-modules
echo "enddrivers"
echo "startkernel"
cat /proc/version
echo "endkernel"
echo "start2stage"
opkg list | grep secondstage
echo "end2stage"
echo "startuptime"
uptime
echo "enduptime"
echo "starthostname"
hostname
echo "endhostname"
echo "startmac"
ifconfig | grep HWaddr
echo "endmac"
echo "";
echo "";
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*             << audi06_19 >>             *";
echo "*  ..:: https://dreamosat-forum.com ::..  *";
echo "*******************************************";
sleep 1;
exit 0
