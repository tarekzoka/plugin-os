#!/bin/sh
#Created By endebar ustaya tesekkurler
wget -q -O - http://altin.piyasadoviz.com/fiyat >> /tmp/altin.txt
sed -n -e '/class="bt">Tam/,+2p' /tmp/altin.txt >> /tmp/altin1.txt
sed -n -e '/class="by">Yar/,+2p' /tmp/altin.txt >> /tmp/altin1.txt
sed -n -e '/class="bc">.eyrek/,+2p' /tmp/altin.txt >> /tmp/altin1.txt
sed -n -e '/class="by14">14/,+2p' /tmp/altin.txt >> /tmp/altin1.txt
sed -n -e '/class="by18">18/,+2p' /tmp/altin.txt >> /tmp/altin1.txt
sed -n -e '/class="by22">22/,+2p' /tmp/altin.txt >> /tmp/altin1.txt
sed -n -e '/Cumhuriyet<\/h2><\/li>/,+2p' /tmp/altin.txt >> /tmp/altin1.txt
sed -n -e '/class="bhh">Has/,+2p' /tmp/altin.txt >> /tmp/altin1.txt
sed -n -e '/class="bh">Hamit/,+2p' /tmp/altin.txt >> /tmp/altin1.txt
sed -n -e '/class="br">Re.at/,+2p' /tmp/altin.txt >> /tmp/altin1.txt
sed -n -e '/class="bag">G.m../,+2p' /tmp/altin.txt >> /tmp/altin1.txt
sed -i -e 's/<li class="lrow simge ai"><h2 class="//g' -e 's/bt">Tam Alt.n/__________TAM ALTIN/g' -e 's/by">Yar.m Alt.n/__________YARIM ALTIN/g' -e 's/bc">.eyrek Alt.n/__________CEYREK ALTIN/g' -e 's/by14">14 Ayar Alt.n/__________14 AYAR ALTIN/g' -e 's/by18">18 Ayar Alt.n/__________18 AYAR ALTIN/g' -e 's/by22">22 Ayar Bilezik/__________22 AYAR ALTIN/g' -e 's/ba">Ata Cumhuriyet/__________ATA CUMHURIYET/g' -e 's/bhh">Has Alt.n/__________HAS ALTIN/g' -e 's/bh">Hamit Alt.n/__________HAMIT ALTIN/g' -e 's/br">Re.at Alt.n/__________RESAT ALTIN/g' -e 's/bag">G.m../__________GUMUS/g' /tmp/altin1.txt
sed -i -e 's/<\/h2><\/li>//g' -e 's/<\/li>//g' -e 's/<li class="midrow alis" title="//g' -e 's/<li class="midrow satis" title="//g' -e 's/">/ : /g' /tmp/altin1.txt
sed 's/^[ \t]*//' /tmp/altin1.txt >> /tmp/altin2.txt
sed -i -e 's/Al.. :/ALIS :/g' -e 's/Sat../SATIS/g' -e 's/Alt.n/ALTIN/g' -e '22 d' /tmp/altin2.txt
sed -i '1i___________________________________________ PERAKENDE ALTIN VE GUMUS FIYATLARI ______________________________________________' /tmp/altin2.txt
sed -i '2i ' /tmp/altin2.txt
tr '[:lower:]' '[:upper:]' < /tmp/altin2.txt> /tmp/altin3.txt
sed -i -e 's/RE.AT/RESAT/g' /tmp/altin3.txt -e 's/G.M../GUMUS/g' /tmp/altin3.txt -e 's/.EYREK/CEYREK/g' /tmp/altin3.txt -e 's/YAR.M/YARIM/g' /tmp/altin3.txt
cat /tmp/altin3.txt
rm -rf /tmp/*.txt
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*              << endebar >>              *";
echo "*..:: https://www.turk-dreamworld.com ::..*";
echo "*******************************************";

exit 0
