#!/bin/sh
#Created By endebar ustaya tesekkurler
opkg install curl
curl -k -sA "Chrome" -L "https://www.digiturkplay.com.tr/superlig" -o /tmp/mac.txt
awk 'ORS="";!/home/{$1=$1; print}{RS="\n"}END{print "\n" $0 "\n"}' /tmp/mac.txt >> /tmp/mac1.txt
sed -e "s/.*live-matches-panel//;s/row-fluid.*//" /tmp/mac1.txt >> /tmp/mac2.txt
sed -i -e 's/<\/div>/\+\+\+/g' /tmp/mac2.txt
sed 's/\+\+\+/\+\+\+\n/g' /tmp/mac2.txt >> /tmp/mac3.txt
sed -i -e '/Saat/d' -e '/Kanal/d' -e '/Karşılaşma/d' -e '/match-info/d' -e '/4 away-team/d' -e '/paket-detay/d' -e '/<\/section><section/d' -e '/<\/html>/d' /tmp/mac3.txt
sed -i -e 's/+++//g' -e 's/<\/span>//g' -e 's/<div class="col-xs-12 col-sm-2"><span>//g' -e 's/col-xs-12">//g' /tmp/mac3.txt
sed -i -e 's/<div class="col-xs-12 live-matches-bar"><div class="date-bar//g' /tmp/mac3.txt
sed -i -e 's/<div class="matches <div class="row"><div class="col-xs-12 col-sm-1"><span>//g' /tmp/mac3.txt
sed -i -e 's/<div class="row"><div class="col-xs-12 col-sm-1"><span>//g' /tmp/mac3.txt
sed 's/\/><img.*png//' /tmp/mac3.txt >> /tmp/mac4.txt
sed 's/<div.*png"//' /tmp/mac4.txt >> /tmp/mac5.txt
sed -i -e 's/ alt="//g' -e 's/" \/>//g' -e 's/" "/ - /g' -e 's/&#....//g' /tmp/mac5.txt
sed -i -e 's/<div class="col-xs-.. col-sm-.">/__________________________________________________ ______________/g' /tmp/mac5.txt
tr '[:lower:]' '[:upper:]' < /tmp/mac5.txt > /tmp/mac6.txt
sed -i -e 's/ş/S/g' -e 's/ı/I/g' -e 's/ğ/G/g' -e 's/ö/O/g' -e 's/ç/C/g' -e 's/i/I/g' -e 's/ü/U/g' -e 's/MRANIYESPOR/UMRANIYESPOR/g' -e 's/GZTEPE/GOZTEPE/g' -e 's/BEIKTAS/BESIKTAS/g' -e 's/AYKUR/CAYKUR/g' -e 's/FENERBAHE/FENERBAHCE/g' -e 's/K\.KARABKSPOR/KARDEMIR KARABUKSPOR/g' /tmp/mac6.txt
cat /tmp/mac6.txt
rm -rf /tmp/*.txt
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*              << endebar >>              *";
echo "*..:: https://www.turk-dreamworld.com ::..*";
echo "*******************************************";

exit 0
