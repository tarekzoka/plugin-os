#!/bin/sh
#Created By endebar ustaya tesekkurler
wget -q -O - http://spor.mynet.com/rss/ >> /tmp/shab.txt
sed 's/"utf-8".*<\/url><\/image><item><title>//' /tmp/shab.txt >> /tmp/shab1.txt
sed -i -e 's/<\/description><video><\/video><sondk><\/sondk><\/item><item><title>//g' /tmp/shab1.txt
sed -i -e 's/<\?xml version="1.0" encoding=//g' /tmp/shab1.txt
echo "_________________________MYNET SPOR HABERLERI______________________________" >> /tmp/shab2.txt
sed 's/<link>.*<description>//' /tmp/shab1.txt >> /tmp/shab2.txt
sed -i -e 's/<\/title>/ :.. /g' /tmp/shab2.txt
sed -i -e 's/<\/description><video><\/video><sondk><\/sondk><\/item><\/channel><\/rss>//g' /tmp/shab2.txt
sed -i -e 's/<?//g' /tmp/shab2.txt
cat /tmp/shab2.txt
rm -rf /tmp/*.txt
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*              << endebar >>              *";
echo "*..:: https://www.turk-dreamworld.com ::..*";
echo "*******************************************";

exit 0
