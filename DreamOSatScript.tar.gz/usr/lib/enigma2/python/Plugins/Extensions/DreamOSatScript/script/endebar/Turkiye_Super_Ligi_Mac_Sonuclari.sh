#!/bin/sh
#Created By endebar ustaya tesekkurler
wget -q -O - http://rss.kicker.de/live/turkcellsueperlig >> /tmp/canli.txt
sed -i -e '/<link>/d' -e '/<\/channel>/d' -e '/<\/rss>/d' -e '/<\?xml/d' -e '/<rss/d' -e '/<channel>/d' -e '/<language>/d' -e '/<image>/d' -e '/<height>/d' -e '/<width>/d' -e '/<\/image>/d' -e '/<copyright>/d' -e '/<item>/d' -e '/<\/item>/d' -e '/<url>/d' -e '/<ttl>/d' -e '/<description>/d' -e '/<guid/d' -e '/<pubDate>/d' -e '/<lastBuildDate>S/d' /tmp/canli.txt
sed -i -e 's/<title>/_______________/g' -e 's/<\/title>/_____________________/g' -e 's/<category>//g' -e 's/<\/category>//g' /tmp/canli.txt
sed -i -e '/_______________kicker/d' /tmp/canli.txt
sed 's/<content.*png"//' /tmp/canli.txt >> /tmp/canli1.txt
sed -i -e '/<content:encoded>/d' -e 's/Rote Karte/Kırmızı Kart/g' -e 's/ \/><br \/><br \/><b>Tore:<\/b> //g' /tmp/canli1.txt
sed 's/<br.*encoded>//' /tmp/canli1.txt >> /tmp/canli2.txt
sed -i -e 's/Spieltag/Hafta/g' -e 's/Fehlanzeige/Gol yok/g' -e 's/Uhr/+2 ekleyin/g' -e 's/\]\]><\/description>//g' -e 's/SPORTOTO SüperLig -//g' -e 's/SPORTOTO SüperLig//g' /tmp/canli2.txt
sed -i -e '/^\s*$/d' /tmp/canli2.txt
sed '1 d' /tmp/canli2.txt
cat /tmp/canli2.txt
rm -rf /tmp/*.txt
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*              << endebar >>              *";
echo "*..:: https://www.turk-dreamworld.com ::..*";
echo "*******************************************";

exit 0
