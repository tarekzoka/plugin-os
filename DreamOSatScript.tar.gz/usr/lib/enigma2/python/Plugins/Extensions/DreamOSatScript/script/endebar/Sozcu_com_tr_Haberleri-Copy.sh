#!/bin/sh
#Created By endebar ustaya tesekkurler
wget -q -O - http://www.sozcu.com.tr/rss.xml >> /tmp/haber.txt
sed -i -e '/<pubDate>/d' -e '/<enclosure /d' -e '/<link/d' -e '/PermaLink/d' -e '/<\/item>/d' -e '/<item>/d' -e '/<channel>/d' -e '/rss/d' -e '/<\/channel>/d' -e '/UTF-8/d' -e '/language/d' -e '/category/d' -e '/image/d' -e '/width/d' -e '/heigh/d' -e '/<ttl>/d' -e '/<lastBuildDate>/d' /tmp/haber.txt
sed -i -e 's/<title>//g' -e 's/<\/title>//g' -e 's/<description>//g' -e 's/<\/description>//g' -e 's/&#.....//g' -e 's/\[\]//g' /tmp/haber.txt
sed -i -e '1,2d' /tmp/haber.txt
cat /tmp/haber.txt
rm -rf /tmp/haber.txt
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*              << endebar >>              *";
echo "*..:: https://www.turk-dreamworld.com ::..*";
echo "*******************************************";

exit 0
