#!/bin/sh
#Created By audi06_19 @https://dreamosat-forum.com
FIN="=================================================="
echo $FIN
echo ".....:: LÜTFEN BEKLEYİNİZ .... PLEASE WAIT ::....."
cd /;
[ -d /etc/tuxbox/config/oscampowervu ] || mkdir -p /etc/tuxbox/config/oscampowervu;
[ -d /usr/keys ] || mkdir -p /usr/keys;
[ -d /tmp/keyupdate ] || mkdir -p /tmp/keyupdate;
wget http://depo.dreamosat.net/CaMs-EmU/SoftCam.Key -qO /tmp/keyupdate/SoftCam.Key > /dev/null;
wget http://depo.dreamosat.net/CaMs-EmU/constant.cw -qO /tmp/keyupdate/constant.cw > /dev/null;
sleep 2;
chmod 0755 /tmp/keyupdate/ -R;
cd /tmp/keyupdate;
cp SoftCam.Key /etc/tuxbox/config/;
cp SoftCam.Key /usr/keys/;
cp constant.cw /etc/tuxbox/config/;
cp constant.cw /usr/keys/;
echo "";
sleep 1;
cd /;
rm -rf /tmp/keyupdate;
echo $FIN
echo "SoftCam.Key ve constant.cw güncellendi";
echo "SoftCam.Key and constant.cw updated";
echo $FIN
echo "EMU Restart Etmeyi Unutmayınız. iyi seyirler...";
echo "Do not forget to restart the EMU. good looking ...";
echo "";
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*             << audi06_19 >>             *";
echo "*  ..:: https://dreamosat-forum.com ::..  *";
echo "*******************************************";
sleep 1;
exit 0
