#!/bin/sh
#Created By audi06_19 @https://dreamosat-forum.com
FIN="=================================================="
echo $FIN
echo ".....:: LÜTFEN BEKLEYİNİZ .... PLEASE WAIT ::....."
[ -d /usr/keys ] || mkdir -p /usr/keys > /dev/null;
DATUM0=$(date +%Y-%m-%d|awk -vFS="-" -vOFS="-" '{$3=$3;print}')
DATUM1=$(date +%Y-%m-%d|awk -vFS="-" -vOFS="-" '{$3=$3-1;print}')
DATUM2=$(date +%Y-%m-%d|awk -vFS="-" -vOFS="-" '{$3=$3-2;print}')
DATUM3=$(date +%Y-%m-%d|awk -vFS="-" -vOFS="-" '{$3=$3-3;print}')
DATUM4=$(date +%Y-%m-%d|awk -vFS="-" -vOFS="-" '{$3=$3-4;print}')
DATUM5=$(date +%Y-%m-%d|awk -vFS="-" -vOFS="-" '{$3=$3-5;print}')
DATUM6=$(date +%Y-%m-%d|awk -vFS="-" -vOFS="-" '{$3=$3-6;print}')
DATUM7=$(date +%Y-%m-%d|awk -vFS="-" -vOFS="-" '{$3=$3-7;print}')
DATUM8=$(date +%Y-%m-%d|awk -vFS="-" -vOFS="-" '{$3=$3-8;print}')
DATUM9=$(date +%Y-%m-%d|awk -vFS="-" -vOFS="-" '{$3=$3-9;print}')
#CONT=$(grep "CWS =" /usr/keys/newcamd.list) > /dev/null 2>&1
WGET1="https://www.testious.com/free-cccam-servers"
EMU="/usr/keys/newcamd.list"
EMU1="/usr/keys/newcamd-2.list"
EMU_CP="/usr/keys/newcamd-1.list"

if grep -qs 'CWS =' cat $EMU ; then
   cp -rd $EMU $EMU_CP > /dev/null 2>&1
   echo $FIN
   echo "usr keys içerisinden, newcamd.list Yedek alındı..."
   echo "newcamd.list Backup taken ..."
   echo $FIN
else
   echo "usr keys içerisinden, newcamd.list Yedek alınamadı..."
   echo "newcamd.list Failed to backup ..."
   echo $FIN
fi

rm -rf $EMU > /dev/null 2>&1
rm -rf $EMU1 > /dev/null 2>&1

cat > $EMU1 << EOF
CWS_KEEPALIVE = 300
CWS_INCOMING_PORT = 21000
EOF

chmod 755 $EMU > /dev/null 2>&1
# N: iexufoh3.cserver.tv 3041 zargacum.center update 01 02 03 04 05 06 07 08 09 10 11 12 13 14 #
curl -Lbo -s $WGET1 | grep -o -i 'N: [^<]*' | awk '!_[$2]++' | awk '!_[$4]++' | awk '!_[$5]++' | awk '{ print $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19 }' >>$EMU1

#wget -U "$WGET1" --quiet -O - $WGET1/$DATUM1 | grep -o 'N:[^<]*' | awk '{if (++dup[$0] == 1) print $0;}' >>$EMU1
#wget -U "$WGET1" --quiet -O - $WGET1/$DATUM2 | grep -o 'N:[^<]*' | awk '{if (++dup[$0] == 1) print $0;}' >>$EMU1
#wget -U "$WGET1" --quiet -O - $WGET1/$DATUM3 | grep -o 'N:[^<]*' | awk '{if (++dup[$0] == 1) print $0;}' >>$EMU1
#wget -U "$WGET1" --quiet -O - $WGET1/$DATUM4 | grep -o 'N:[^<]*' | awk '{if (++dup[$0] == 1) print $0;}' >>$EMU1
#wget -U "$WGET1" --quiet -O - $WGET1/$DATUM5 | grep -o 'N:[^<]*' | awk '{if (++dup[$0] == 1) print $0;}' >>$EMU1
#wget -U "$WGET1" --quiet -O - $WGET1/$DATUM6 | grep -o 'N:[^<]*' | awk '{if (++dup[$0] == 1) print $0;}' >>$EMU1
#wget -U "$WGET1" --quiet -O - $WGET1/$DATUM7 | grep -o 'N:[^<]*' | awk '{if (++dup[$0] == 1) print $0;}' >>$EMU1
#wget -U "$WGET1" --quiet -O - $WGET1/$DATUM8 | grep -o 'N:[^<]*' | awk '{if (++dup[$0] == 1) print $0;}' >>$EMU1
#wget -U "$WGET1" --quiet -O - $WGET1/$DATUM9 | grep -o 'N:[^<]*' | awk '{if (++dup[$0] == 1) print $0;}' >>$EMU1

#dos2unix $EMU1 > /dev/null 2>&1
#tail -50  $EMU >>$EMU1
#head -6 $EMU >>$EMU1

sed -e '74,$d' $EMU1 >>$EMU
rm -rf $EMU1 > /dev/null 2>&1
sed -i 's/0102030405060708091011121314/01 02 03 04 05 06 07 08 09 10 11 12 13 14/g' $EMU > /dev/null 2>&1

sed -i '3,53s/^N:/CWS =/g' $EMU > /dev/null 2>&1
sed -i 's/^n:/#N:/g' $EMU > /dev/null 2>&1
#sed -i '102,$d/^g' $EMU > /dev/null 2>&1

#sed '$!N; /^\(.*\)\n\1$/!P; D' $EMU > /dev/null 2>&1
#sed '1,10d' $EMU
echo $FIN
if grep -qs 'CWS =' cat $EMU ; then
echo "N + Line server (www.testious.com) indirildi, usr keys içerisine yazıldı..."
echo "N+Line server (www.freecline.com) downloaded, it was written in /usr/keys ...";
else
      if [ -f /usr/keys/newcamd.list ] ; then
         cp -rd $EMU_CP $EMU
      else
         echo $FIN
      fi
   echo "Server Off, (www.freecline.com) bağlantı kurulamadı..."
   echo "Server Off, unable to connect ...";
   echo $FIN
   echo "N+Line server Yedek geri yuklendi..."
   echo "N+Line server Backup uploaded back ..."
fi
echo ""
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*             << audi06_19 >>             *";
echo "*  ..:: https://dreamosat-forum.com ::..  *";
echo "*******************************************";
sleep 3;
exit 0


