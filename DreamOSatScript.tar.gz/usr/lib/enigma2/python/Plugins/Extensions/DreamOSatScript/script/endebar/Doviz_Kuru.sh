#!/bin/sh
#Created By endebar ustaya tesekkurler
wget -q -O - http://kur.piyasadoviz.com/banka >> /tmp/kur.txt
sed -n -e '/ title="ABD/,+13p' -e '/ title="Euro">/,+13p' -e '/title="İngiliz/,+13p' -e '/title="Japon/,+13p' -e '/title="İsviçre /,+13p' -e '/title="Danimarka/,+13p' -e '/title="İsveç/,+13p' -e '/title="Norveç/,+13p' -e '/title="Suudi/,+13p' -e '/title="Avustralya/,+13p' -e '/title="Kanada/,+13p' -e '/title="Rus/,+13p' -e '/title="Çin/,+13p' -e '/title="Güney/,+13p' -e '/title="Meksika/,+13p' -e '/title="Yeni/,+13p' -e '/title="Irak/,+13p' -e '/title="Birleşik/,+13p' -e '/title="Kuveyt/,+13p' -e '/title="Bahreyn/,+13p' /tmp/kur.txt >> /tmp/kur1.txt
sed -i -e '6s/<li class="midrow">/ALIS : /' -e '13s/<li class="midrow">/ALIS : /' -e '20s/<li class="midrow">/ALIS : /' -e '27s/<li class="midrow">/ALIS : /' -e '34s/<li class="midrow">/ALIS : /' -e '41s/<li class="midrow">/ALIS : /' -e '48s/<li class="midrow">/ALIS : /' -e '55s/<li class="midrow">/ALIS : /' -e '62s/<li class="midrow">/ALIS : /' -e '69s/<li class="midrow">/ALIS : /' -e '76s/<li class="midrow">/ALIS : /' -e '83s/<li class="midrow">/ALIS : /' -e '90s/<li class="midrow">/ALIS : /' /tmp/kur1.txt
sed -i -e '/<ul>/d' -e '/<\/ul>/d' -e '/<li class="lrow simge">/d' -e '/<\/div>/d' -e '/li class="rrow"><span/d' -e '/class="onceki/d' /tmp/kur1.txt
sed -i -e '1s/">//' -e '8s/">//' -e '15s/">//' -e '22s/">//' -e '29s/">//' -e '36s/">//' -e '43s/">//' -e '50s/">//' -e '57s/">//' -e '64s/">//' -e '71s/">//' -e '78s/">//' -e '85s/">//' /tmp/kur1.txt
sed -i -e 's/<li class="midrow">/SATIS : /g' -e 's/<div class="kurlar bordernone" title="//g' -e 's/<li class="midrow alis" title="//g' -e 's/<li class="midrow satis" title="//g' -e 's/<li class="midrow capraz" title="//g' -e 's/<li class="lrow">//g' -e 's/<\/li>//g' -e 's/">/ : /g' /tmp/kur1.txt
sed -i '1i______________________________________________ SERBEST PIYASA DOVIZ KURLARI ______________________________________________' /tmp/kur1.txt
sed -i '2i ' /tmp/kur1.txt
tr '[:lower:]' '[:upper:]' < /tmp/kur1.txt> /tmp/kur2.txt
sed -i -e 's/AL../ALIS/g' -e 's/SAT../SATIS/g' -e 's/DOLAR./DOLARI/g' -e 's/DINAR./DINARI/g' -e 's/.NCEK./ONCEKI/g' -e 's/.APRAZ/CAPRAZ/g' -e 's/AVUSTRAL../AVUSTRALYA/g' -e 's/	//g' -e 's/	/__________________/g' /tmp/kur2.txt
cat /tmp/kur2.txt
rm -rf /tmp/*.txt
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*              << endebar >>              *";
echo "*..:: https://www.turk-dreamworld.com ::..*";
echo "*******************************************";

exit 0
