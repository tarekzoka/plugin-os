#!/bin/sh
#Created By audi06_19 @https://dreamosat-forum.com
wget http://depo.dreamosat.net/Settings/satellitesxml/satellites.xml -qO /etc/tuxbox/satellites.xml;
chmod 0755 /etc/tuxbox/satellites.xml -R;
echo ""
wget -qO - http://127.0.0.1/web/servicelistreload?mode=0 > /dev/null;
wget -qO - http://127.0.0.1/web/servicelistreload?mode=1 > /dev/null;
wget -qO - http://127.0.0.1/web/servicelistreload?mode=2 > /dev/null;
echo "Satellites.xlm güncellendi";
echo ""
echo "Uydu alıcınızı Restart Etmeyi Unutmayınız. iyi seyirler...";
echo "";
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*             << audi06_19 >>             *";
echo "*  ..:: https://dreamosat-forum.com ::..  *";
echo "*******************************************";
sleep 1;
exit 0
