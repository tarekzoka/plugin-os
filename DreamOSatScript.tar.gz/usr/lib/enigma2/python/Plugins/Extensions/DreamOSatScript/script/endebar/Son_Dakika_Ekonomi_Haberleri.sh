#!/bin/sh
#Created By endebar ustaya tesekkurler
opkg install curl
curl -k -sA "Chrome" -L "https://www.sondakika.com/ekonomi/" -q | sed -e 's/<[^>]*>//g;s/^ //g' > /tmp/a.txt
sed -i -e '/^\s*$/d' /tmp/a.txt
sed -e 's/2017/2017baslik/g' -e 's/2018/2018baslik/g' -e 's/2019/2019baslik/g' -e 's/2020/2020baslik/g' /tmp/a.txt > /tmp/b.txt
sed -n '/baslik/{N;N;N;p}' /tmp/b.txt > /tmp/c.txt
sed '201,4000 d' /tmp/c.txt > /tmp/e.txt
sed -i -e 's/baslik//g' /tmp/e.txt
sed 's/^[ \t]*//' /tmp/e.txt >> /tmp/f.txt
cat /tmp/f.txt
rm -rf /tmp/*.txt
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*              << endebar >>              *";
echo "*..:: https://www.turk-dreamworld.com ::..*";
echo "*******************************************";

exit 0
