#!/bin/sh
#Created By audi06_19 @https://dreamosat-forum.com
FIN="=================================================="
echo $FIN
echo ".....:: LÜTFEN BEKLEYİNİZ .... PLEASE WAIT ::....."
echo $FIN
echo "FreeColor Key 56e Downloader for E2, DreamOS";
cd /;
[ -d /usr/keys ] || mkdir -p /usr/keys;
sleep 1;
[ -d /tmp/freecolor ] || mkdir -p /tmp/freecolor;
sleep 1;
wget http://freecolor.eu.org/sat/freecolor-keys.zip -qO /tmp/freecolor/freecolor-keys.zip > /dev/null;
sleep 1;
unzip -o /tmp/freecolor/freecolor-keys.zip -d /tmp/freecolor/ > /dev/null;
sleep 1;
#sibir
rm -rf /usr/keys/ee.bin;
rm -rf /usr/keys/iq.bin;
rm -rf /usr/keys/key.bin;
rm -rf /usr/keys/key.db;
rm -rf /usr/keys/keydata.bin;
rm -rf /usr/keys/keydata.tmp;
rm -rf /usr/keys/keydata.txt;
rm -rf /usr/keys/mcaskey.bin;
rm -rf /usr/keys/snippet.tbl91;
#keys
rm -rf /usr/keys/SoftCam.Key;
rm -rf /usr/keys/constant.cw;
rm -rf /usr/keys/dre.keys;
rm -rf /usr/keys/drecrypt.key;
rm -rf /usr/keys/drekeys.log;
rm -rf /usr/keys/gbox.key;
rm -rf /usr/keys/oscam.keys;
rm -rf /usr/keys/pobedit.key;
#copy
cp -rd /tmp/freecolor/sibir/ee.bin /usr/keys/;
cp -rd /tmp/freecolor/sibir/iq.bin /usr/keys/;
cp -rd /tmp/freecolor/sibir/key.bin /usr/keys/;
cp -rd /tmp/freecolor/sibir/key.db /usr/keys/;
cp -rd /tmp/freecolor/sibir/keydata.bin /usr/keys/;
cp -rd /tmp/freecolor/sibir/keydata.tmp /usr/keys/;
cp -rd /tmp/freecolor/sibir/keydata.txt /usr/keys/;
cp -rd /tmp/freecolor/sibir/mcaskey.bin /usr/keys/;
cp -rd /tmp/freecolor/center/snippet.tbl91 /usr/keys/;
#
cp -rd /tmp/freecolor/keys/SoftCam.Key /usr/keys/;
cp -rd /tmp/freecolor/keys/constant.cw /usr/keys/;
cp -rd /tmp/freecolor/keys/dre.keys /usr/keys/;
cp -rd /tmp/freecolor/keys/drecrypt.key /usr/keys/;
cp -rd /tmp/freecolor/keys/drekeys.log /usr/keys/;
cp -rd /tmp/freecolor/keys/gbox.key /usr/keys/;
cp -rd /tmp/freecolor/keys/oscam.keys /usr/keys/;
cp -rd /tmp/freecolor/keys/pobedit.key /usr/keys/;
#
rm -rf /tmp/freecolor;
echo $FIN
echo "Güncellendi FreeColor Key 56e ";
echo "Updated FreeColor Key 56e";
echo $FIN
echo "Wicard, Oscam-Ymod, Oscam Emu Restart Etmeyi Unutmayınız. iyi seyirler...";
echo "Wicard, Oscam-Ymod, Oscam Emu Do not forget to Restart. good looking ...";
echo "";
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*             << audi06_19 >>             *";
echo "*  ..:: https://dreamosat-forum.com ::..  *";
echo "*******************************************";
sleep 1;
exit 0

