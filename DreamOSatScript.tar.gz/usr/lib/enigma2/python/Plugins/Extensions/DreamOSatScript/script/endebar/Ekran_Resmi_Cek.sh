#!/bin/sh
#Created By endebar ustaya tesekkurler
echo ""
echo ""
grab -v /tmp/ekranresmi.png
echo "EKRAN RESMINIZIN CEKILMISTIR. EKLENTILERDEN RESIM GOSTERICI PLUGINSI ILE CEKILEN RESMI GOREBILIRSINIZ. RESIM DOSYASI YOLU /tmp/ekranresmi.png"
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*              << endebar >>              *";
echo "*..:: https://www.turk-dreamworld.com ::..*";
echo "*******************************************";

exit 0
