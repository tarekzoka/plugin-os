#!/bin/sh

EXISTING_ARCH1="/etc/enigma2/blacklist"
EXISTING_ARCH2="/etc/enigma2/lamedb"
EXISTING_ARCH3="/etc/enigma2/satellites.xml"
EXISTING_ARCH4="/etc/tuxbox/satellites.xml"
EXISTING_ARCH5="/etc/enigma2/whitelist"
EXISTING_ARCH6="/etc/enigma2/*.tv"
EXISTING_ARCH7="/etc/enigma2/*.radio"

WGET1="wget http://depo.dreamosat.net/Settings/VERSION -qO /tmp/VERSION"
WGET2="wget http://depo.dreamosat.net/Settings/enigma2-settings-$HAZIRLAYAN-$KANAL_SETTINGS-$TARGET_DATE.zip -qO /tmp/enigma2-settings-$HAZIRLAYAN-$KANAL_SETTINGS-$TARGET_DATE.zip"

## change to working directory and cleanup any downloaded files and extracted rules in modsec/ directory
	rm -f -r $EXISTING_ARCH1
	rm -f -r $EXISTING_ARCH2
	rm -f -r $EXISTING_ARCH3
	rm -f -r $EXISTING_ARCH4
	rm -f -r $EXISTING_ARCH5
	rm -f -r $EXISTING_ARCH6
	rm -f -r $EXISTING_ARCH7

## wget1 to download VERSION file
	`$WGET1`

## get current MODSEC_VERSION from VERSION file and save as variable
	cd /tmp/
	source VERSION
	TARGET_DATE=`echo $MODSEC_VERSION`

## WGET2 command to download current archive
	`$WGET2`MODSEC_VERSION

	echo "Güncel $HAZIRLAYAN $TARGET_DATE Motor Kanal Listesi";

## extract archive
	unzip -o /tmp/enigma2-settings-$HAZIRLAYAN-$KANAL_SETTINGS-$TARGET_DATE.zip -d /etc/enigma2 > /dev/null;

	cp /etc/enigma2/satellites.xml /etc/tuxbox/;
	chmod 0755 /etc/tuxbox/satellites.xml -R;

	rm -rf /tmp/enigma2-settings-$HAZIRLAYAN-$KANAL_SETTINGS-$TARGET_DATE.zip > /dev/null;
	rm -rf /tmp/VERSION;

echo "";
	wget -qO - http://127.0.0.1/web/servicelistreload?mode=0 > /dev/null;
	wget -qO - http://127.0.0.1/web/servicelistreload?mode=1 > /dev/null;
	wget -qO - http://127.0.0.1/web/servicelistreload?mode=2 > /dev/null;
echo "KANAL LİSTESİ İÇİN ..::$HAZIRLAYAN::.. USTAMIZA TEŞEKKÜRLER.";
echo "";
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*             << audi06_19 >>             *";
echo "*  ..:: https://dreamosat-forum.com ::..  *";
echo "*******************************************";

exit 0
