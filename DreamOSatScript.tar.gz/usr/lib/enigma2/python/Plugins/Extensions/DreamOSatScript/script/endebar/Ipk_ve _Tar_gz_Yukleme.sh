#!/bin/sh
#Created By endebar ustaya tesekkurler
echo "USB VEYA TMP KLASORUNE KOPYALADIGINIZ .IPK VE TAR.GZ UZANTILI DOSYALARI BU SCRIPTLE YUKLEYEBILIRSINIZ"
echo ""
echo ""
sleep 1
echo "DOSYALARINIZ YUKLENIYOR"
opkg install --force-depends /tmp/*.ipk
opkg install --force-depends /media/usb/*.ipk
tar -zxvf /tmp/*.tar.gz -C /
tar -zxvf /media/usb/*.tar.gz -C /
sleep 3 
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*              << endebar >>              *";
echo "*..:: https://www.turk-dreamworld.com ::..*";
echo "*******************************************";
reboot

exit 0
