#!/bin/sh
#Created By endebar ustaya tesekkurler
if [[ -n $(find /usr/bin/ -name "curl") ]]; then
echo ""
else
opkg update
opkg install curl
fi
init 4
curl -k -sA "Chrome" -L "https://github.com/OpenPLi/OpenPLi-1/blob/master/cdk/cdk/root/share/tuxbox/satellites.xml" -q | sed -e 's/<[^>]*>//g;s/^ //g' > /tmp/a.txt
sed -i -e '/^\s*$/d' /tmp/a.txt
sed -i -e 's/\&lt\;/</g' -e 's/\&gt\;/>/g' -e 's/\&quot\;/\"/g' /tmp/a.txt
cat /tmp/a.txt | grep ".<" > /tmp/b.txt
sed ':a;N;$!ba;s/\n/ /g' /tmp/b.txt > /tmp/c.txt
sed -e "s/.*<\?xml//;s/;<\/satellites>.*//"  /tmp/c.txt > /tmp/d.txt
sed -e 's/</\n</g' /tmp/d.txt > /tmp/e.txt
sed -i -e 's/ version=\"1\.0\"/<\?xml version=\"1\.0\"/g' -e 's/<\!\-\-//g' /tmp/e.txt
mv /tmp/e.txt /etc/tuxbox/satellites.xml
rm -rf /tmp/*.txt
init 3
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*              << endebar >>              *";
echo "*..:: https://www.turk-dreamworld.com ::..*";
echo "*******************************************";

exit 0
