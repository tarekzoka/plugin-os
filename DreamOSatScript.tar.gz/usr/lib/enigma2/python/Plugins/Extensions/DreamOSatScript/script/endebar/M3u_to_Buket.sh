#!/bin/sh
#Created By endebar ustaya tesekkurler
mv /etc/enigma2/*.m3u /tmp/buket.txt
mv /tmp/*.m3u /tmp/buket.txt
dos2unix /tmp/*.txt
sed -i -e '/EXTM3U/d' /tmp/buket.txt
sed -i -e '/^\s*$/d' /tmp/buket.txt
awk '0 == NR % 2' /tmp/buket.txt >> /tmp/buket1.txt
awk '0 == (NR + 1) % 2' /tmp/buket.txt >> /tmp/buket2.txt
sed -i -e 's/#EXTINF:-1,/#DESCRIPTION /g' -e 's/#EXTINF:-2,/#DESCRIPTION /g' -e 's/#EXTINF:-3,/#DESCRIPTION /g' -e 's/#EXTINF:-4,/#DESCRIPTION /g' -e 's/#EXTINF:0,/#DESCRIPTION /g' -e 's/#EXTINF:1,/#DESCRIPTION /g' -e 's/#EXTINF:2,/#DESCRIPTION /g' -e 's/#EXTINF:3,/#DESCRIPTION /g' -e 's/#EXTINF:4,/#DESCRIPTION /g' /tmp/buket2.txt
sed -i -e 's/:/%3A/g' /tmp/buket1.txt
dos2unix /tmp/*.txt
sed -i -e 's/http/#SERVICE 4097:0:1:0:0:0:0:0:0:0:http/g' /tmp/buket1.txt
sed -i -e 's/https/#SERVICE 4097:0:1:0:0:0:0:0:0:0:https/g' /tmp/buket1.txt
sed -i -e 's/rtmp/#SERVICE 4097:0:1:0:0:0:0:0:0:0:rtmp/g' /tmp/buket1.txt
awk -v t=3 '{c=c<FNR?FNR:c; for (i=1;i<=t;i++) if (ARGIND==i) a[i FS FNR]=$0} END {for (i=1;i<=c;i++) for (j=1;j<=t;j++) print a[j FS i]}' /tmp/buket1.txt /tmp/buket2.txt >> /tmp/userbouquet.m3utobuket.tv
dos2unix /tmp/userbouquet.m3utobuket.tv
sed -i -e '/^\s*$/d' /tmp/userbouquet.m3utobuket.tv
sed -i '1i#NAME M3U TO BUKET' /tmp/userbouquet.m3utobuket.tv
if grep -qs 'userbouquet.m3utobuket.tv' cat /etc/enigma2/bouquets.tv ; then
echo ""
else
sed -i -e '2a#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET \"userbouquet\.m3utobuket\.tv\" ORDER BY bouquet' /etc/enigma2/bouquets.tv
fi
rm -rf /tmp/*.txt
if [[ -n $(find /etc/enigma2/ -name "userbouquet.m3utobuket.tv") ]]; then
sed -n 2,9999p /tmp/userbouquet.m3utobuket.tv >> /etc/enigma2/userbouquet.m3utobuket.tv 
sed -i -e '/^\s*$/d' /etc/enigma2/userbouquet.m3utobuket.tv 
dos2unix /etc/enigma2/userbouquet.m3utobuket.tv 
rm -rf /etc/enigma2/*.Del
rm -rf /etc/enigma2/*.del
else
mv /tmp/userbouquet.m3utobuket.tv /etc/enigma2/userbouquet.m3utobuket.tv
fi
wget -q -O - http://127.0.0.1/web/servicelistreload?mode=2
wget -q -O - http://127.0.0.1/web/servicelistreload?mode=2
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*              << endebar >>              *";
echo "*..:: https://www.turk-dreamworld.com ::..*";
echo "*******************************************";

exit 0
