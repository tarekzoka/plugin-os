#!/bin/sh
#Created By endebar ustaya tesekkurler
echo "FTP VE TELNET SIFRESINI FABRIKA AYARLARINA SIFIRLAR. DREAMBOX SIFRISI dreambox VUDUO SIFRE YOK YADA vuduo OLARAK DEGISTIRIR"
echo ""
echo ""
sed -i -e '1s/root:x:0:0:root:\/home\/root:\/bin\/sh/root::0:0::\/:\/bin\/sh/g' /etc/passwd
sed -i -e '1s/root::0:0:root:\/home\/root:\/bin\/sh/root::0:0::\/:\/bin\/sh/g' /etc/passwd-
sleep 2
echo "SIFRENIZ SIFIRLANDI"
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*              << endebar >>              *";
echo "*..:: https://www.turk-dreamworld.com ::..*";
echo "*******************************************";

exit 0
