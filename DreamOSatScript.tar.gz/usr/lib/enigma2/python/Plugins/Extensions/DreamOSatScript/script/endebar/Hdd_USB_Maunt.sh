#!/bin/sh
#Created By endebar ustaya tesekkurler
#usb mount
blkid >> /tmp/mount.txt
sleep 3
awk '/ntfs/{print $3}' /tmp/mount.txt >> /tmp/usb.txt 
echo "/media/usb auto defaults 0 0" >> /tmp/usb.txt  
sed -i -e 's/"//g' /tmp/usb.txt
awk '/vfat/{print $2}' /tmp/mount.txt >> /tmp/usb.txt
echo "/media/usb auto defaults 0 0" >> /tmp/usb.txt 
while read line1; do read line2; echo "$line1 $line2"; done </tmp/usb.txt>/tmp/usb1.txt
if grep -qs 'UUID' cat /tmp/usb1.txt ; then
awk 'NR==1' /tmp/usb1.txt >> /tmp/usb2.txt
else
echo ""
fi
if grep -qs '\/media\/usb' cat /etc/fstab ; then
echo ""
else
echo "" >> /etc/fstab
awk 'NR==1' /tmp/usb2.txt >> /etc/fstab
fi
#hdd mount
awk '/sda1/{print $2}' /tmp/mount.txt >> /tmp/hdisk.txt 
echo "/media/hdd auto defaults 0 0" >> /tmp/hdisk.txt
sed -i -e 's/"//g' /tmp/hdisk.txt
while read line1; do read line2; echo "$line1 $line2"; done </tmp/hdisk.txt>/tmp/hdisk1.txt
if grep -qs 'UUID' cat /tmp/hdisk1.txt ; then
awk 'NR==1' /tmp/hdisk1.txt >> /tmp/hdisk2.txt
else
echo ""
fi
if grep -qs '\/media\/hdd' cat /etc/fstab ; then
echo ""
else
echo "" >> /etc/fstab
awk 'NR==1' /tmp/hdisk2.txt >> /etc/fstab
fi
rm -rf /tmp/usb.txt
rm -rf /tmp/usb1.txt
rm -rf /tmp/usb2.txt
rm -rf /tmp/hdisk.txt
rm -rf /tmp/hdisk1.txt
rm -rf /tmp/hdisk2.txt
rm -rf /tmp/mount.txt
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*              << endebar >>              *";
echo "*..:: https://www.turk-dreamworld.com ::..*";
echo "*******************************************";

exit 0
