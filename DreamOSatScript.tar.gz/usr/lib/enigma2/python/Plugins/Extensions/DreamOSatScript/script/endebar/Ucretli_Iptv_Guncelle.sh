#!/bin/sh
#Created By endebar ustaya tesekkurler
cat /etc/enigma2/*.tv | grep "[0123456789].ts" | awk 'NR==1' >> /tmp/ip.txt
sed 's/\#SERVICE.*http/http/' /tmp/ip.txt >> /tmp/ip1.txt
sed -i -e 's/%3A/:/g' -e 's/http:\/\//http/g' -e 's/\/live\//get.php?username=/g' /tmp/ip1.txt
sed 's/\//&\pass/1' /tmp/ip1.txt >> /tmp/ip2.txt
sed -i -e 's/\/pass/\&password=/g' /tmp/ip2.txt
sed 's/\/.*ts/\&type=simple\&output=ts"/' /tmp/ip2.txt >> /tmp/ip3.txt
sed -i -e 's/http/wget -q -O \/tmp\/iptv\.tv "http:\/\//g' /tmp/ip3.txt
sed -i -e 's/get.php/\/get.php/g' /tmp/ip3.txt
echo "#!/bin/bash" >> /tmp/iptv1.sh
awk 'NR==1' /tmp/ip3.txt >> /tmp/iptv1.sh
echo "exit 0" >> /tmp/iptv1.sh
dos2unix /tmp/iptv1.sh
chmod 755 /tmp/iptv1.sh
sleep 2
bash /tmp/iptv1.sh
sleep 5
cat /tmp/iptv.tv | grep "[0123456789].ts" >> /tmp/iptv1.tv
cat /tmp/iptv.tv | grep "[0123456789].avi" >> /tmp/iptv2.tv
cat /tmp/iptv.tv | grep "[0123456789].AVI" >> /tmp/iptv2.tv
cat /tmp/iptv.tv | grep "[0123456789].mp4" >> /tmp/iptv2.tv
cat /tmp/iptv.tv | grep "[0123456789].MP4" >> /tmp/iptv2.tv
cat /tmp/iptv.tv | grep "[0123456789].mkv" >> /tmp/iptv2.tv
cat /tmp/iptv.tv | grep "[0123456789].MKV" >> /tmp/iptv2.tv
echo "#NAME GUNCEL IPTV" >> /tmp/userbouquet.gunceliptv.tv 
sed 's/ /&\n/1' /tmp/iptv1.tv >> /tmp/userbouquet.gunceliptv.tv
sed -i -e 's/Name\:/DESCRIPTION/g' /tmp/userbouquet.gunceliptv.tv
sed -i -e 's/\:/%3A/g' /tmp/userbouquet.gunceliptv.tv
sed -i -e 's/http/#SERVICE 4097\:0\:1\:0\:0\:0\:0\:0\:0\:0\:http/g' /tmp/userbouquet.gunceliptv.tv
echo "#NAME GUNCEL VOD" >> /tmp/userbouquet.guncelvod.tv 
sed 's/ /&\n/1' /tmp/iptv2.tv >> /tmp/userbouquet.guncelvod.tv
sed -i -e 's/Name\:/DESCRIPTION/g' /tmp/userbouquet.guncelvod.tv
sed -i -e 's/\:/%3A/g' /tmp/userbouquet.guncelvod.tv
sed -i -e 's/http/#SERVICE 4097\:0\:1\:0\:0\:0\:0\:0\:0\:0\:http/g' /tmp/userbouquet.guncelvod.tv
if grep -qs 'userbouquet.gunceliptv.tv' cat /etc/enigma2/bouquets.tv ; then
echo ""
else
echo " " >> /etc/enigma2/bouquets.tv
echo '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "userbouquet.gunceliptv.tv" ORDER BY bouquet' >> /etc/enigma2/bouquets.tv
sed -i -e '/^\s*$/d' /etc/enigma2/bouquets.tv
fi
if grep -qs 'userbouquet.guncelvod.tv' cat /etc/enigma2/bouquets.tv ; then
echo ""
else
echo " " >> /etc/enigma2/bouquets.tv 
echo '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "userbouquet.guncelvod.tv" ORDER BY bouquet' >> /etc/enigma2/bouquets.tv
sed -i -e '/^\s*$/d' /etc/enigma2/bouquets.tv
fi
rm -rf /tmp/*.txt
rm -rf /etc/enigma2/userbouquet.gunceliptv.tv
rm -rf /etc/enigma2/*.del
mv /tmp/userbouquet.gunceliptv.tv /etc/enigma2/userbouquet.gunceliptv.tv
rm -rf /etc/enigma2/userbouquet.guncelvod.tv
mv /tmp/userbouquet.guncelvod.tv /etc/enigma2/userbouquet.guncelvod.tv
rm -rf /tmp/*.tv
rm -rf /tmp/*.sh
wget -q -O - http://127.0.0.1/web/servicelistreload?mode=2
wget -q -O - http://127.0.0.1/web/servicelistreload?mode=2
wget -O /dev/null -q http://root:password@localhost/web/r...trol?command=1
wget -O /dev/null -q http://root:password@localhost/web/r...trol?command=1
wget -O /dev/null -q http://root:password@localhost/web/r...trol?command=1
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*              << endebar >>              *";
echo "*..:: https://www.turk-dreamworld.com ::..*";
echo "*******************************************";

exit 0
