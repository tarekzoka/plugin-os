#!/bin/sh
#DESCRIPTION=This script will delete all crash-logs from /media/hdd
echo "";
echo "";
rm -rf /media/hdd/enigma2_crash* > /dev/null;
echo "Media HDD içerisindeki crash.log dosyaları silindi..."
echo "";
echo "";
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*             << audi06_19 >>             *";
echo "*  ..:: https://dreamosat-forum.com ::..  *";
echo "*******************************************";
sleep 1;
exit 0
