#!/bin/sh
#Created By "TEKZEN"
#Created By audi06_19 @https://dreamosat-forum.com
#http://destek.korax.com.tr/UYDUSIS/CLOUD.txt
FIN="=================================================="
echo $FIN
echo ".....:: LÜTFEN BEKLEYİNİZ .... PLEASE WAIT ::....."
cd /;
[ -d /tmp/IPTV ] || mkdir -p /tmp/IPTV;
cd /tmp/IPTV;
sleep 1;

wget --quiet -O - http://destek.korax.com.tr/UYDUSIS/CLOUD.txt | sed -En 's/^(.*),(.*$)/#EXTINF:-1,\1\n\2/p' >2017.m3u

sed '/#EXTINF:-1,/!s/:/%3a/g' 2017.m3u >0
sed 's/#EXTINF:-1,/#DESCRIPTION: /g' 0 >00
sed '/#SERVICE 4097:0:1:0:0:0:0:0:0:0:rt/!s/http%3a/#SERVICE 4097:0:1:0:0:0:0:0:0:0:http%3a/' 00 >000
sed '/#SERVICE 4097:0:1:0:0:0:0:0:0:0:rt/!s/rtmp%3a/#SERVICE 4097:0:1:0:0:0:0:0:0:0:rtmp%3a/' 000 >0000
sed -i '1i #NAME INT IPTV' 0000
sed -n '/^#DES.*/h;/^#SER.*/{p;x;p};/^#NA.*/p' 0000 >userbouquet.INT_IPTV.tv

sleep 1;
cp /tmp/IPTV/userbouquet.INT_IPTV.tv /etc/enigma2/userbouquet.INT_IPTV.tv > /dev/null

echo $LINE


if grep -qs 'userbouquet.INT_IPTV.tv' cat /etc/enigma2/bouquets.tv  ; then
    echo "Lista esistente in Bouquet"
else 
	echo "[+]Install INT IPTV List ..."
	echo '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "userbouquet.INT_IPTV.tv" ORDER BY bouquet' >> /etc/enigma2/bouquets.tv
fi
cd /;
rm -rf /tmp/IPTV > /dev/null 2>&1
echo $LINE

wget -q -O - http://127.0.0.1/web/servicelistreload?mode=0 > /dev/null 2>&1
wget -q -O - http://127.0.0.1/web/servicelistreload?mode=2 > /dev/null 2>&1

echo "";
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*             << audi06_19 >>             *";
echo "*  ..:: https://dreamosat-forum.com ::..  *";
echo "*******************************************";
sleep 1;
exit 0

