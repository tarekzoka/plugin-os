#!/bin/sh
#Created By audi06_19 @https://dreamosat-forum.com 15-10-2017
FIN="=================================================="
echo $FIN
echo ".....:: LÜTFEN BEKLEYİNİZ .... PLEASE WAIT ::....."
echo $FIN
echo "HDD MOUT İŞLEMİ BAŞLATILDI"
echo "HDD MOUT OPERATION HAS STARTED"
[ -d /tmp/DreamOSat ] || mkdir -p /tmp/DreamOSat > /dev/null;
sleep 1
CONT=$(blkid | awk '/vfat/{print $2}')
CONT1=$(blkid | awk '/ntfs/{print $3}')
MOUT="/tmp/DreamOSat/usb-mount.txt"
echo "/dev/disk/by-uuid/$CONT	/media/usb	auto	auto,nofail	0	0" >> $MOUT
echo "/dev/disk/by-uuid/$CONT1	/media/usb	auto	auto,nofail	0	0" >> $MOUT
sleep 1
sed -i -e 's/"//g' $MOUT
sleep 1
sed -i -e 's/UUID=//g' $MOUT
sleep 1
if grep -qs '\/media\/usb' cat /etc/fstab ; then
  echo $FIN
  echo "USB Disk daha önce Mount edilmiş. Tekrar Mount edilmesine gerek yoktur..."
  echo "USB Disk Mounted previously. No need to mount again ..."
else
  echo "" >> /etc/fstab
  awk 'NR==1' $MOUT >> /etc/fstab
	
	echo $FIN
	echo "Disk id numarası yazıldı. media/usb olarak mount edildi...";
	echo "The disk id number was written. Mounted as media/usb ...";
	echo $FIN
	[ -d /media/usb/backup ] || mkdir -p /media/usb/backup > /dev/null;
	echo "media/usb/backup/ klasörü oluşturuldu...";
	echo "media/usb/backup/ folder has been created ...";
	echo $FIN
	[ -d /media/usb/movie ] || mkdir -p /media/usb/movie > /dev/null;
	echo "media/usb/movie/ klasörü oluşturuldu...";
	echo "media/usb/movie/ folder has been created ...";
	echo $FIN
	echo "Uydu alıcınız YENİDEN başlatılıyor. iyi seyirler...";
	echo "Your satellite receiver is starting again. good looking ...";
	echo "";
	rm -rf /tmp/DreamOSat > /dev/null;
	echo "*******************************************";
	echo "*          ..:: A U T H O R ::..          *";
	echo "*             << audi06_19 >>             *";
	echo "*  ..:: https://dreamosat-forum.com ::..  *";
	echo "*******************************************";
	sleep 3;
	reboot
fi
echo "";
rm -rf /tmp/DreamOSat > /dev/null;
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*             << audi06_19 >>             *";
echo "*  ..:: https://dreamosat-forum.com ::..  *";
echo "*******************************************";
sleep 3;
exit 0
