#!/bin/sh
echo "";
echo "Internet Performance"
echo "Pinging - Please Wait"
ping -c 5 www.google.com
echo ""
ping -c 5 dreamosat-forum.com
echo "Done"
echo "";
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*             << audi06_19 >>             *";
echo "*  ..:: https://dreamosat-forum.com ::..  *";
echo "*******************************************";
sleep 1;
exit 0
