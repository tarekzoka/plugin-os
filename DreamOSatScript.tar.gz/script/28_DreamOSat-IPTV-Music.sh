#!/bin/sh
#Created By audi06_19 @https://dreamosat-forum.com
echo "*           ..:: M U S İ C ::..           *";
echo "*******************************************";
echo "*   ..:: G Ü N C E L L E N İ Y O R ::..   *";
echo "*******************************************";
echo "";
ping -q -c 1 -W 1 8.8.8.8 > /dev/null; 
if [ $? -eq 1 ]; 
then exit; 
fi;
sed -i '/userbouquet.DreamOSatIPTV_music.tv/d' /etc/enigma2/bouquets.tv
echo "";
rm -rf /etc/enigma2/userbouquet.DreamOSatIPTV_music.tv

wget http://depo.dreamosat.net/oZeL/DreamOSatIPTV/bouquets/userbouquet.DreamOSatIPTV_music.tv -q -O /etc/enigma2/userbouquet.DreamOSatIPTV_music.tv > /dev/null
echo "";
echo '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "userbouquet.DreamOSatIPTV_music.tv" ORDER BY bouquet' >> /etc/enigma2/bouquets.tv

wget -q -O - http://127.0.0.1/web/servicelistreload?mode=0 > /dev/null
wget -q -O - http://127.0.0.1/web/servicelistreload?mode=2 > /dev/null

# if grep -qs 'userbouquet.DreamOSatIPTV_music.tv' cat /etc/enigma2/bouquets.tv
# then
# echo "Lista esistente in Bouquet"
# else
# echo "[+]Install IPTV LIST DreamOSat Forum ..."
# echo '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "userbouquet.DreamOSatIPTV_music.tv" ORDER BY bouquet' >> /etc/enigma2/bouquets.tv
# fi
echo "";
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*             << audi06_19 >>             *";
echo "*  ..:: https://dreamosat-forum.com ::..  *";
echo "*******************************************";
sleep 1;
exit 0

