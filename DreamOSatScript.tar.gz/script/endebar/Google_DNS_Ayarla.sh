#!/bin/sh
#Created By endebar ustaya tesekkurler
echo "SERVIS SAGLAYICI TARAFINDAN YASAKLANAN SITELERE GIRMEK ICIN DNS ADRESINIZI GOOGLE DNS OLARAK DEGISTIRIR"
echo ""
echo ""
if grep -qs 'nameserver 8.8.8.8' cat /etc/resolv.conf ; then
echo "DNS ADRESINIZ ZATEN GOOGLE DEGISTIRMEYE GEREK YOK"
else
rm -rf /etc/resolv.conf
touch /etc/resolv.conf | echo "nameserver 8.8.8.8" >> /etc/resolv.conf | echo "nameserver 8.8.4.4" >> /etc/resolv.conf
chmod 0755 /etc/resolv.conf
dos2unix /etc/resolv.conf
echo "DNS ADRESINIZ GOOGLE DNS OLARAK DEĞİŞTİRİLDİ"
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*              << endebar >>              *";
echo "*..:: https://www.turk-dreamworld.com ::..*";
echo "*******************************************";
reboot
fi

exit 0
