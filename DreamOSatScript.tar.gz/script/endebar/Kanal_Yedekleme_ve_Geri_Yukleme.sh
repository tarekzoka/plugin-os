#!/bin/sh
#Created By endebar ustaya tesekkurler
rm -rf /tmp/kanallar
rm -rf /media/usb/kanallar
rm -rf /media/hdd/kanallar
mkdir /tmp/kanallar
cat /etc/enigma2/settings | grep "config.Nims" >> /tmp/kanallar/diseqcayar.txt
scp /etc/enigma2/*.tv /tmp/kanallar/ 
scp /etc/enigma2/*.radio /tmp/kanallar/ 
scp /etc/enigma2/lamedb /tmp/kanallar/ 
scp /etc/enigma2/lamedb5 /tmp/kanallar/
scp /etc/tuxbox/satellites.xml /tmp/kanallar/
echo "kanallar /tmp dizinine yedeklendi"
rm -rf /tmp/*.txt
mkdir /media/usb/kanallar
mkdir /media/hdd/kanallar
scp /tmp/kanallar/*.* /media/usb/kanallar
scp /tmp/kanallar/*.* /media/hdd/kanallar
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*              << endebar >>              *";
echo "*..:: https://www.turk-dreamworld.com ::..*";
echo "*******************************************";

exit 0
