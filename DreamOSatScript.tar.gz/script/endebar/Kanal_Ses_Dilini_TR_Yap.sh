#!/bin/sh
#Created By endebar ustaya tesekkurler
wget -q -O - http://127.0.0.1/web/getaudiotracks >> /tmp/turkce.txt
sed -i "s/	//g" /tmp/turkce.txt
sed -i "s/	//g" /tmp/turkce.txt
sed -i -e '/<?xml version="1.0" encoding="UTF-8"?>/d' /tmp/turkce.txt
sed -i -e '/<e2audiotracklist>/d' /tmp/turkce.txt
sed -i -e '/<e2audiotrack>/d' /tmp/turkce.txt
sed -i -e '/<\/e2audiotrack>/d' /tmp/turkce.txt
sed -i -e '/<\/e2audiotracklist>/d' /tmp/turkce.txt
sed -i -e '/<e2audiotrackpid>/d' /tmp/turkce.txt
sed -i -e 's/<\/e2audiotrackdescription>//g' /tmp/turkce.txt
sed -i -e 's/<\/e2audiotrackid>//g' /tmp/turkce.txt
sed -i -e 's/<\/e2audiotrackpid>//g' /tmp/turkce.txt
sed -i -e 's/<\/e2audiotrackactive>//g' /tmp/turkce.txt
sed -i -e 's/<e2audiotrackdescription>//g' /tmp/turkce.txt
sed -i -e 's/<e2audiotrackactive>//g' /tmp/turkce.txt
sed -i -e 's/<e2audiotrackid>/id/g' /tmp/turkce.txt
sed -i -e 's/audio\/x-ac3 (Turkish)/Turkce/g' /tmp/turkce.txt
sed -i -e 's/MPEG 1 Audio, Layer 1 (Turkish)/Turkce/g' /tmp/turkce.txt
sed -i -e 's/MPEG 1 Audio, Layer 2 (Turkish)/Turkce/g' /tmp/turkce.txt
sed -i -e 's/MPEG 2 Audio, Layer 1 (Turkish)/Turkce/g' /tmp/turkce.txt
sed -i -e 's/MPEG 2 Audio, Layer 2 (Turkish)/Turkce/g' /tmp/turkce.txt
sed -i -e 's/MPEG Audio, Layer 1 (Turkish)/Turkce/g' /tmp/turkce.txt
sed -i -e 's/MPEG Audio, Layer 2 (Turkish)/Turkce/g' /tmp/turkce.txt
sed -i -e 's/MPEG (Turkish)/Turkce/g' /tmp/turkce.txt
sed -i -e 's/MPEG 1 Audio, (Turkish)/Turkce/g' /tmp/turkce.txt
sed -i -e 's/audio\/x-ac3 (Turkce)/Turkce/g' /tmp/turkce.txt
sed -i -e 's/MPEG 1 Audio, Layer 1 (Turkce)/Turkce/g' /tmp/turkce.txt
sed -i -e 's/MPEG 1 Audio, Layer 2 (Turkce)/Turkce/g' /tmp/turkce.txt
sed -i -e 's/MPEG 2 Audio, Layer 1 (Turkce)/Turkce/g' /tmp/turkce.txt
sed -i -e 's/MPEG 2 Audio, Layer 2 (Turkce)/Turkce/g' /tmp/turkce.txt
sed -i -e 's/MPEG Audio, Layer 1 (Turkce)/Turkce/g' /tmp/turkce.txt
sed -i -e 's/MPEG Audio, Layer 2 (Turkce)/Turkce/g' /tmp/turkce.txt
sed -i -e 's/MPEG (Turkce)/Turkce/g' /tmp/turkce.txt
sed -i -e 's/MPEG 1 Audio, (Turkce)/Turkce/g' /tmp/turkce.txt
while read line1; read line2; do read line3; echo "$line1 $line2 $line3"; done </tmp/turkce.txt>/tmp/turk.txt
if grep -qs 'Turkce id0 False' cat /tmp/turk.txt ; then
wget -q -O - http://127.0.0.1/web/selectaudiotrack?id=0
fi
if grep -qs 'Turkce id1 False' cat /tmp/turk.txt ; then
wget -q -O - http://127.0.0.1/web/selectaudiotrack?id=1
fi
if grep -qs 'Turkce id2 False' cat /tmp/turk.txt ; then
wget -q -O - http://127.0.0.1/web/selectaudiotrack?id=2
fi
if grep -qs 'Turkce id3 False' cat /tmp/turk.txt ; then
wget -q -O - http://127.0.0.1/web/selectaudiotrack?id=3
fi
rm -rf /tmp/turkce.txt
rm -rf /tmp/turk.txt
echo ""
echo "SES DILI TURKCE OLARAK AYARLANDI."
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*              << endebar >>              *";
echo "*..:: https://www.turk-dreamworld.com ::..*";
echo "*******************************************";

exit 0
